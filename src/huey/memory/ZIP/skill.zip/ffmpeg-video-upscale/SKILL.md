---
name: ffmpeg-video-upscale
description: recommend preservation-first ffmpeg commands for users who paste ffmpeg, ffprobe, idet, cropdetect, or mediainfo metadata and want a safe 1080p cleanup or upscale workflow. use when chatgpt needs to assess source video streams, decide whether the source is progressive or interlaced, preserve aspect ratio without stretching, choose conservative scale and pad behavior, convert containers to mkv only when needed, convert audio to flac only when needed, and return ready-to-run linux terminal commands with warnings about risky processing.
---

# Ffmpeg Video Upscale

## Overview

Analyze the user-provided stream metadata and recommend a conservative FFmpeg workflow for a 1080p derivative. Prefer preservation-first decisions. Do not invent problems that the metadata does not support.

## Workflow

1. Read the pasted metadata carefully.
2. Extract the facts that materially affect processing:
   - container
   - video codec
   - audio codec
   - width and height
   - display aspect ratio and sample aspect ratio
   - frame rate
   - field order or interlace evidence
   - color metadata
   - bitrate and bit depth when present
   - cropdetect or idet evidence when present
3. Classify the source:
   - **progressive** only when the metadata clearly supports it
   - **interlaced** only when field order or idet evidence clearly supports it
   - **uncertain** when the evidence conflicts or is incomplete
4. Choose one recommendation path:
   - **safe viewing derivative** for most cases
   - **heavier cleanup** only when the metadata clearly justifies an extra step such as deinterlacing
5. Return a concise assessment, one recommended command, a short explanation, and warnings.

## Command-building rules

### 1) Resolution and framing

Target 1920x1080 output without distortion.

- Never stretch the image.
- Preserve the display aspect ratio.
- Use scaling plus padding when needed.
- Use a filter chain based on `force_original_aspect_ratio=decrease` and pad to 1920:1080.
- Use square-pixel output unless the metadata clearly requires a different handling step.
- Use `setsar=1` in the output chain unless the source handling would make that inappropriate.

Default upscale filter chain:

```bash
-vf "scale=1920:1080:flags=lanczos:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1"
```

Do not recommend cropping by default. Only include crop when the user explicitly wants it **and** the crop evidence appears trustworthy. Even then, warn that visual confirmation is still required.

### 2) Interlace handling

- Do not deinterlace a source that appears progressive.
- Do not deinterlace when the evidence is weak or conflicting.
- Recommend deinterlacing only when field order or idet results clearly indicate an interlaced source.
- When deinterlacing is justified, prefer a conservative, standard FFmpeg filter such as `bwdif`.

Typical justified deinterlace chain:

```bash
-vf "bwdif=mode=send_frame:parity=auto:deint=all,scale=1920:1080:flags=lanczos:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1"
```

### 3) Container handling

- If the source container is not MKV, recommend an `.mkv` output file.
- If the source is already MKV, keep MKV.
- Do not add a separate remux-only step unless it helps avoid unnecessary work. Usually a single final encode into MKV is sufficient.

### 4) Audio handling

- If the source audio is already FLAC, copy it with `-c:a copy`.
- If the source audio is another lossless codec and MKV supports it cleanly, prefer copying when practical.
- If the source audio is lossy or the codec is unclear, convert to FLAC with `-c:a flac`.
- Do not resample, remix, or normalize unless the metadata or user request clearly calls for it.

### 5) Video codec choice

Prioritize a practical preservation-first workflow.

- For a high-quality derivative, default to FFV1 in MKV when the user explicitly wants the safest lossless preservation workflow and file size is not the main concern.
- For a high-quality but more practical derivative, default to libx264 with lossless settings when FFV1 would be unnecessarily heavy for the use case.
- Prefer `-crf 0 -preset veryslow -pix_fmt yuv420p` for lossless x264 only when the pixel format conversion would not discard important source fidelity.
- If the source uses higher bit depth or a non-420 format and preserving that matters, say so explicitly and prefer an output pixel format that preserves it when feasible.
- Do not guess exotic pixel-format handling when the metadata is incomplete.

Default bias:

- Use **FFV1** when the user says highest quality, archival, or lossless workflow.
- Use **libx264 lossless** only when a smaller or more compatible derivative is preferable.

### 6) Color metadata

Preserve color tags when the metadata exposes them.

When present, carry through fields such as:

```bash
-color_primaries <value> -color_trc <value> -colorspace <value> -color_range <value>
```

Only include the fields that are actually present in the input metadata. Do not invent missing color values.

### 7) Frame rate

- Preserve the source frame rate unless there is clear evidence that a change is required.
- Do not recommend interpolation or frame-rate conversion by default.

### 8) Cleanup and enhancement limits

Do not recommend these by default:

- AI upscale
- sharpening
- denoise
- crop
- frame interpolation
- frame-rate conversion
- color manipulation

Only recommend them when the user explicitly asks for them or the metadata clearly supports a necessary corrective action.

## Output format

Use exactly these labels in this order:

### Source assessment
- Summarize the source in 3 to 6 short bullets.
- State whether it appears progressive, interlaced, or uncertain, and why.
- State whether cropping evidence appears trustworthy, weak, or absent.

### Recommended command
- Return one ready-to-run FFmpeg command in a fenced bash block.
- Use descriptive placeholder filenames if the real path is not provided.

### Why this command
- Explain the reasoning in 2 to 5 bullets.
- Mention scaling, padding, container choice, audio handling, interlace decision, and codec choice.

### Warnings
- Include only the warnings that apply.
- Always warn against stretching.
- Warn against blind cropping when cropdetect is absent or weak.
- Warn against deinterlacing when the source appears progressive or uncertain.

## Decision defaults

When uncertain, prefer the safer path:

- assume progressive only if supported
- otherwise say interlace status is uncertain
- avoid crop
- avoid deinterlace
- preserve frame rate
- preserve color metadata when known
- choose mkv output
- choose flac for audio unless safe stream copy is clearly better

## Practical command patterns

Consult `references/command-patterns.md` for reusable command templates and wording patterns.
