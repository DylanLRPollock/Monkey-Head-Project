# Command patterns

Use these templates as starting points. Adapt only from facts present in the user's metadata.

## 1) Progressive source, lossy audio, archival bias

```bash
ffmpeg -i input.ext \
  -map 0:v:0 -map 0:a? -map 0:s? \
  -vf "scale=1920:1080:flags=lanczos:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1" \
  -c:v ffv1 -level 3 -g 1 \
  -c:a flac \
  -c:s copy \
  output_1080p.mkv
```

Use when the source appears progressive and the user clearly wants a lossless preservation-first derivative.

## 2) Progressive source, audio already flac, archival bias

```bash
ffmpeg -i input.ext \
  -map 0:v:0 -map 0:a? -map 0:s? \
  -vf "scale=1920:1080:flags=lanczos:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1" \
  -c:v ffv1 -level 3 -g 1 \
  -c:a copy \
  -c:s copy \
  output_1080p.mkv
```

Use when audio is already FLAC and can be preserved without re-encoding.

## 3) Interlaced source, justified deinterlace, archival bias

```bash
ffmpeg -i input.ext \
  -map 0:v:0 -map 0:a? -map 0:s? \
  -vf "bwdif=mode=send_frame:parity=auto:deint=all,scale=1920:1080:flags=lanczos:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1" \
  -c:v ffv1 -level 3 -g 1 \
  -c:a flac \
  -c:s copy \
  output_1080p.mkv
```

Use only when interlacing is clearly supported by field order or idet evidence.

## 4) Progressive source, practical compatibility bias

```bash
ffmpeg -i input.ext \
  -map 0:v:0 -map 0:a? -map 0:s? \
  -vf "scale=1920:1080:flags=lanczos:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1" \
  -c:v libx264 -preset veryslow -crf 0 \
  -c:a flac \
  -c:s copy \
  output_1080p.mkv
```

Use only when the user wants a more practical lossless derivative and the source characteristics do not call for more exact preservation than this path can provide.

## 5) Color metadata carry-through

Append only the tags that are actually present in the source metadata:

```bash
-color_primaries bt709 -color_trc bt709 -colorspace bt709
```

Do not invent color values.

## 6) Assessment wording patterns

### Progressive
- Source appears progressive because field order is progressive or idet does not indicate meaningful interlacing.

### Interlaced
- Source appears interlaced because field order and idet both indicate combed fields, so conservative deinterlacing is justified.

### Uncertain
- Interlace status is uncertain because the metadata is incomplete or conflicting, so preservation-first handling should avoid deinterlacing.

### Cropdetect
- Cropdetect is suggestive, not definitive; do not crop unless the result has been visually confirmed.
