# DLRP Style System

## 1. Identity

The DLRP site family is:

- purple-first
- dark and immersive
- clean rather than noisy
- structured around rounded cards and pill controls
- emotionally personal but technically grounded

It should feel like a serious personal lab site, not a startup landing page and not a generic blog theme.

## 2. Color posture

Use a dark purple base and layered purple gradients first.

Typical behavior:

- page background is deep purple or plum
- panels are darker, translucent, or gradient-backed purple surfaces
- subtle blue-purple or teal drift may appear in gradients
- green/teal is restrained and used as an accent only
- text remains bright and readable, usually off-white rather than harsh pure white

Avoid:

- light themes by default
- heavy grey neutrals
- loud rainbow accents
- flat single-color card surfaces unless the page deliberately needs quietness

## 3. Header system

The canonical header is:

- sticky
- visually light relative to the body but still dark
- left brand area
- centered primary nav
- right utility controls
- pill navigation with rounded borders
- active state visibly highlighted but still restrained

Desktop should not default to hamburger-first navigation.

## 4. Footer system

The footer should echo the header language quietly:

- chips or pills for major links
- darker surface
- clean spacing
- quiet build/version line when relevant
- no oversized or cluttered footer stacks

## 5. Type system

Preferred roles:

- Inter: body text, interface labels, buttons, navigation
- Space Grotesk: page titles, major section titles, prominent card titles
- Caveat: handwritten quote or motto accents only

Body copy should remain readable and moderately sized.
Headlines can be strong and large but should not become ornamental.

## 6. Spacing and rhythm

Use generous spacing.

The site works best when:

- sections have breathing room
- cards stack in a calm vertical rhythm
- hero or anchor cards appear first
- denser mini-card grids appear later
- text blocks are not too wide

## 7. Cards

Cards are the main architectural language.

Shared traits:

- rounded corners
- soft borders
- depth through gradients/shadows rather than harsh hard edges
- image and text integrated into one unit

## 8. Buttons

Buttons should usually be pill-shaped and calm.

Use:

- outlined or lightly filled pill buttons
- restrained hover/focus treatment
- compact labels

Avoid oversized aggressive ctas.

## 9. Images

Images should feel deliberate.

- use rounded media frames
- crop intentionally
- keep object-position thoughtful
- avoid awkward letterboxing when possible
- let major images carry mood as well as information

## 10. Tone

Page writing should sound like Dylan and the site family:

- grounded
- reflective
- direct
- technically aware
- human

Avoid:

- generic brand slogans
- overhyped product language
- corporate conversion copy
