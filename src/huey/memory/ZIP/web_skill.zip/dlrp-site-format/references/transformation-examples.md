# Transformation Examples

## Example 1: Restyle an old static page

### Input

- existing about.html
- existing css file
- a few profile images

### Desired result

Rewrite the full page into the DLRP family.

### Good transformation choices

- preserve the original content meaning
- rebuild the page around one full-card intro and supporting half-cards
- normalize colors into the purple-first palette
- add the canonical sticky header and quiet footer
- return a short change log

## Example 2: Build a new page from copy and image paths

### Input

- title and copy for a Dogs page
- image paths only

### Desired result

Create a full static page in DLRP style.

### Good transformation choices

- full-card intro for the page identity
- image-led supporting cards or mini-card grid depending on volume
- preserve the site family without forcing homepage duplication
- keep the tone personal and warm, not cute or generic

## Example 3: Repair a visually inconsistent page using a screenshot

### Input

- broken html/css
- latest screenshot of the intended look

### Desired result

Correct the page so it fits the current site family.

### Good transformation choices

- recover working structure from code first
- use screenshot to correct spacing, crop, and visual rhythm
- prefer canonical DLRP decisions where screenshot artifacts conflict with clean layout
- explain the major fixes briefly

## Example 4: Return reusable sections after a rewrite

### Input

- one complete project page rewrite

### Desired result

Return the full page plus reusable section blocks.

### Good transformation choices

- extract a reusable hero full-card
- extract reusable mini-card markup for related links
- keep the reusable pieces plain html/css/js first
