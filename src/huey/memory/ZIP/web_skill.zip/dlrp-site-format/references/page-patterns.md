# Page Patterns

## Full-card

Use for hero sections or major anchors.

### Structure

- kicker
- title
- optional quote/motto accent
- one to three short body paragraphs
- primary action
- media block

### Layout behavior

- split layout on desktop
- stacked layout on smaller screens
- content side should feel spacious
- media should feel integral, not appended

### Good use cases

- page intros
- identity anchors
- major section openers
- high-importance story or project intros

## Half-card

Use for supporting sections that still need visual weight.

### Structure

- eyebrow or kicker
- title
- one or two body paragraphs
- optional supporting link or button
- optional image or icon block

### Good use cases

- supporting about sections
- sub-project descriptions
- documentation or research previews
- paired overview sections

## Mini-card

Use for repeatable grid content.

### Structure

- image or illustration on top
- eyebrow
- title
- short description
- pill action

### Grid behavior

- three-column grid on desktop when space allows
- reduce to two or one column responsively
- cards should remain balanced in height where practical

### Good use cases

- projects
- docs / research / playlist cards
- dogs/media/supporting links

## Typical DLRP Page Rhythm

A good default page rhythm is:

1. sticky header
2. one full-card hero or anchor
3. one or more supporting full-cards or half-cards
4. mini-card grid for related destinations
5. quiet footer

Not every page needs every layer, but this is the safest default family shape.

## Family resemblance without cloning

Stay in the same family by preserving:

- purple-first visual identity
- rounded card language
- header/footer continuity
- type roles
- image-led structure
- calm pill actions

Do not copy the homepage section-for-section unless the page truly needs the same structure.
