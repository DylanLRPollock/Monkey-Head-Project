---
name: dlrp-site-format
description: create, rewrite, or restyle static website pages for dlrp.ca in the exact dlrp house style. use when chatgpt needs to work from existing html/css/js, raw section copy and image paths, or screenshots/mockups to produce a full dlrp-standard page rewrite, reusable sections, or a short style audit. prioritize existing page code first, then supporting copy/assets, then screenshots for visual alignment. default to plain html/css/js unless the user explicitly requests another framework.
---

# DLRP Site Format

## Overview

Use this skill to keep pages for **dlrp.ca** visually and structurally coherent with the live house style.

Default behavior:

1. inspect the existing page code first when it exists
2. recover the page's real structure and content
3. rewrite the page into the DLRP family rather than cloning the homepage literally
4. return a **complete page** in plain HTML/CSS/JS unless the user explicitly asks for a different framework
5. include a **short style audit or change log** explaining what changed and why

This is a **strict house-style** skill for DLRP pages, not a vague inspiration generator.

## Workflow Decision Tree

### 1. Decide the input mode

Choose the strongest available source in this order:

1. **existing page code**
   - html
   - css
   - js
   - partial page sections
   - zipped static-site content
2. **supporting content and assets**
   - raw copy
   - headings
   - ctas
   - image paths
   - page outlines
3. **visual references**
   - screenshots
   - captures
   - pdf exports
   - mockups

Important rule: when code exists, treat it as the primary structural source. Use screenshots to refine visual matching, not to override working structure without reason.

### 2. Decide the output mode

Default to a **complete DLRP-standard page rewrite**.

Also support these secondary outputs when the user asks or when they help the task:

- corrected full-page code
- reusable sections or components
- concise style audit
- short change log
- targeted recommendations when a clean full rewrite is blocked

### 3. Decide the transformation path

**Existing page present?**
Follow the **Existing Page Rewrite** workflow.

**No page, only copy/assets?**
Follow the **New Page Build** workflow.

**Screenshot or visual matching emphasized?**
Follow the **Visual Alignment Pass** after the page structure is established.

## Existing Page Rewrite

1. inspect the current html, css, and js before inventing new structure
2. preserve valid page meaning, links, metadata, and content hierarchy where possible
3. normalize the page into DLRP patterns:
   - full-card
   - half-card
   - mini-card
   - sticky header
   - quiet footer
4. remove generic, flat, or off-brand styling
5. keep javascript minimal and purposeful
6. return a full rewritten page
7. add a short change log with the most important visual and structural corrections

## New Page Build

1. determine the page's purpose
2. map the copy into the correct DLRP page rhythm
3. choose the right card hierarchy:
   - full-card for anchor or hero sections
   - half-card for supporting major blocks
   - mini-cards for repeatable linked content
4. assign images deliberately and set object-position when needed
5. build the full page in plain html/css/js
6. keep the page clearly in the DLRP family without cloning the homepage section-for-section
7. include a brief note describing the chosen structure if helpful

## Visual Alignment Pass

Use this when screenshots, captures, or mockups matter.

1. read the screenshot as a visual guide for spacing, crop balance, scale, and feel
2. preserve DLRP identity over one-off visual accidents in the screenshot
3. correct:
   - spacing rhythm
   - card proportions
   - image crop logic
   - nav/footer continuity
   - color balance
4. prefer canonical DLRP decisions when the screenshot and page code disagree

## Non-Negotiable DLRP Style Rules

### Purple-first identity

The page must remain unmistakably purple-first.

Required traits:

- dark purple base background
- layered purple gradients
- subtle depth rather than flat blocks
- restrained green or teal accent only
- no white-page redesigns unless explicitly requested
- no neutral corporate grey takeover

### Restrained green accent

Green is an accent, not the main brand color.

Good uses:

- active nav emphasis
- subtle border or glow details
- selective cta emphasis
- small interface highlights

Do not let green dominate the page.

### Rounded card system

The site should feel built from a coherent card language.

Required traits:

- generous rounded corners
- layered card surfaces
- soft borders
- soft glow or shadow
- pill buttons and pill nav language

### Header and footer continuity

Preserve the family resemblance of the header and footer across pages.

Required header traits:

- sticky top bar
- left brand
- centered primary nav
- right utility area
- pill-like navigation items
- visible current-page state
- translucent dark surface with border and blur feel

Required footer traits:

- quieter than main content
- chip or pill link language
- centered or balanced layout
- build/version line when relevant

### Typography hierarchy

Use the DLRP type roles consistently.

- **Inter** for body and interface readability
- **Space Grotesk** for headings and prominent titles
- **Caveat** only for selective handwritten quote-style emphasis

Do not overuse decorative typography.

### Visual rhythm

Keep the page spacious, centered, and legible.

- strong vertical pacing
- large cards first, smaller cards later
- image-led but copy-supported
- no dashboard clutter
- no cramped sections

### Tone

Keep the site voice:

- personal
- calm
- clear
- serious without stiffness
- technically grounded without sounding sterile
- meaningful without melodrama

Do not generate generic startup-marketing copy.

## Page Patterns

Read `references/page-patterns.md` when choosing structure.

Use these patterns:

### Full-card

Use for hero or anchor sections.

Characteristics:

- high-priority section
- large rounded card
- split layout on desktop
- text/content on one side
- media on the other side
- kicker, title, body, cta

### Half-card

Use for supporting major content blocks.

Characteristics:

- related to full-card language
- more compact
- can be paired in grid/two-column layouts
- supports image-top or text-first variants

### Mini-card

Use for repeatable linked content.

Characteristics:

- compact card
- image or illustration on top
- eyebrow
- title
- short copy
- pill action

## Image Handling Rules

1. crop images cleanly
2. round them to match the card system
3. set object-position deliberately when needed
4. never treat images as floating afterthoughts
5. keep media integrated into the card structure

## Code Rules

1. prefer semantic html
2. default to plain html/css/js
3. reduce unnecessary wrappers when restructuring
4. keep js minimal and purposeful
5. preserve accessibility basics
6. preserve canonical metadata and links unless the user changes them
7. avoid framework drift on static pages

## Explicitly Avoid

- generic saas design language
- flat white or grey redesigns
- excessive glassmorphism
- over-animation
- random component-library feel
- tiny cramped copy
- inconsistent radii
- broken card hierarchy
- literal homepage cloning for every page
- loud accent colors that break the purple-first family

## Return Format

Unless the user asks otherwise, return:

1. **complete page code**
2. **any reusable sections/components worth preserving**
3. **short style audit/change log**

Use the change log to explain the most important corrections, such as:

- color normalization
- card restructuring
- header/footer alignment
- crop fixes
- spacing cleanup
- tone cleanup

## Resources

Read these references when relevant:

- `references/style-system.md` for color, type, spacing, and header/footer rules
- `references/page-patterns.md` for full-card, half-card, and mini-card structure
- `references/transformation-examples.md` for concrete before/after style transformations

Use `assets/page-shell.html` as a static-site-first starter when building a full page from scratch.
