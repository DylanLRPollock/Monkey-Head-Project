# Sample Data

This directory contains sample JSON files that demonstrate the data structure expected by the HueyOS Migration Command Center dashboard.

## Files

### migration-phases.json

Complete migration phase data including:
- Phase definitions with status and risk levels
- Risk assessments and mitigation strategies
- Checklists and validation commands
- Phase-specific notes
- Global migration notes

**Usage**: Import this file via the "Export/Import" section in the dashboard to load a complete migration state.

### v1-proof-loop-runs.json

Sample V1 Brain proof loop run data including:
- Audio fixture filenames
- Transcription results
- Cognition bridge responses
- Pass/fail results
- Error details
- Raw JSONL-style data

**Usage**: Reference this structure when generating real V1 run logs for import into the dashboard.

### operator-panel-status.json

Mock operator panel status data including:
- System identity and version information
- API health status
- Proof loop statistics
- Memory store metrics
- Governance status
- Connector states
- Recent log entries

**Usage**: This structure represents what the Operator Panel Mock displays. In future phases with real integration, this format would be returned by HueyOS status endpoints.

### dependency-security-backlog.json

Dependency and security tracking data including:
- Outdated package information
- Security vulnerability reports (CVE references)
- Technical debt items
- Test coverage metrics
- Code quality indicators

**Usage**: This data structure can be used to track security and quality issues alongside migration phases. Not currently integrated into the dashboard but available for future enhancements.

## Using Sample Data

### Import into Dashboard

1. Open the HueyOS Migration Command Center
2. Scroll to the "Data Export & Import" section
3. Click "Import State"
4. Select `migration-phases.json`
5. The dashboard will load the sample migration state

### Export Your Own Data

1. Make changes in the dashboard (update statuses, add notes, etc.)
2. Scroll to the "Data Export & Import" section
3. Click "Export State"
4. Save the JSON file to back up your dashboard state

### Customize Sample Data

You can edit these JSON files to:
- Add your own migration phases
- Modify risk assessments
- Update checklists
- Add custom validation commands
- Track your specific project timeline

## Data Formats

All data files follow TypeScript types defined in `src/lib/types.ts`. Refer to that file for the complete schema.

### Key Data Types

```typescript
// Migration phase status
type PhaseStatus = 'not-started' | 'in-progress' | 'blocked' | 'ready' | 'merged'

// Risk levels
type RiskLevel = 'low' | 'medium' | 'high'

// V1 run status
type RunStatus = 'pending' | 'complete' | 'error'

// V1 run result
type RunResult = 'passed' | 'failed' | 'pending'

// Connector status
type ConnectorStatus = 'connected' | 'disconnected' | 'error'

// System health status
type HealthStatus = 'healthy' | 'degraded' | 'unhealthy'
```

## Important Notes

- **All data is mock/sample**: These files contain fictional data for demonstration and testing purposes only
- **No production data**: Never commit real production logs, credentials, or sensitive information
- **Schema validation**: The dashboard validates imported data against expected schemas
- **Privacy**: Sample data is safe to share publicly as part of the repository

## Creating Your Own Samples

To create your own sample data files:

1. Use the dashboard to create your desired state
2. Export the state to JSON
3. Save to this directory with a descriptive filename
4. Add documentation above explaining the sample's purpose
5. Ensure no sensitive data is included

## Future Enhancements

Future versions may include:
- JSONL log file samples for V1 run import
- GitHub webhook payload samples
- API response samples for read-only integrations
- Test fixture audio file references
- Performance benchmark data

---

**Remember**: This is a local-first dashboard. All data stays on your machine unless you explicitly export and share it.
