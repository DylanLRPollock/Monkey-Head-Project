# Security Policy

## Critical Safety Notice

**This application does not control live HueyOS systems.**

The HueyOS Migration Command Center is a **local dashboard prototype** for migration tracking and UI experimentation only. It has **no capability** to control, modify, or interact with production HueyOS systems, robots, networks, or infrastructure.

## Security Boundaries

### ✅ Safe Operations (What This App Does)

- Store dashboard state in browser localStorage
- Display mock data for prototyping
- Import/export JSON files chosen by user
- Copy validation commands to clipboard
- Render UI components and layouts

### ❌ Prohibited Operations (What This App Cannot Do)

- Execute commands on HueyOS systems
- Control robots or physical hardware
- Modify production memory or governance state
- Connect to live networks without explicit user configuration
- Store or transmit credentials
- Access files outside browser sandbox
- Make external API calls (current phase - may be added later with strict read-only boundaries)

## Do Not Commit Secrets

**Never commit the following to this repository:**

- ❌ API keys or access tokens
- ❌ Private keys or certificates
- ❌ Database credentials or connection strings
- ❌ Production configuration files
- ❌ Real HueyOS logs containing sensitive data
- ❌ OAuth secrets or client secrets
- ❌ Personal access tokens

All sample data must be **fictional and clearly marked as mock data**.

## Do Not Expose Live HueyOS Controls

**Current Phase (A-B)**: This dashboard uses mock data only. No live integrations exist.

**Future Phases (C+)**: If read-only integrations are added, they must:

- Be explicitly opt-in
- Use read-only adapters with no write/control capabilities
- Never store credentials in localStorage or frontend code
- Be documented in the integration phase documentation
- Pass security review before deployment

**Never to be added**: Live control capabilities (system commands, robot control, memory mutation, governance changes) will never be added to this dashboard. This is a monitoring and planning tool, not a control surface.

## Reporting Security Issues

### For This Repository

If you discover a security vulnerability in the HueyOS Migration Command Center dashboard:

**Do not open a public issue.** Please report privately to the repository owner.

### For HueyOS Runtime or Monkey-Head-Project

This repository is not part of HueyOS runtime code. Security issues in HueyOS itself should be reported according to the Monkey-Head-Project security policy.

### What to Report

Please include:

- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

### What Qualifies as a Security Issue

Examples of security issues in this dashboard:

- XSS vulnerabilities in imported JSON rendering
- Potential for credential leakage in future integrations
- Unsafe file handling in import/export
- Code injection via malformed data

Examples of **non-issues** (by design):

- "Dashboard doesn't validate if HueyOS commands are safe" - Dashboard doesn't execute commands
- "Could display sensitive data" - User controls what data they import
- "No authentication" - Not needed for local-only tool

## Responsible Disclosure

We appreciate responsible disclosure of security vulnerabilities. Please:

1. Report privately to the repository owner
2. Allow reasonable time for a fix before public disclosure
3. Do not exploit the vulnerability beyond verification

---

**Remember**: This dashboard is a local-first tool. Your data stays on your machine unless you explicitly export and share it. No production systems are at risk from this application.

