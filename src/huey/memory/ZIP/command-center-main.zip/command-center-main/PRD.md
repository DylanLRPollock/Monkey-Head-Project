# Planning Guide

A local-first migration command center dashboard for tracking the Monkey-Head-Project repository migration from legacy HueyOS paths to the new src/huey architecture. This is a companion prototype tool for development tracking - it does NOT execute HueyOS runtime code, control robots, or mutate system state.

**Experience Qualities**: 
1. **Technical precision** - Information should be dense, organized, and immediately actionable with clear visual status indicators
2. **Command-ready** - Every validation command should be one click away from clipboard, emphasizing developer efficiency
3. **Mission-critical clarity** - Risk levels, phase status, and blockers should be instantly visible with operator-console urgency

**Complexity Level**: Light Application (multiple features with basic state)
  - The app manages migration phase tracking, risk assessment, checklists, validation commands, V1 run viewing, operator panel mockups, and data export/import with local browser persistence for team coordination

## Essential Features

### Phase Status Cards
- **Functionality**: Display migration phases with editable status, risk levels, and progress indicators
- **Purpose**: Provide at-a-glance understanding of where the migration stands
- **Trigger**: User views dashboard on load
- **Progression**: View phases → Select phase card → Edit status/risk → Auto-saves to local storage
- **Success criteria**: All 4 phases visible with distinct status indicators, editable fields persist across sessions

### Current Phase Indicator
- **Functionality**: Highlights the active migration phase with emphasis
- **Purpose**: Immediately orient operators to current work focus
- **Trigger**: Determined by phase status (first "in progress" or latest "not started")
- **Progression**: Dashboard loads → Algorithm identifies current phase → Visual emphasis applied
- **Success criteria**: Current phase visually distinct with prominent positioning or styling

### Active Risks Panel
- **Functionality**: Lists all high/medium risks across phases with descriptions
- **Purpose**: Surface critical blockers that need attention
- **Trigger**: Automatic aggregation from phase data
- **Progression**: Phase risks updated → Risk panel refreshes → Sorted by severity
- **Success criteria**: Risks displayed with severity badges, filterable by level

### PR Checklist Manager
- **Functionality**: Interactive checklist with checkboxes for each phase's PR requirements
- **Purpose**: Ensure no steps are skipped before merge
- **Trigger**: User expands phase details or views dedicated checklist section
- **Progression**: View checklist → Check/uncheck items → Status persists → Visual completion indicator
- **Success criteria**: Checkboxes functional, completion percentage shown, state persists

### Validation Commands Center
- **Functionality**: Displays validation commands with one-click copy buttons
- **Purpose**: Eliminate manual typing errors and speed up validation workflow
- **Trigger**: User views validation section or phase details
- **Progression**: View command → Click copy button → Toast confirmation → Paste in terminal
- **Success criteria**: All 8 validation commands listed, copy button functional, toast feedback

### Notes Section
- **Functionality**: Persistent textarea for team notes and migration context
- **Purpose**: Capture decisions, blockers, and context that doesn't fit structured data
- **Trigger**: User clicks notes section
- **Progression**: Click notes → Type/edit content → Auto-save on blur → Content persists
- **Success criteria**: Rich text area, auto-saves, persists across sessions

### Migration Timeline Visualization
- **Functionality**: Visual progress bar or timeline showing phase sequence
- **Purpose**: Communicate overall migration progress and remaining work
- **Trigger**: Loads with dashboard
- **Progression**: View timeline → See phase sequence → Status color-coded → Understand progress
- **Success criteria**: All phases in sequence, color-coded by status, progress percentage visible

### Safety Boundaries Panel
- **Functionality**: Displays clear safety boundaries and operational limitations
- **Purpose**: Communicate that this is a read-only dashboard with no live system control
- **Trigger**: Always visible on migration tracker tab
- **Progression**: User views panel → Understands app limitations → Trusts safe usage
- **Success criteria**: 6 safety boundaries listed with checkmarks, clear messaging about mock-only status

### Umbrella Links Panel
- **Functionality**: Quick links to related Monkey-Head-Project repositories and documentation
- **Purpose**: Provide navigation to related resources and project context
- **Trigger**: Always visible on migration tracker tab
- **Progression**: View links → Click to navigate → Access related resources
- **Success criteria**: All 5 umbrella project links displayed with descriptions

### Subrepo Status Card
- **Functionality**: Shows repository metadata and integration status
- **Purpose**: Clarify this app's relationship to the Monkey-Head-Project umbrella
- **Trigger**: Always visible on migration tracker tab
- **Progression**: View status → Understand repo positioning → Know integration mode
- **Success criteria**: 4 status fields displayed (repo name, umbrella, status, integration mode)

### Data Export/Import
- **Functionality**: Export migration data as JSON file and import previously exported data
- **Purpose**: Enable data backup, sharing, and restoration across sessions or team members
- **Trigger**: User clicks export/import buttons
- **Progression**: Click export → File downloads → Or click import → Select file → Data restored → Toast confirmation
- **Success criteria**: Export generates timestamped JSON file, import validates and restores data, error handling for invalid files

## Edge Case Handling
- **Empty State**: First load shows all phases as "not started" with helpful onboarding message
- **Data Corruption**: If localStorage data is malformed, reset to default mock data with user notification
- **Copy Failure**: If clipboard API unavailable, show modal with command text for manual copy
- **Long Notes**: Notes section should handle multi-paragraph content without layout breaking
- **Rapid Edits**: Debounce auto-save to prevent excessive localStorage writes

## Design Direction
The design should evoke a high-tech operations control center - precise, authoritative, and mission-focused. Think terminal aesthetics meets modern dashboards, with glowing purple accents against deep dark backgrounds creating a focused, immersive workspace for critical migration work.

## Color Selection
A dark, technical color scheme with vibrant purple as the brand color and electric green for success/validation states, creating high contrast for rapid information scanning.

- **Primary Color**: Deep vivid purple `oklch(0.55 0.25 285)` - Represents HueyOS brand identity, used for primary actions and key highlights, communicating technical sophistication
- **Secondary Colors**: 
  - Dark navy background `oklch(0.12 0.02 265)` - Deep, focused workspace
  - Slate gray `oklch(0.25 0.015 265)` - Card backgrounds and panels
  - Dim gray `oklch(0.35 0.01 265)` - Secondary text and borders
- **Accent Color**: Electric green `oklch(0.75 0.20 145)` - Commands, success states, and validation indicators, suggesting operational readiness
- **Status Colors**:
  - Blocked/High Risk: Crimson `oklch(0.60 0.24 25)` 
  - In Progress: Bright cyan `oklch(0.70 0.15 210)`
  - Ready/Merged: Electric green (accent)
  - Not Started: Muted gray `oklch(0.45 0.02 265)`
- **Foreground/Background Pairings**: 
  - Background `oklch(0.12 0.02 265)`: Light gray text `oklch(0.92 0.01 265)` - Ratio 15.2:1 ✓
  - Primary Purple `oklch(0.55 0.25 285)`: White text `oklch(0.98 0 0)` - Ratio 6.1:1 ✓
  - Accent Green `oklch(0.75 0.20 145)`: Dark background `oklch(0.12 0.02 265)` - Ratio 12.8:1 ✓
  - Card Background `oklch(0.25 0.015 265)`: Light gray text `oklch(0.92 0.01 265)` - Ratio 11.5:1 ✓

## Font Selection
Typefaces should communicate technical precision and modern engineering, balancing monospace code aesthetics with readable interface typography.

- **Primary Font**: JetBrains Mono - Monospace font for code commands and technical content, reinforcing developer tool identity
- **Secondary Font**: Inter - Clean sans-serif for UI text, ensuring readability in long-form content
- **Typographic Hierarchy**: 
  - H1 (Page Title): JetBrains Mono Bold / 32px / tight tracking (-0.02em) / uppercase
  - H2 (Section Headers): Inter SemiBold / 20px / normal tracking
  - H3 (Phase Names): Inter Medium / 18px / normal tracking
  - Body (Descriptions): Inter Regular / 15px / line-height 1.6
  - Code/Commands: JetBrains Mono Regular / 14px / line-height 1.5
  - Labels: Inter Medium / 13px / uppercase / tracking 0.05em
  - Captions: Inter Regular / 12px / muted color

## Animations
Animations should feel responsive and instantaneous, with subtle transitions that guide attention without delaying interaction. Micro-interactions on status changes and copy actions provide satisfying feedback.

- Button hovers: Quick color shift (100ms) with subtle glow on primary actions
- Status changes: Smooth color transition (200ms) with scale pulse (150ms)
- Copy button: Check icon swap animation (250ms) with success toast
- Card expansions: Height transition (300ms ease-out) for collapsible sections
- Risk level changes: Color fade (200ms) with optional shake for "blocked"
- Page load: Staggered fade-in (50ms delay per card) for visual hierarchy

## Component Selection
- **Components**: 
  - `Card` - Phase cards, risk panels, notes section with purple borders on hover
  - `Badge` - Status indicators, risk levels with appropriate color variants
  - `Button` - Primary actions (copy commands), secondary actions (edit) with icon support
  - `Checkbox` - PR checklist items with custom purple checked state
  - `Textarea` - Notes section with dark styling
  - `Progress` - Migration timeline progress bar with purple fill
  - `Tabs` - If needed for organizing validation commands vs. checklists
  - `Select` - Dropdown for changing phase status and risk levels
  - `Separator` - Dividing sections with subtle dark borders
  - `Tooltip` - Additional context on validation commands
- **Customizations**: 
  - Custom status badge colors beyond shadcn defaults (cyan for "in progress", crimson for "blocked")
  - Monospace styling for command text blocks
  - Glowing purple border effect on interactive cards
  - Copy button with animated icon transition
- **States**: 
  - Buttons: Default (purple bg), hover (lighter purple + glow), active (darker purple), disabled (muted)
  - Cards: Default (slate bg), hover (purple border glow), focus (ring)
  - Checkboxes: Unchecked (border), checked (purple fill), indeterminate (dash)
  - Inputs/Selects: Default (dark border), focus (purple ring), filled (border color shift)
- **Icon Selection**: 
  - `@phosphor-icons/react` - Copy (`Copy`), Check (`Check`), Warning (`Warning`), Info (`Info`), GitBranch (`GitBranch`), Terminal (`Terminal`), CheckCircle (`CheckCircle`), XCircle (`XCircle`), Clock (`Clock`)
- **Spacing**: 
  - Page padding: `p-6` on mobile, `p-8` on desktop
  - Card padding: `p-6`
  - Gap between cards: `gap-6`
  - Section margins: `mb-8` for major sections
  - Inline spacing: `space-x-2` for buttons/badges
- **Mobile**: 
  - Single column layout for all sections
  - Phase cards stack vertically
  - Commands section becomes scrollable horizontal list or accordion
  - Bottom fixed "Current Phase" indicator for context
  - Touch-friendly button sizes (min 44px)
  - Collapsible sections to conserve screen space
