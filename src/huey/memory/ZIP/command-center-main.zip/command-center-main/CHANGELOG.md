# Changelog

All notable changes to the HueyOS Migration Command Center will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Repository Preparation
- Added comprehensive documentation structure
- Added project scope and data boundaries documentation
- Added development roadmap
- Added sample data files with README
- Enhanced .gitignore for security
- Updated SECURITY.md with clear boundaries
- Polished README.md with full feature documentation
- Added CONTRIBUTING.md guidelines

## [0.2.0] - 2024-01-15

### Added - Phase B: Import/Export JSON
- Export migration state to JSON file
- Import migration state from JSON file
- Data Export/Import UI section in dashboard
- Sample data files in `sample-data/` directory
- JSON schema validation on import
- Version stamping for exports

### Enhanced
- Safety Boundaries section in UI
- Umbrella Links panel with project relationships
- Subrepo Status card showing repository role

## [0.1.0] - 2024-01-10

### Added - Phase A: Local Mock Dashboard
- Migration phase tracking with status indicators
- Risk assessment and management interface
- Interactive PR checklists per phase
- Validation command display with copy buttons
- Phase-specific and global notes
- Overall progress tracking
- V1 Run Viewer tab with mock JSONL data
- Operator Panel Mock tab with system status
- Local browser persistence using Spark KV store
- Purple/black HueyOS theme with green accents
- Responsive layout for mobile and desktop

### Components
- PhaseCard component for migration phases
- V1RunViewer for proof loop visualization
- V1RunCard for individual run display
- OperatorPanel for system status mockup
- StatusBadge for visual indicators
- CopyButton for command copying
- SafetyBoundaries information panel
- UmbrellaLinks reference panel
- SubrepoStatus metadata display
- DataExportImport functionality

### Documentation
- Initial README with setup instructions
- SECURITY.md with safety boundaries
- Basic project structure

## Future Releases

### [0.3.0] - Phase C: GitHub Integration (Planned)
- Read-only GitHub API adapter
- Public repository status display
- Issue and PR integration
- CI/CD pipeline status
- Optional OAuth for private repos

### [0.4.0] - Phase D: Log Viewer (Planned)
- JSONL log file import
- V1 run analysis from real logs
- Error pattern detection
- Performance metrics dashboard

### [0.5.0] - Phase E: Authenticated Read-Only (Conditional)
- OAuth authentication flow
- Real system health metrics (read-only)
- Live connector status monitoring
- Memory and governance insights

---

## Version History Summary

| Version | Phase | Date | Focus |
|---------|-------|------|-------|
| 0.1.0 | Phase A | 2024-01-10 | Local mock dashboard |
| 0.2.0 | Phase B | 2024-01-15 | Import/export JSON |
| 0.3.0 | Phase C | Q2 2024 | GitHub integration |
| 0.4.0 | Phase D | Q3 2024 | Log viewer |
| 0.5.0 | Phase E | Q4 2024+ | Authenticated read-only |

---

## Notes

- **Breaking Changes**: Will be clearly marked in version notes
- **Security Updates**: Will be released immediately as patch versions
- **Deprecations**: Will be announced one version before removal
- **Experimental Features**: May be marked as (experimental) in notes

For detailed development plans, see [docs/roadmap.md](docs/roadmap.md).
