# HueyOS Migration Command Center

A local-first companion dashboard for the **Monkey-Head-Project** ecosystem. This tool tracks the repository migration from legacy HueyOS paths to the new `src/huey` architecture, provides V1 proof loop visualization, and prototypes operator panel interfaces.

---

## 🤖 Project Relationship

This application is part of the Monkey-Head-Project ecosystem:

- **[Monkey-Head-Project](https://github.com/your-org/monkey-head-project)** - Main HueyOS runtime and umbrella repository
- **[PyHuey](https://github.com/your-org/pyhuey)** - Operator cockpit fork (formerly `pygpt_net`)
- **HueyOS Migration Command Center** (this repository) - Dashboard and prototyping companion

---

## ⚠️ Important: This is NOT HueyOS Runtime Code

This dashboard is a **companion tool** for development planning and tracking only.

### What This App Does NOT Do

- ❌ Execute HueyOS runtime code
- ❌ Control robots or physical systems
- ❌ Connect to production networks
- ❌ Mutate memory or governance state
- ❌ Execute system commands
- ❌ Make external API calls (current phase)

### What This App DOES Do

- ✅ Track migration phases locally
- ✅ Manage risk assessments and checklists
- ✅ Display validation commands with copy functionality
- ✅ Visualize mock V1 proof loop runs
- ✅ Prototype operator panel interfaces
- ✅ Export/import dashboard state

**All data is local and mock by default.** This is a safe planning and prototyping tool with no production system access.

---

## 🎯 Purpose

The Migration Command Center provides:

- **Migration Tracking**: Phase-by-phase progress with status indicators
- **Risk Management**: Track risks, mitigation strategies, and blockers
- **PR Checklists**: Interactive task lists for each migration phase
- **Validation Commands**: Quick-copy commands for testing
- **V1 Run Viewer**: JSONL-style proof loop visualization (mock data)
- **Operator Panel Mock**: UI prototypes for HueyOS cockpit interfaces

---

## 🚀 Getting Started

### Prerequisites

- **Node.js** 18+ and npm

### Installation

```bash
npm install
```

### Development

```bash
npm run dev
```

The app will open in your browser at the URL shown in terminal (typically `http://localhost:5173`).

### Build for Production

```bash
npm run build
```

Build output will be in the `dist/` directory.

---

## 📊 Features

### 1. Migration Tracker

Track your HueyOS migration progress:

- **Phase Status**: Not Started → In Progress → Blocked → Ready → Merged
- **Risk Levels**: Low, Medium, High with mitigation strategies
- **Interactive Checklists**: Track task completion per phase
- **Validation Commands**: One-click copy of test/validation commands
- **Phase Notes**: Document decisions, blockers, and next steps
- **Global Notes**: Overall migration context and stakeholder info
- **Progress Bar**: Visual overall completion tracking

### 2. V1 Run Viewer

Visualize Huey Brain V1 proof loop runs:

- **Proof Loop Flow**: MP3 fixtures → Transcription → Cognition → Structured logs
- **Run Timeline**: Chronological view of test runs
- **Status Filters**: Filter by passed, failed, or pending
- **Error Details**: View transcription and cognition errors
- **JSON Inspector**: Examine raw JSONL data per run
- **Export**: Download visible runs as JSON

**Note**: Currently displays mock data. Future phases may support importing real log files.

### 3. Operator Panel Mock

Prototype HueyOS operator cockpit interfaces:

- **System Identity**: Instance ID, version, environment, uptime
- **API Health**: Endpoint status and response times
- **Proof Loop Status**: Run statistics and success rates
- **Memory Metrics**: Storage usage and sync status
- **Governance Status**: Active rules and violation tracking
- **Connector Status**: Real-time connector health indicators
- **Recent Logs**: System log stream
- **Safe Actions**: UI mockups for future operator controls

**⚠️ All actions are mock-only.** No actual system operations occur. This is for UI/UX design and validation.

### 4. Safety Boundaries

Clear indicators that this dashboard:

- Uses mock data only
- Has no live robot control
- Makes no network/system mutations
- Performs no governance/memory changes
- Has no external API calls (current phase)

### 5. Umbrella Links

Quick access to related resources:

- Monkey-Head-Project repository
- PyHuey cockpit repository
- HueyOS architecture documentation
- Migration phase documentation

### 6. Subrepo Status

Dashboard metadata showing:

- Repository role within Monkey-Head-Project
- Current status (companion prototype)
- Integration mode (separate repo, optional submodule later)

---

## 💾 Data Persistence

All dashboard state persists locally in your browser using the **Spark KV store**. No data is transmitted to external servers.

### What Gets Saved

- Migration phase statuses and risk levels
- Checklist completion states
- Phase-specific and global notes
- User preferences and UI state

### Export & Import

Back up or share your dashboard state:

1. **Export**: Click "Export State" in the Data Export/Import section
2. **Import**: Click "Import State" and select a previously exported JSON file

Exported files are standard JSON and can be:

- Backed up before clearing browser data
- Shared with team members
- Version controlled (if no sensitive data)
- Edited manually (with caution)

### Sample Data

The `sample-data/` directory contains example JSON files you can import to test the dashboard or use as templates.

---

## 🔒 Safety & Security

This application operates with strict safety boundaries to ensure it cannot accidentally impact production systems.

### Data Handling

- ✅ **Local-first**: All data stored in browser only
- ✅ **Mock by default**: Pre-loaded data is fictional
- ✅ **No secrets**: Never stores API keys or credentials
- ✅ **User-controlled**: You control all imports/exports
- ✅ **No telemetry**: No analytics or tracking

### Current Phase: No Network Access

The current version (Phase A-B) makes **zero network requests**. Everything runs locally in your browser.

**Future Phases**: Read-only integrations may be added (GitHub API, log file viewing) with:

- Explicit user opt-in
- Clear documentation
- No write/control capabilities
- Security review and auditing

See [docs/roadmap.md](docs/roadmap.md) for integration plans.

### Reporting Security Issues

Do not commit:

- API keys or tokens
- Production logs with sensitive data
- Real credentials or secrets

Report security vulnerabilities privately to the repository owner. See [SECURITY.md](SECURITY.md) for details.

---

## 📁 Project Structure

```
.
├── docs/
│   ├── project-scope.md        # Repository scope and boundaries
│   ├── data-boundaries.md      # Data handling rules
│   └── roadmap.md              # Development phases
├── sample-data/
│   ├── migration-phases.json         # Sample migration state
│   ├── v1-proof-loop-runs.json       # Sample V1 runs
│   ├── operator-panel-status.json    # Sample operator data
│   └── dependency-security-backlog.json
├── src/
│   ├── components/             # React components
│   │   ├── ui/                # shadcn components
│   │   ├── PhaseCard.tsx
│   │   ├── V1RunViewer.tsx
│   │   ├── OperatorPanel.tsx
│   │   └── ...
│   ├── lib/
│   │   ├── mockData.ts        # Default mock data
│   │   ├── types.ts           # TypeScript types
│   │   └── utils.ts
│   ├── App.tsx                # Main app component
│   └── index.css              # Theme and styles
├── README.md                  # This file
├── SECURITY.md                # Security policy
└── package.json               # Dependencies
```

---

## 🎨 Design & Theme

- **Color Scheme**: Dark mode with purple-first palette and green accents
- **Typography**: Inter (UI) and JetBrains Mono (code)
- **Style**: Operator console aesthetic
- **Components**: Built with shadcn/ui and Radix UI primitives
- **Icons**: Phosphor Icons
- **Animation**: Subtle Framer Motion effects

Theme customization in `src/index.css` using CSS custom properties and Tailwind.

---

## 🗂️ Migration Phases

The dashboard tracks these migration phases:

1. **Phase 1**: HueyOS layout migration under `src/huey`
2. **Phase 2**: `huey.os` canonical import path with compatibility shim
3. **Phase 2.5**: Move `src/huey/pygpt_net` to `src/huey/connectors/pyhuey`
4. **Phase 3**: Rename PyHuey repo package from `pygpt_net` to `pyhuey`

Each phase includes:

- Status tracking
- Risk assessment
- Checklist items
- Validation commands
- Notes and documentation

---

## 🛠️ Development

### Technology Stack

- **Framework**: React 19 with TypeScript
- **Build Tool**: Vite
- **Styling**: Tailwind CSS v4
- **Components**: shadcn/ui v4, Radix UI
- **Icons**: Phosphor Icons
- **State**: React hooks + Spark KV for persistence
- **Animation**: Framer Motion
- **Deployment**: Static build (no backend required)

### Available Scripts

```bash
npm run dev      # Start development server
npm run build    # Production build
npm run preview  # Preview production build
npm run lint     # Run ESLint
```

### Adding Features

When adding features:

1. Start with mock data in `src/lib/mockData.ts`
2. Define TypeScript types in `src/lib/types.ts`
3. Build UI components in `src/components/`
4. Test with sample data files
5. Document in relevant `/docs` files
6. Ensure no external API calls (current phase)

See [docs/project-scope.md](docs/project-scope.md) for development guidelines.

---

## 📖 Documentation

- **[Project Scope](docs/project-scope.md)** - Role within Monkey-Head-Project, operational boundaries
- **[Data Boundaries](docs/data-boundaries.md)** - Data handling rules, security practices
- **[Roadmap](docs/roadmap.md)** - Development phases and future integrations
- **[Security Policy](SECURITY.md)** - Security boundaries and reporting
- **[Sample Data Guide](sample-data/README.md)** - Using and creating sample data

---

## 🔗 Related Projects

### Monkey-Head-Project Ecosystem

- **Monkey-Head-Project**: Main runtime repository ([link](https://github.com/your-org/monkey-head-project))
- **PyHuey**: Operator cockpit fork ([link](https://github.com/your-org/pyhuey))
- **HueyOS Architecture Docs**: Design documentation (internal)

### Technologies

- [Spark Template](https://github.com/github/spark) - Runtime environment
- [shadcn/ui](https://ui.shadcn.com/) - Component library
- [Tailwind CSS](https://tailwindcss.com/) - Styling framework
- [Radix UI](https://www.radix-ui.com/) - Primitives
- [Phosphor Icons](https://phosphoricons.com/) - Icon set

---

## 📄 License

The Spark Template files and resources from GitHub are licensed under the terms of the MIT license, Copyright GitHub, Inc.

Additional project code follows the license specified by the Monkey-Head-Project umbrella.

---

## 🤝 Contributing

This is a companion tool for the Monkey-Head-Project. Contributions should:

- Maintain safety boundaries (no live system control)
- Use mock data by default
- Follow existing code patterns
- Include documentation updates
- Pass TypeScript and ESLint checks

---

## 📞 Support

For questions or issues:

- **This Dashboard**: Open an issue in this repository
- **HueyOS Runtime**: Refer to Monkey-Head-Project repository
- **Migration Planning**: Contact the development team

---

**Repository Status**: Companion prototype | Separate repo, optional submodule later | Phase A-B complete
