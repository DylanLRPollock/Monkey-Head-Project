# Data Boundaries

## Overview

This document establishes strict boundaries for data handling in the HueyOS Migration Command Center. These rules ensure the dashboard remains a safe, local-first tool that cannot accidentally impact production systems.

## Core Principles

### 1. Local-First by Default

**All features must work with local mock data by default.**

- No network calls required for core functionality
- No authentication needed to use the app
- No dependencies on external services
- All state stored in browser storage only

### 2. No Secrets in Frontend Code

**Never store or transmit secrets in the frontend application.**

#### Prohibited Practices

- ❌ API keys hardcoded in JavaScript/TypeScript
- ❌ Access tokens in localStorage without encryption
- ❌ Passwords in configuration files
- ❌ Private keys in the codebase
- ❌ Connection strings with credentials
- ❌ OAuth secrets in the frontend

#### Acceptable Practices

- ✅ Public GitHub repository URLs
- ✅ Public API endpoints (if read-only)
- ✅ Documentation links
- ✅ Mock/sample credentials clearly labeled as such
- ✅ User-provided credentials in memory only (never stored)

### 3. No Private Data Committed

**The repository must never contain sensitive production data.**

#### Prohibited Content

- ❌ Production logs with PII
- ❌ Real system configurations
- ❌ Actual robot command histories
- ❌ Real user data or profiles
- ❌ Internal network information
- ❌ Real API keys or tokens
- ❌ Database dumps or backups
- ❌ Real error traces with system details

#### Acceptable Content

- ✅ Sanitized/anonymized sample data
- ✅ Fictional mock data with realistic structure
- ✅ Public documentation excerpts
- ✅ Open-source code examples
- ✅ Schema definitions without data
- ✅ Placeholder values clearly marked

### 4. Mock Data Only by Default

**All pre-loaded data must be clearly mock/fictional.**

#### Mock Data Standards

Mock data should be:

- **Realistic but fictional**: Mirrors real structure without real content
- **Clearly labeled**: Obvious it's not production data (e.g., "test_fixture.mp3")
- **Self-contained**: No dependencies on external systems
- **Version controlled**: Committed to the repository
- **Documented**: JSON schema or TypeScript types provided

#### Examples

```typescript
// ✅ GOOD: Clearly mock data
export const mockSystemStatus = {
  instanceId: 'huey-dev-001',
  environment: 'development',
  message: 'Mock data for prototyping only'
}

// ❌ BAD: Looks like real production data
export const systemStatus = {
  instanceId: 'prod-huey-cluster-3',
  environment: 'production',
  privateKey: 'sk-real-key-here'
}
```

## Data Storage Boundaries

### Browser Storage (Permitted)

The application may use browser-local storage mechanisms:

- ✅ **localStorage**: For user preferences and dashboard state
- ✅ **IndexedDB (via Spark KV)**: For structured local data
- ✅ **sessionStorage**: For temporary UI state
- ✅ **In-memory state**: React state, temporary calculations

**Important**: All browser storage is:
- Local to the user's machine
- Not transmitted automatically
- Cleared on browser reset/clear data
- User-owned and user-controlled

### External Storage (Prohibited by Default)

The application must NOT use:

- ❌ Cloud databases (Firebase, Supabase, etc.)
- ❌ Remote file storage (S3, Dropbox, etc.)
- ❌ Analytics services (Google Analytics, Mixpanel, etc.)
- ❌ Logging services (Sentry, LogRocket, etc.)
- ❌ CDNs for user data
- ❌ Third-party APIs for storage

**Exception**: May be permitted in future phases with:
- Explicit user opt-in
- Clear data usage policy
- Documented integration adapter
- Security review

## Import/Export Boundaries

### Safe Import Practices

When importing user-provided data:

1. **Validate Schema**: Ensure data matches expected structure
2. **Sanitize Inputs**: Strip dangerous content (scripts, etc.)
3. **Size Limits**: Reject unreasonably large files
4. **Type Checking**: Verify data types match expectations
5. **Error Handling**: Fail gracefully on invalid data
6. **No Execution**: Never eval() or execute imported code

```typescript
// ✅ GOOD: Validated import
function importMigrationData(jsonString: string): MigrationData {
  try {
    const data = JSON.parse(jsonString)
    return migrationDataSchema.parse(data) // Zod validation
  } catch (error) {
    throw new Error('Invalid migration data format')
  }
}

// ❌ BAD: Unsafe import
function importData(jsonString: string) {
  return eval(`(${jsonString})`) // Never do this!
}
```

### Safe Export Practices

When exporting data:

1. **JSON Only**: Use standard JSON serialization
2. **No Credentials**: Strip any sensitive fields
3. **Sanitize Paths**: Remove absolute file paths
4. **User Control**: Let user choose export location
5. **Clear Labeling**: Mark exports with timestamp and version

```typescript
// ✅ GOOD: Clean export
function exportMigrationData(data: MigrationData): string {
  const sanitized = {
    ...data,
    exportedAt: new Date().toISOString(),
    version: '1.0',
    // Credentials intentionally omitted
  }
  return JSON.stringify(sanitized, null, 2)
}
```

## Future Integration Boundaries

### Read-Only Adapter Pattern

When integrating with real systems (future phases), use the **Read-Only Adapter Pattern**:

```typescript
interface ReadOnlyAdapter {
  // Permitted: Query operations only
  query(params: QueryParams): Promise<ReadOnlyData>
  
  // Prohibited: No write operations
  // create(): never
  // update(): never
  // delete(): never
  // execute(): never
}
```

### Integration Checklist

Before adding any external integration:

- [ ] **Purpose**: Why is real data needed? (mock data insufficient?)
- [ ] **Read-Only**: Guaranteed no write operations?
- [ ] **Opt-In**: User must explicitly enable?
- [ ] **Documented**: Clear explanation of what data is accessed?
- [ ] **Rate-Limited**: Prevents abuse or accidents?
- [ ] **Auditable**: All queries logged locally?
- [ ] **Fail-Safe**: Errors don't affect source system?
- [ ] **Timeout**: Queries timeout quickly?
- [ ] **No Credentials**: Frontend never stores auth tokens?
- [ ] **Security Review**: Has someone reviewed for vulnerabilities?

### Explicit Adapter Boundaries

Each adapter must:

1. **Live in a dedicated module**: `src/adapters/github-readonly.ts`
2. **Have a clear interface**: TypeScript interface defining allowed operations
3. **Be feature-flagged**: Disabled by default, enabled via config
4. **Log all access**: Every query attempt logged to console
5. **Handle errors gracefully**: Never crash on network failure
6. **Document limitations**: README section on what it can/cannot do

## File System Boundaries

### Prohibited

- ❌ Reading files from user's file system (except via file picker)
- ❌ Writing files to user's file system (except via download prompt)
- ❌ Executing shell commands
- ❌ Accessing system paths
- ❌ Modifying browser extensions
- ❌ Installing native modules

### Permitted

- ✅ User-triggered file upload via `<input type="file">`
- ✅ User-triggered file download via `Blob` + `download` attribute
- ✅ Reading uploaded files in memory only
- ✅ Displaying file content in UI

## Network Boundaries

### Current (Phase A-B): Zero Network Calls

- All data is local/mock
- No fetch() or XMLHttpRequest
- No WebSocket connections
- No iframe embeds from external sources
- No image loading from external URLs

### Future (Phase C+): Limited Read-Only Network Calls

When network integration is added:

1. **GitHub API (Read-Only)**
   - ✅ Public repository metadata
   - ✅ Issue/PR status (public repos)
   - ✅ Repository statistics
   - ❌ No write operations
   - ❌ No private repo access without user OAuth

2. **HueyOS Log Viewer (Read-Only)**
   - ✅ Read exported log files
   - ✅ View system health metrics
   - ❌ No log modification
   - ❌ No log deletion
   - ❌ No live command execution

## Credential Handling

### Never Store Credentials

If future phases require authentication:

1. **Use OAuth flow**: Redirect to provider, receive token
2. **Store token in memory only**: Never localStorage
3. **Session-based**: Token expires when tab closes
4. **User-controlled**: Clear "sign out" button
5. **Minimal scope**: Request least privilege needed
6. **Revocable**: User can revoke access anytime

### Example Safe Pattern

```typescript
// ✅ GOOD: Session-only token
let sessionToken: string | null = null

async function authenticateUser() {
  // OAuth flow, token stored in memory only
  sessionToken = await getTokenFromOAuthFlow()
  // Token never touches localStorage
}

function signOut() {
  sessionToken = null // Cleared on sign out
}
```

## Audit & Compliance

### Logging

- Log all import/export operations
- Log all network requests (when added)
- Log all adapter queries (when added)
- Never log sensitive data (tokens, PII)

### Regular Reviews

- Quarterly security audit of data handling code
- Review all new integrations before merge
- Update this document when new boundaries are needed
- Test that mock-only mode works without network

## Summary

| Boundary | Rule | Why |
|----------|------|-----|
| **Secrets** | Never in frontend | Prevents exposure of credentials |
| **Private Data** | Never committed | Prevents data leaks |
| **Mock Data** | Default for all features | Ensures safe development |
| **Storage** | Browser-local only | User-controlled, no cloud sync |
| **Network** | None by default | Prevents accidental production access |
| **File System** | User-triggered only | Browser sandbox security |
| **Integration** | Explicit adapters only | Clear boundaries, auditable |

These boundaries ensure the HueyOS Migration Command Center remains a safe, trustworthy tool that cannot accidentally harm production systems or leak sensitive data.
