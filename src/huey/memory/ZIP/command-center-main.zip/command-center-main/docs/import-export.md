# Import / Export Documentation

The HueyOS Migration Command Center supports comprehensive import/export functionality for all dashboard data. All operations are performed locally in your browser with no server uploads.

## Overview

The Import / Export panel allows you to:
- Import and export individual datasets
- Export the complete dashboard state as a single file
- Reset all data to sample defaults
- Validate imported JSON before applying changes

## Data Formats

All data is stored and exported as JSON. The dashboard manages four separate datasets:

### 1. Migration Phases (`migration-phases.json`)

Contains migration phase tracking data including phases, risks, checklists, and validation commands.

**Schema:**
```json
{
  "phases": [
    {
      "id": string,
      "name": string,
      "description": string,
      "status": "not-started" | "in-progress" | "blocked" | "ready" | "merged",
      "riskLevel": "low" | "medium" | "high",
      "risks": [
        {
          "id": string,
          "level": "low" | "medium" | "high",
          "description": string,
          "mitigation": string (optional)
        }
      ],
      "checklist": [
        {
          "id": string,
          "text": string,
          "completed": boolean
        }
      ],
      "validationCommands": string[],
      "notes": string
    }
  ],
  "globalNotes": string
}
```

**Example:**
```json
{
  "phases": [
    {
      "id": "phase-1",
      "name": "Phase 1: HueyOS layout migration under src/huey",
      "description": "Move all HueyOS-related code from legacy paths...",
      "status": "in-progress",
      "riskLevel": "medium",
      "risks": [
        {
          "id": "risk-1-1",
          "level": "medium",
          "description": "Import path conflicts during transition",
          "mitigation": "Use compatibility shims and gradual rollout"
        }
      ],
      "checklist": [
        {
          "id": "check-1-1",
          "text": "Create src/huey directory structure",
          "completed": true
        }
      ],
      "validationCommands": [
        "python scripts/check_stale_platform_strings.py"
      ],
      "notes": "Currently working on updating imports."
    }
  ],
  "globalNotes": "Migration started Q1 2024..."
}
```

### 2. V1 Proof Loop Runs (`v1-proof-loop-runs.json`)

Contains test run data from the Huey Brain V1 proof loop system.

**Schema:**
```json
[
  {
    "id": string,
    "timestamp": string (ISO 8601),
    "fixtureFilename": string,
    "transcriptionStatus": "complete" | "error" | "pending",
    "transcriptionText": string (optional),
    "transcriptionError": string (optional),
    "cognitionStatus": "complete" | "error" | "pending",
    "cognitionResponse": string (optional),
    "cognitionError": string (optional),
    "result": "passed" | "failed" | "pending",
    "errorDetails": string (optional),
    "rawJson": object
  }
]
```

**Example:**
```json
[
  {
    "id": "run-001",
    "timestamp": "2024-01-15T14:23:45.123Z",
    "fixtureFilename": "test_hello_world.mp3",
    "transcriptionStatus": "complete",
    "transcriptionText": "Hello Huey, please turn on the lights.",
    "cognitionStatus": "complete",
    "cognitionResponse": "Understood. Turning on lights in living room.",
    "result": "passed",
    "rawJson": {
      "fixture": "test_hello_world.mp3",
      "transcription": {
        "text": "Hello Huey, please turn on the lights.",
        "confidence": 0.98
      },
      "cognition": {
        "intent": "light_control",
        "action": "turn_on",
        "target": "living_room"
      },
      "result": "passed"
    }
  }
]
```

### 3. Operator Panel Data (`operator-panel-status.json`)

Contains simulated HueyOS operator panel system status.

**Schema:**
```json
{
  "systemIdentity": {
    "instanceId": string,
    "version": string,
    "environment": string,
    "uptime": number,
    "hostname": string
  },
  "apiHealth": {
    "status": "healthy" | "degraded" | "down",
    "lastCheck": string (ISO 8601),
    "responseTime": number,
    "endpoints": [
      {
        "name": string,
        "status": "healthy" | "degraded" | "down",
        "responseTime": number
      }
    ]
  },
  "proofLoop": {
    "status": "running" | "paused" | "stopped" | "error",
    "currentRun": string (optional),
    "totalRuns": number,
    "successRate": number,
    "lastRunTime": string (ISO 8601),
    "errorCount": number
  },
  "memory": {
    "status": "healthy" | "degraded" | "down",
    "totalEntries": number,
    "recentWrites": number,
    "lastSync": string (ISO 8601),
    "storageUsed": number,
    "storageLimit": number
  },
  "governance": {
    "status": "healthy" | "degraded" | "down",
    "activeRules": number,
    "violations": number,
    "lastAudit": string (ISO 8601),
    "emergencyMode": boolean
  },
  "connectors": [
    {
      "id": string,
      "name": string,
      "status": "connected" | "disconnected" | "error",
      "lastPing": string (ISO 8601),
      "messageCount": number
    }
  ],
  "recentLogs": [
    {
      "id": string,
      "timestamp": string (ISO 8601),
      "level": "info" | "warn" | "error" | "debug",
      "source": string,
      "message": string
    }
  ]
}
```

### 4. Dependency & Security Backlog (`dependency-security-backlog.json`)

Contains dependency updates, security issues, technical debt, test coverage, and code quality metrics.

**Schema:**
```json
{
  "dependencies": [
    {
      "id": string,
      "package": string,
      "currentVersion": string,
      "latestVersion": string,
      "status": string,
      "severity": string,
      "updateRecommendation": string,
      "relatedPhases": string[]
    }
  ],
  "securityIssues": [
    {
      "id": string,
      "severity": string,
      "package": string,
      "vulnerability": string,
      "description": string,
      "affectedVersions": string,
      "fixedVersion": string,
      "recommendation": string,
      "status": string,
      "resolvedDate": string (optional),
      "relatedPhases": string[]
    }
  ],
  "technicalDebt": [
    {
      "id": string,
      "title": string,
      "description": string,
      "priority": string,
      "estimatedEffort": string,
      "impact": string,
      "relatedPhases": string[]
    }
  ],
  "testCoverage": {
    "overall": number,
    "byModule": [
      {
        "module": string,
        "coverage": number,
        "status": string
      }
    ],
    "gaps": [
      {
        "module": string,
        "missingTests": string[],
        "priority": string
      }
    ]
  },
  "codeQuality": {
    "lintIssues": number,
    "formattingIssues": number,
    "complexityWarnings": number,
    "duplicateCode": number,
    "unusedImports": number
  }
}
```

### 5. Full Dashboard State

The full dashboard state export combines all four datasets into a single file for backup purposes.

**Schema:**
```json
{
  "migrationData": { /* Migration Phases schema */ },
  "v1Runs": [ /* V1 Proof Loop Runs schema */ ],
  "operatorPanelData": { /* Operator Panel Data schema */ },
  "dependencyBacklog": { /* Dependency & Security Backlog schema */ }
}
```

## Import Process

1. Click the appropriate "Import..." button for your dataset
2. Select a valid JSON file from your computer
3. The system validates the JSON structure
4. If valid, the data replaces the current dataset
5. If invalid, an error message shows which fields are incorrect

**Validation checks:**
- JSON syntax correctness
- Required fields present
- Correct data types
- Valid enum values (statuses, levels, etc.)

## Export Process

1. Click the appropriate "Export..." button
2. A JSON file downloads to your browser's default download location
3. The filename includes the dataset type and timestamp (for full state exports)

**File naming:**
- Individual datasets use fixed names (e.g., `migration-phases.json`)
- Full state exports include date: `hueyos-dashboard-full-state-2024-01-15.json`

## Reset to Sample Data

The "Reset to Sample Data" button restores all datasets to their original mock/sample values. This operation:
- Cannot be undone
- Clears all custom data
- Restores default sample data from `sample-data/` directory
- Requires confirmation before proceeding

## Data Privacy & Safety

✓ **All data is stored locally** in your browser's IndexedDB storage  
✓ **No data is uploaded** to external servers  
✓ **Export files are created client-side** only  
✓ **Imported files are validated** before applying  
✓ **Invalid JSON will be rejected** with error details  

## Sample Data Files

Reference sample data files are available in the `sample-data/` directory:
- `migration-phases.json` - Sample migration phase data
- `v1-proof-loop-runs.json` - Sample V1 run data
- `operator-panel-status.json` - Sample operator panel data
- `dependency-security-backlog.json` - Sample dependency/security data

These files serve as:
- Templates for creating your own data
- Schema references
- Default reset values
- Testing fixtures

## Common Use Cases

### Backup Your Work
1. Go to "Import / Export" tab
2. Click "Export Full State"
3. Save the downloaded file somewhere safe

### Share Data With Team
1. Export the relevant dataset(s)
2. Share the JSON file via your preferred method
3. Team member imports the file on their instance

### Move to Production Data
1. Replace sample data with real migration information
2. Export as backup
3. Continue tracking real progress

### Reset After Testing
1. Test features with modified data
2. Click "Reset to Sample Data"
3. Return to clean starting state

## Troubleshooting

### Import Fails with "Invalid JSON"
- Check that the file is valid JSON (use a JSON validator)
- Ensure no trailing commas or syntax errors
- Verify the file wasn't corrupted during transfer

### Import Fails with Schema Errors
- Review the error message for specific field issues
- Compare your JSON structure to the schemas above
- Check that enum values match exactly (case-sensitive)
- Ensure all required fields are present

### Export Doesn't Download
- Check browser's download permissions
- Verify popup blockers aren't interfering
- Try a different browser

### Data Doesn't Persist
- Ensure browser allows IndexedDB storage
- Check that you're not in private/incognito mode
- Verify sufficient disk space available

## Technical Notes

- All timestamps should be in ISO 8601 format (`YYYY-MM-DDTHH:mm:ss.sssZ`)
- Boolean values must be lowercase (`true`/`false`)
- Numbers should not be quoted strings
- Array fields cannot be `null` (use empty array `[]` instead)
- Optional fields can be omitted entirely or set to `undefined`
