export interface ValidationCommand {
  id: string
  repo: string
  command: string
  purpose: string
  expectedResult: string
  riskLevel: 'low' | 'medium' | 'high'
  notes?: string
}

export const validationCommands: ValidationCommand[] = [
  {
    id: 'mhp-check-stale',
    repo: 'Monkey-Head-Project',
    command: 'python scripts/check_stale_platform_strings.py',
    purpose: 'Detect stale platform-specific strings',
    expectedResult: 'No stale strings found',
    riskLevel: 'low'
  },
  {
    id: 'mhp-check-drift',
    repo: 'Monkey-Head-Project',
    command: 'python scripts/check_repo_drift.py',
    purpose: 'Detect repository drift from canonical structure',
    expectedResult: 'No drift detected',
    riskLevel: 'medium'
  },
  {
    id: 'mhp-check-legacy-imports',
    repo: 'Monkey-Head-Project',
    command: 'python scripts/check_legacy_hueyos_imports.py',
    purpose: 'Find legacy hueyos imports that should use huey.os',
    expectedResult: 'No legacy imports found',
    riskLevel: 'high'
  },
  {
    id: 'mhp-black',
    repo: 'Monkey-Head-Project',
    command: 'python -m black --check src tests scripts conftest.py',
    purpose: 'Verify code formatting with Black',
    expectedResult: 'All files formatted correctly',
    riskLevel: 'low'
  },
  {
    id: 'mhp-isort',
    repo: 'Monkey-Head-Project',
    command: 'python -m isort --check-only src tests scripts conftest.py',
    purpose: 'Verify import sorting with isort',
    expectedResult: 'All imports sorted correctly',
    riskLevel: 'low'
  },
  {
    id: 'mhp-ruff',
    repo: 'Monkey-Head-Project',
    command: 'python -m ruff check src tests scripts conftest.py',
    purpose: 'Run Ruff linter for code quality',
    expectedResult: 'No linting errors',
    riskLevel: 'medium'
  },
  {
    id: 'mhp-flake8',
    repo: 'Monkey-Head-Project',
    command: 'python -m flake8 --exclude=src/huey/connectors/pyhuey src tests scripts conftest.py',
    purpose: 'Run Flake8 linter (excluding pyhuey connector)',
    expectedResult: 'No linting errors',
    riskLevel: 'medium'
  },
  {
    id: 'mhp-pytest',
    repo: 'Monkey-Head-Project',
    command: 'python -m pytest -q',
    purpose: 'Run full test suite',
    expectedResult: 'All tests pass',
    riskLevel: 'high'
  },
  {
    id: 'pyhuey-poetry-check',
    repo: 'PyHuey',
    command: 'poetry check',
    purpose: 'Validate pyproject.toml and poetry.lock',
    expectedResult: 'All set!',
    riskLevel: 'low'
  },
  {
    id: 'pyhuey-pytest',
    repo: 'PyHuey',
    command: 'python -m pytest -q',
    purpose: 'Run PyHuey test suite',
    expectedResult: 'All tests pass',
    riskLevel: 'high'
  },
  {
    id: 'pyhuey-import-smoke',
    repo: 'PyHuey',
    command: 'python -c "import pyhuey, pyhuey.app, pygpt_net, pygpt_net.app; print(\'package import smoke passed\')"',
    purpose: 'Smoke test package imports',
    expectedResult: 'package import smoke passed',
    riskLevel: 'high'
  },
  {
    id: 'cc-install',
    repo: 'command-center',
    command: 'npm install',
    purpose: 'Install dependencies',
    expectedResult: 'Dependencies installed successfully',
    riskLevel: 'low'
  },
  {
    id: 'cc-lint',
    repo: 'command-center',
    command: 'npm run lint',
    purpose: 'Run ESLint',
    expectedResult: 'No linting errors',
    riskLevel: 'low'
  },
  {
    id: 'cc-build',
    repo: 'command-center',
    command: 'npm run build',
    purpose: 'Build production bundle',
    expectedResult: 'Build completes successfully',
    riskLevel: 'medium'
  }
]

export function getValidationCommandsByRepo(repo: string): ValidationCommand[] {
  return validationCommands.filter(cmd => cmd.repo === repo)
}
