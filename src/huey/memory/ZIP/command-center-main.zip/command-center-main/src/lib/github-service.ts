import type { 
  GitHubRepository, 
  PullRequest, 
  Issue, 
  WorkflowRun, 
  RepositoryHealth,
  GitHubSettings 
} from './github-types'

export class GitHubService {
  private settings: GitHubSettings

  constructor(settings: GitHubSettings) {
    this.settings = settings
  }

  updateSettings(settings: GitHubSettings) {
    this.settings = settings
  }

  private async fetchGitHub(url: string): Promise<any> {
    if (!this.settings.enabled || !this.settings.token) {
      throw new Error('GitHub API not configured')
    }

    const response = await fetch(url, {
      headers: {
        'Authorization': `token ${this.settings.token}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    })

    if (!response.ok) {
      throw new Error(`GitHub API error: ${response.statusText}`)
    }

    return response.json()
  }

  async getRepository(owner: string, name: string): Promise<GitHubRepository | null> {
    try {
      const data = await this.fetchGitHub(`https://api.github.com/repos/${owner}/${name}`)
      
      return {
        owner,
        name,
        fullName: data.full_name,
        description: data.description || '',
        purpose: '',
        role: '',
        url: data.html_url,
        defaultBranch: data.default_branch,
        openPRs: data.open_issues_count,
        openIssues: data.open_issues_count
      }
    } catch (error) {
      console.error('Failed to fetch repository:', error)
      return null
    }
  }

  async getPullRequests(owner: string, name: string): Promise<PullRequest[]> {
    try {
      const data = await this.fetchGitHub(
        `https://api.github.com/repos/${owner}/${name}/pulls?state=open`
      )
      
      return data.map((pr: any) => ({
        number: pr.number,
        title: pr.title,
        state: pr.state,
        createdAt: pr.created_at,
        updatedAt: pr.updated_at,
        author: pr.user.login,
        url: pr.html_url,
        draft: pr.draft,
        labels: pr.labels.map((l: any) => l.name)
      }))
    } catch (error) {
      console.error('Failed to fetch pull requests:', error)
      return []
    }
  }

  async getIssues(owner: string, name: string): Promise<Issue[]> {
    try {
      const data = await this.fetchGitHub(
        `https://api.github.com/repos/${owner}/${name}/issues?state=open`
      )
      
      return data
        .filter((issue: any) => !issue.pull_request)
        .map((issue: any) => ({
          number: issue.number,
          title: issue.title,
          state: issue.state,
          createdAt: issue.created_at,
          updatedAt: issue.updated_at,
          author: issue.user.login,
          url: issue.html_url,
          labels: issue.labels.map((l: any) => l.name)
        }))
    } catch (error) {
      console.error('Failed to fetch issues:', error)
      return []
    }
  }

  async getWorkflowRuns(owner: string, name: string): Promise<WorkflowRun[]> {
    try {
      const data = await this.fetchGitHub(
        `https://api.github.com/repos/${owner}/${name}/actions/runs?per_page=5`
      )
      
      return data.workflow_runs.map((run: any) => ({
        id: run.id,
        name: run.name,
        status: run.status,
        conclusion: run.conclusion,
        createdAt: run.created_at,
        url: run.html_url
      }))
    } catch (error) {
      console.error('Failed to fetch workflow runs:', error)
      return []
    }
  }

  async getRepositoryHealth(
    owner: string, 
    name: string, 
    purpose: string,
    role: string
  ): Promise<RepositoryHealth> {
    const [repo, prs, issues, workflows] = await Promise.all([
      this.getRepository(owner, name),
      this.getPullRequests(owner, name),
      this.getIssues(owner, name),
      this.getWorkflowRuns(owner, name)
    ])

    return {
      repo: repo || {
        owner,
        name,
        fullName: `${owner}/${name}`,
        description: '',
        purpose,
        role,
        url: `https://github.com/${owner}/${name}`,
        defaultBranch: 'main',
        openPRs: 0,
        openIssues: 0
      },
      openPRs: prs,
      openIssues: issues,
      recentWorkflowRuns: workflows,
      lastUpdated: new Date().toISOString()
    }
  }
}

export function getMockRepositoryHealth(
  owner: string,
  name: string,
  purpose: string,
  role: string,
  mockData: Partial<RepositoryHealth> = {}
): RepositoryHealth {
  return {
    repo: {
      owner,
      name,
      fullName: `${owner}/${name}`,
      description: purpose,
      purpose,
      role,
      url: `https://github.com/${owner}/${name}`,
      defaultBranch: 'main',
      openPRs: mockData.openPRs?.length || 0,
      openIssues: mockData.openIssues?.length || 0
    },
    openPRs: mockData.openPRs || [],
    openIssues: mockData.openIssues || [],
    recentWorkflowRuns: mockData.recentWorkflowRuns || [],
    lastUpdated: new Date().toISOString()
  }
}
