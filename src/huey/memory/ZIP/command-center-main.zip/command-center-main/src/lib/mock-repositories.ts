import type { RepositoryHealth } from './github-types'

export const mockRepositories: RepositoryHealth[] = [
  {
    repo: {
      owner: 'DylanLRPollock',
      name: 'Monkey-Head-Project',
      fullName: 'DylanLRPollock/Monkey-Head-Project',
      description: 'Canonical HueyOS/runtime repository - core ML cognitive architecture',
      purpose: 'Canonical HueyOS/runtime repository - core ML cognitive architecture',
      role: 'Primary runtime and architecture hub',
      url: 'https://github.com/DylanLRPollock/Monkey-Head-Project',
      defaultBranch: 'main',
      openPRs: 2,
      openIssues: 5
    },
    phase: 'Phase 1',
    status: 'in-progress',
    openPRs: [
      {
        number: 42,
        title: 'Phase 1: HueyOS layout migration under src/huey',
        state: 'open',
        createdAt: '2025-01-15T10:30:00Z',
        updatedAt: '2025-01-16T14:20:00Z',
        author: 'DylanLRPollock',
        url: 'https://github.com/DylanLRPollock/Monkey-Head-Project/pull/42',
        draft: false,
        labels: ['migration', 'phase-1']
      },
      {
        number: 38,
        title: 'Add validation script for legacy imports',
        state: 'open',
        createdAt: '2025-01-12T09:15:00Z',
        updatedAt: '2025-01-14T16:45:00Z',
        author: 'DylanLRPollock',
        url: 'https://github.com/DylanLRPollock/Monkey-Head-Project/pull/38',
        draft: true,
        labels: ['tooling']
      }
    ],
    openIssues: [
      {
        number: 87,
        title: 'Plan Phase 2: Canonical import path strategy',
        state: 'open',
        createdAt: '2025-01-10T11:00:00Z',
        updatedAt: '2025-01-15T13:30:00Z',
        author: 'DylanLRPollock',
        url: 'https://github.com/DylanLRPollock/Monkey-Head-Project/issues/87',
        labels: ['planning', 'phase-2']
      }
    ],
    recentWorkflowRuns: [
      {
        id: 12345,
        name: 'CI',
        status: 'completed',
        conclusion: 'success',
        createdAt: '2025-01-16T15:30:00Z',
        url: 'https://github.com/DylanLRPollock/Monkey-Head-Project/actions/runs/12345'
      },
      {
        id: 12344,
        name: 'Lint',
        status: 'completed',
        conclusion: 'success',
        createdAt: '2025-01-16T15:25:00Z',
        url: 'https://github.com/DylanLRPollock/Monkey-Head-Project/actions/runs/12344'
      }
    ],
    lastUpdated: new Date().toISOString()
  },
  {
    repo: {
      owner: 'DylanLRPollock',
      name: 'PyHuey',
      fullName: 'DylanLRPollock/PyHuey',
      description: 'Cockpit/operator-side desktop fork for HueyOS',
      purpose: 'Cockpit/operator-side desktop fork for HueyOS',
      role: 'Operator interface and desktop tooling',
      url: 'https://github.com/DylanLRPollock/PyHuey',
      defaultBranch: 'main',
      openPRs: 1,
      openIssues: 3
    },
    phase: 'Phase 3',
    status: 'not-started',
    openPRs: [
      {
        number: 15,
        title: 'Update connector API documentation',
        state: 'open',
        createdAt: '2025-01-14T08:00:00Z',
        updatedAt: '2025-01-15T10:30:00Z',
        author: 'DylanLRPollock',
        url: 'https://github.com/DylanLRPollock/PyHuey/pull/15',
        draft: false,
        labels: ['documentation']
      }
    ],
    openIssues: [
      {
        number: 23,
        title: 'Rename package from pygpt_net to pyhuey',
        state: 'open',
        createdAt: '2025-01-08T14:00:00Z',
        updatedAt: '2025-01-12T09:20:00Z',
        author: 'DylanLRPollock',
        url: 'https://github.com/DylanLRPollock/PyHuey/issues/23',
        labels: ['breaking-change', 'phase-3']
      }
    ],
    recentWorkflowRuns: [
      {
        id: 98765,
        name: 'Tests',
        status: 'completed',
        conclusion: 'success',
        createdAt: '2025-01-15T11:00:00Z',
        url: 'https://github.com/DylanLRPollock/PyHuey/actions/runs/98765'
      }
    ],
    lastUpdated: new Date().toISOString()
  },
  {
    repo: {
      owner: 'DylanLRPollock',
      name: 'command-center',
      fullName: 'DylanLRPollock/command-center',
      description: 'Dashboard and migration tracker for Monkey-Head-Project ecosystem',
      purpose: 'Dashboard and migration tracker for Monkey-Head-Project ecosystem',
      role: 'Dashboard/prototype and project management',
      url: 'https://github.com/DylanLRPollock/command-center',
      defaultBranch: 'main',
      openPRs: 0,
      openIssues: 2
    },
    status: 'active',
    openPRs: [],
    openIssues: [
      {
        number: 5,
        title: 'Add GitHub API integration',
        state: 'open',
        createdAt: '2025-01-16T10:00:00Z',
        updatedAt: '2025-01-16T16:00:00Z',
        author: 'DylanLRPollock',
        url: 'https://github.com/DylanLRPollock/command-center/issues/5',
        labels: ['enhancement']
      }
    ],
    recentWorkflowRuns: [
      {
        id: 55555,
        name: 'Build',
        status: 'completed',
        conclusion: 'success',
        createdAt: '2025-01-16T16:15:00Z',
        url: 'https://github.com/DylanLRPollock/command-center/actions/runs/55555'
      }
    ],
    lastUpdated: new Date().toISOString()
  }
]
