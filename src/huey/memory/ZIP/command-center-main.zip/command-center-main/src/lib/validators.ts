import type { 
  MigrationData, 
  V1Run, 
  OperatorPanelData,
  Phase,
  PhaseStatus,
  RiskLevel,
  TranscriptionStatus,
  CognitionStatus,
  RunStatus,
  HealthStatus,
  LoopStatus,
  ConnectorStatus
} from './types'

export interface ValidationResult {
  isValid: boolean
  errors: string[]
}

export interface DependencySecurityBacklog {
  dependencies?: Array<{
    id: string
    package: string
    currentVersion: string
    latestVersion: string
    status: string
    severity: string
    updateRecommendation: string
    relatedPhases: string[]
  }>
  securityIssues?: Array<{
    id: string
    severity: string
    package: string
    vulnerability: string
    description: string
    affectedVersions: string
    fixedVersion: string
    recommendation: string
    status: string
    resolvedDate?: string
    relatedPhases: string[]
  }>
  technicalDebt?: Array<{
    id: string
    title: string
    description: string
    priority: string
    estimatedEffort: string
    impact: string
    relatedPhases: string[]
  }>
  testCoverage?: {
    overall: number
    byModule: Array<{
      module: string
      coverage: number
      status: string
    }>
    gaps: Array<{
      module: string
      missingTests: string[]
      priority: string
    }>
  }
  codeQuality?: {
    lintIssues: number
    formattingIssues: number
    complexityWarnings: number
    duplicateCode: number
    unusedImports: number
  }
}

export interface FullDashboardState {
  migrationData: MigrationData
  v1Runs: V1Run[]
  operatorPanelData: OperatorPanelData
  dependencyBacklog: DependencySecurityBacklog
}

const isValidPhaseStatus = (status: any): status is PhaseStatus => {
  return ['not-started', 'in-progress', 'blocked', 'ready', 'merged'].includes(status)
}

const isValidRiskLevel = (level: any): level is RiskLevel => {
  return ['low', 'medium', 'high'].includes(level)
}

const isValidTranscriptionStatus = (status: any): status is TranscriptionStatus => {
  return ['complete', 'error', 'pending'].includes(status)
}

const isValidCognitionStatus = (status: any): status is CognitionStatus => {
  return ['complete', 'error', 'pending'].includes(status)
}

const isValidRunStatus = (status: any): status is RunStatus => {
  return ['passed', 'failed', 'pending'].includes(status)
}

const isValidHealthStatus = (status: any): status is HealthStatus => {
  return ['healthy', 'degraded', 'down'].includes(status)
}

const isValidLoopStatus = (status: any): status is LoopStatus => {
  return ['running', 'paused', 'stopped', 'error'].includes(status)
}

const isValidConnectorStatus = (status: any): status is ConnectorStatus => {
  return ['connected', 'disconnected', 'error'].includes(status)
}

export function validateMigrationData(data: any): ValidationResult {
  const errors: string[] = []

  if (!data || typeof data !== 'object') {
    return { isValid: false, errors: ['Invalid data: must be an object'] }
  }

  if (!Array.isArray(data.phases)) {
    errors.push('Missing or invalid "phases" array')
  } else {
    data.phases.forEach((phase: any, index: number) => {
      if (!phase.id || typeof phase.id !== 'string') {
        errors.push(`Phase ${index}: missing or invalid "id"`)
      }
      if (!phase.name || typeof phase.name !== 'string') {
        errors.push(`Phase ${index}: missing or invalid "name"`)
      }
      if (!isValidPhaseStatus(phase.status)) {
        errors.push(`Phase ${index}: invalid "status" (must be: not-started, in-progress, blocked, ready, merged)`)
      }
      if (!isValidRiskLevel(phase.riskLevel)) {
        errors.push(`Phase ${index}: invalid "riskLevel" (must be: low, medium, high)`)
      }
      if (!Array.isArray(phase.risks)) {
        errors.push(`Phase ${index}: missing or invalid "risks" array`)
      }
      if (!Array.isArray(phase.checklist)) {
        errors.push(`Phase ${index}: missing or invalid "checklist" array`)
      }
      if (!Array.isArray(phase.validationCommands)) {
        errors.push(`Phase ${index}: missing or invalid "validationCommands" array`)
      }
    })
  }

  if (typeof data.globalNotes !== 'string') {
    errors.push('Missing or invalid "globalNotes" (must be a string)')
  }

  return {
    isValid: errors.length === 0,
    errors
  }
}

export function validateV1Runs(data: any): ValidationResult {
  const errors: string[] = []

  if (!Array.isArray(data)) {
    return { isValid: false, errors: ['Invalid data: must be an array of V1 runs'] }
  }

  data.forEach((run: any, index: number) => {
    if (!run.id || typeof run.id !== 'string') {
      errors.push(`Run ${index}: missing or invalid "id"`)
    }
    if (!run.timestamp || typeof run.timestamp !== 'string') {
      errors.push(`Run ${index}: missing or invalid "timestamp"`)
    }
    if (!run.fixtureFilename || typeof run.fixtureFilename !== 'string') {
      errors.push(`Run ${index}: missing or invalid "fixtureFilename"`)
    }
    if (!isValidTranscriptionStatus(run.transcriptionStatus)) {
      errors.push(`Run ${index}: invalid "transcriptionStatus" (must be: complete, error, pending)`)
    }
    if (!isValidCognitionStatus(run.cognitionStatus)) {
      errors.push(`Run ${index}: invalid "cognitionStatus" (must be: complete, error, pending)`)
    }
    if (!isValidRunStatus(run.result)) {
      errors.push(`Run ${index}: invalid "result" (must be: passed, failed, pending)`)
    }
    if (!run.rawJson || typeof run.rawJson !== 'object') {
      errors.push(`Run ${index}: missing or invalid "rawJson"`)
    }
  })

  return {
    isValid: errors.length === 0,
    errors
  }
}

export function validateOperatorPanelData(data: any): ValidationResult {
  const errors: string[] = []

  if (!data || typeof data !== 'object') {
    return { isValid: false, errors: ['Invalid data: must be an object'] }
  }

  if (!data.systemIdentity || typeof data.systemIdentity !== 'object') {
    errors.push('Missing or invalid "systemIdentity"')
  } else {
    if (!data.systemIdentity.instanceId) errors.push('systemIdentity: missing "instanceId"')
    if (!data.systemIdentity.version) errors.push('systemIdentity: missing "version"')
  }

  if (!data.apiHealth || typeof data.apiHealth !== 'object') {
    errors.push('Missing or invalid "apiHealth"')
  } else {
    if (!isValidHealthStatus(data.apiHealth.status)) {
      errors.push('apiHealth: invalid "status"')
    }
  }

  if (!data.proofLoop || typeof data.proofLoop !== 'object') {
    errors.push('Missing or invalid "proofLoop"')
  } else {
    if (!isValidLoopStatus(data.proofLoop.status)) {
      errors.push('proofLoop: invalid "status"')
    }
  }

  if (!data.memory || typeof data.memory !== 'object') {
    errors.push('Missing or invalid "memory"')
  } else {
    if (!isValidHealthStatus(data.memory.status)) {
      errors.push('memory: invalid "status"')
    }
  }

  if (!data.governance || typeof data.governance !== 'object') {
    errors.push('Missing or invalid "governance"')
  } else {
    if (!isValidHealthStatus(data.governance.status)) {
      errors.push('governance: invalid "status"')
    }
  }

  if (!Array.isArray(data.connectors)) {
    errors.push('Missing or invalid "connectors" array')
  } else {
    data.connectors.forEach((connector: any, index: number) => {
      if (!isValidConnectorStatus(connector.status)) {
        errors.push(`Connector ${index}: invalid "status"`)
      }
    })
  }

  if (!Array.isArray(data.recentLogs)) {
    errors.push('Missing or invalid "recentLogs" array')
  }

  return {
    isValid: errors.length === 0,
    errors
  }
}

export function validateDependencyBacklog(data: any): ValidationResult {
  const errors: string[] = []

  if (!data || typeof data !== 'object') {
    return { isValid: false, errors: ['Invalid data: must be an object'] }
  }

  if (data.dependencies && !Array.isArray(data.dependencies)) {
    errors.push('Invalid "dependencies" (must be an array)')
  }

  if (data.securityIssues && !Array.isArray(data.securityIssues)) {
    errors.push('Invalid "securityIssues" (must be an array)')
  }

  if (data.technicalDebt && !Array.isArray(data.technicalDebt)) {
    errors.push('Invalid "technicalDebt" (must be an array)')
  }

  return {
    isValid: errors.length === 0,
    errors
  }
}

export function validateFullDashboardState(data: any): ValidationResult {
  const errors: string[] = []

  if (!data || typeof data !== 'object') {
    return { isValid: false, errors: ['Invalid data: must be an object'] }
  }

  if (data.migrationData) {
    const migrationResult = validateMigrationData(data.migrationData)
    if (!migrationResult.isValid) {
      errors.push(...migrationResult.errors.map(e => `migrationData: ${e}`))
    }
  } else {
    errors.push('Missing "migrationData"')
  }

  if (data.v1Runs) {
    const v1RunsResult = validateV1Runs(data.v1Runs)
    if (!v1RunsResult.isValid) {
      errors.push(...v1RunsResult.errors.map(e => `v1Runs: ${e}`))
    }
  } else {
    errors.push('Missing "v1Runs"')
  }

  if (data.operatorPanelData) {
    const operatorResult = validateOperatorPanelData(data.operatorPanelData)
    if (!operatorResult.isValid) {
      errors.push(...operatorResult.errors.map(e => `operatorPanelData: ${e}`))
    }
  } else {
    errors.push('Missing "operatorPanelData"')
  }

  if (data.dependencyBacklog) {
    const backlogResult = validateDependencyBacklog(data.dependencyBacklog)
    if (!backlogResult.isValid) {
      errors.push(...backlogResult.errors.map(e => `dependencyBacklog: ${e}`))
    }
  } else {
    errors.push('Missing "dependencyBacklog"')
  }

  return {
    isValid: errors.length === 0,
    errors
  }
}
