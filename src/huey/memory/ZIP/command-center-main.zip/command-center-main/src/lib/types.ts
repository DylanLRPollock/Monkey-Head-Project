export type PhaseStatus = 'not-started' | 'in-progress' | 'blocked' | 'ready' | 'merged'
export type RiskLevel = 'low' | 'medium' | 'high'

export interface ChecklistItem {
  id: string
  text: string
  completed: boolean
}

export interface Risk {
  id: string
  description: string
  level: RiskLevel
  mitigation?: string
}

export interface Phase {
  id: string
  name: string
  description: string
  status: PhaseStatus
  riskLevel: RiskLevel
  risks: Risk[]
  checklist: ChecklistItem[]
  validationCommands: string[]
  notes: string
}

export interface MigrationData {
  phases: Phase[]
  globalNotes: string
}

export type RunStatus = 'passed' | 'failed' | 'pending'
export type TranscriptionStatus = 'complete' | 'error' | 'pending'
export type CognitionStatus = 'complete' | 'error' | 'pending'

export interface V1Run {
  id: string
  timestamp: string
  fixtureFilename: string
  transcriptionStatus: TranscriptionStatus
  transcriptionText?: string
  transcriptionError?: string
  cognitionStatus: CognitionStatus
  cognitionResponse?: string
  cognitionError?: string
  result: RunStatus
  errorDetails?: string
  rawJson: Record<string, any>
}

export type HealthStatus = 'healthy' | 'degraded' | 'down'
export type LoopStatus = 'running' | 'paused' | 'stopped' | 'error'
export type ConnectorStatus = 'connected' | 'disconnected' | 'error'

export interface SystemIdentity {
  instanceId: string
  version: string
  environment: string
  uptime: number
  hostname: string
}

export interface APIHealth {
  status: HealthStatus
  lastCheck: string
  responseTime: number
  endpoints: {
    name: string
    status: HealthStatus
    responseTime: number
  }[]
}

export interface ProofLoopStatus {
  status: LoopStatus
  currentRun?: string
  totalRuns: number
  successRate: number
  lastRunTime: string
  errorCount: number
}

export interface MemoryStatus {
  status: HealthStatus
  totalEntries: number
  recentWrites: number
  lastSync: string
  storageUsed: number
  storageLimit: number
}

export interface GovernanceStatus {
  status: HealthStatus
  activeRules: number
  violations: number
  lastAudit: string
  emergencyMode: boolean
}

export interface Connector {
  id: string
  name: string
  status: ConnectorStatus
  lastPing: string
  messageCount: number
}

export interface LogEntry {
  id: string
  timestamp: string
  level: 'info' | 'warn' | 'error' | 'debug'
  source: string
  message: string
}

export interface OperatorPanelData {
  systemIdentity: SystemIdentity
  apiHealth: APIHealth
  proofLoop: ProofLoopStatus
  memory: MemoryStatus
  governance: GovernanceStatus
  connectors: Connector[]
  recentLogs: LogEntry[]
}
