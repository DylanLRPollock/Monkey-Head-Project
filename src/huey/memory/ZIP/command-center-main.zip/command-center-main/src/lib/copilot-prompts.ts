import type { Phase } from './types'

export interface CopilotPrompt {
  objective: string
  repo: string
  branch: string
  filesInvolved: string[]
  doNotTouch: string[]
  validationCommands: string[]
  prTitle: string
  prBody: string
}

export function generateCopilotPrompt(phase: Phase, repo: string): CopilotPrompt {
  const phasePrompts: Record<string, Partial<CopilotPrompt>> = {
    'phase-1': {
      objective: 'Move all HueyOS-related code from legacy paths into the new src/huey directory structure',
      repo: 'DylanLRPollock/Monkey-Head-Project',
      branch: 'feature/phase-1-huey-layout-migration',
      filesInvolved: [
        'src/huey/**/*',
        'tests/huey/**/*',
        'scripts/check_stale_platform_strings.py',
        'scripts/check_repo_drift.py'
      ],
      doNotTouch: [
        'src/huey/connectors/pyhuey/**/*',
        'legacy compatibility shims',
        'external API contracts',
        'production configuration files'
      ],
      prTitle: 'Phase 1: HueyOS layout migration under src/huey',
      prBody: `## Objective
Move all HueyOS-related code from legacy paths into the new src/huey directory structure.

## Changes
- Created src/huey directory structure
- Moved core HueyOS modules to src/huey
- Updated internal imports within moved modules
- Added tests for migrated code

## Validation
- [ ] All validation commands pass
- [ ] No stale platform strings
- [ ] No repository drift detected
- [ ] Full test suite passes

## Risks
- Import path conflicts during transition (mitigated with compatibility shims)
- Test coverage gaps in moved modules (mitigated with full test suite)

## Next Steps
- Phase 2: Establish huey.os canonical import path`
    },
    'phase-2': {
      objective: 'Establish huey.os as the canonical import path while maintaining backward compatibility through shims',
      repo: 'DylanLRPollock/Monkey-Head-Project',
      branch: 'feature/phase-2-canonical-import-path',
      filesInvolved: [
        'src/huey/__init__.py',
        'src/hueyos/**/* (compatibility shims)',
        'scripts/check_legacy_hueyos_imports.py',
        'docs/migration-guide.md'
      ],
      doNotTouch: [
        'src/huey/core functionality',
        'external consumer code',
        'production imports until shims verified'
      ],
      prTitle: 'Phase 2: huey.os canonical import path with compatibility shims',
      prBody: `## Objective
Establish huey.os as the canonical import path while maintaining backward compatibility.

## Changes
- Implemented compatibility shim architecture
- Created hueyos → huey.os redirect layer
- Added deprecation warnings to legacy imports
- Updated internal consumers to use new path
- Tested shim with production scenarios
- Updated migration guide documentation

## Validation
- [ ] Legacy imports still work via shims
- [ ] Deprecation warnings appear correctly
- [ ] No legacy import usage in new code
- [ ] Full test suite passes

## Risks
- Breaking changes for external consumers (mitigated with shims for 2+ releases)
- Shim performance overhead (profiled and optimized)

## Next Steps
- Phase 2.5: Move PyHuey connector to dedicated directory`
    },
    'phase-2.5': {
      objective: 'Reorganize connector code into dedicated connectors subdirectory',
      repo: 'DylanLRPollock/Monkey-Head-Project',
      branch: 'feature/phase-2.5-pyhuey-connector-path',
      filesInvolved: [
        'src/huey/connectors/__init__.py',
        'src/huey/connectors/pyhuey/**/*',
        'src/huey/pygpt_net/**/* (move from here)',
        'tests/huey/connectors/**/*'
      ],
      doNotTouch: [
        'PyHuey external package code',
        'other connector implementations',
        'huey core modules'
      ],
      prTitle: 'Phase 2.5: Move PyHuey connector to src/huey/connectors/pyhuey',
      prBody: `## Objective
Reorganize connector code into dedicated connectors subdirectory.

## Changes
- Created src/huey/connectors directory
- Moved src/huey/pygpt_net to src/huey/connectors/pyhuey
- Updated import paths in connector tests
- Verified connector functionality

## Validation
- [ ] Connector tests pass
- [ ] Import paths updated correctly
- [ ] No broken references

## Next Steps
- Phase 3: Rename PyHuey repo package from pygpt_net to pyhuey`
    },
    'phase-3': {
      objective: 'Rename PyHuey repository package from pygpt_net to pyhuey',
      repo: 'DylanLRPollock/PyHuey',
      branch: 'feature/phase-3-rename-package-to-pyhuey',
      filesInvolved: [
        'pyproject.toml',
        'setup.py',
        'pyhuey/**/* (renamed from pygpt_net)',
        'tests/**/*',
        'README.md',
        'docs/**/*'
      ],
      doNotTouch: [
        'Monkey-Head-Project connector references (update separately)',
        'external API contracts',
        'production deployments until verified'
      ],
      prTitle: 'Phase 3: Rename package from pygpt_net to pyhuey',
      prBody: `## Objective
Rename PyHuey repository package from pygpt_net to pyhuey.

## Changes
- Renamed package directory pygpt_net → pyhuey
- Updated pyproject.toml and setup.py
- Updated all internal imports
- Updated documentation and README
- Verified package builds and installs correctly

## Validation
- [ ] poetry check passes
- [ ] Package installs as pyhuey
- [ ] Import tests pass: import pyhuey, pyhuey.app
- [ ] All tests pass

## Risks
- Breaking change for consumers (coordinate deployment)
- Requires synchronized update in Monkey-Head-Project

## Next Steps
- Update Monkey-Head-Project connector to import from pyhuey
- Phase 4: Remove compatibility shims`
    },
    'phase-4': {
      objective: 'Remove compatibility shims after downstream migration complete',
      repo: 'DylanLRPollock/Monkey-Head-Project',
      branch: 'feature/phase-4-remove-compat-shims',
      filesInvolved: [
        'src/hueyos/**/* (remove shims)',
        'scripts/check_legacy_hueyos_imports.py',
        'docs/changelog.md'
      ],
      doNotTouch: [
        'src/huey core modules',
        'active production code',
        'external integrations'
      ],
      prTitle: 'Phase 4: Remove compatibility shims',
      prBody: `## Objective
Remove compatibility shims after all downstream consumers migrated.

## Changes
- Removed hueyos compatibility shim layer
- Updated legacy import checker to enforce new paths
- Updated changelog with breaking change notice
- Verified no legacy imports remain

## Validation
- [ ] No legacy imports detected
- [ ] All tests pass with shims removed
- [ ] Downstream consumers verified migrated

## Next Steps
- Phase 5: Integrate V1 proof-loop dashboard`
    }
  }

  const promptData = phasePrompts[phase.id] || {}

  return {
    objective: promptData.objective || phase.description,
    repo: promptData.repo || repo,
    branch: promptData.branch || `feature/${phase.id}`,
    filesInvolved: promptData.filesInvolved || [],
    doNotTouch: promptData.doNotTouch || [],
    validationCommands: phase.validationCommands || [],
    prTitle: promptData.prTitle || phase.name,
    prBody: promptData.prBody || phase.description
  }
}

export function formatCopilotPromptForCopy(prompt: CopilotPrompt): string {
  return `# ${prompt.prTitle}

## Objective
${prompt.objective}

## Repository
${prompt.repo}

## Branch
${prompt.branch}

## Files Likely Involved
${prompt.filesInvolved.map(f => `- ${f}`).join('\n')}

## Do Not Touch
${prompt.doNotTouch.map(f => `- ${f}`).join('\n')}

## Validation Commands
${prompt.validationCommands.map(c => `\`\`\`bash\n${c}\n\`\`\``).join('\n\n')}

## PR Title
${prompt.prTitle}

## PR Body
${prompt.prBody}
`
}

export function generateNextBestTask(phases: Phase[]): string {
  const nextPhase = phases.find(p => p.status === 'not-started' && p.riskLevel !== 'high') ||
    phases.find(p => p.status === 'not-started')

  if (!nextPhase) {
    return 'All phases are in progress or completed. Review blocked or in-progress phases.'
  }

  const prompt = generateCopilotPrompt(nextPhase, 'DylanLRPollock/Monkey-Head-Project')
  return formatCopilotPromptForCopy(prompt)
}
