import type { MigrationData, V1Run, OperatorPanelData } from './types'
import type { DependencySecurityBacklog } from './validators'

export const initialMigrationData: MigrationData = {
  phases: [
    {
      id: 'phase-1',
      name: 'Phase 1: HueyOS layout migration under src/huey',
      description: 'Move all HueyOS-related code from legacy paths into the new src/huey directory structure',
      status: 'in-progress',
      riskLevel: 'medium',
      risks: [
        {
          id: 'risk-1-1',
          level: 'medium',
          description: 'Import path conflicts during transition',
          mitigation: 'Use compatibility shims and gradual rollout'
        },
        {
          id: 'risk-1-2',
          level: 'low',
          description: 'Test coverage gaps in moved modules',
          mitigation: 'Run full test suite after each major move'
        }
      ],
      checklist: [
        { id: 'check-1-1', text: 'Create src/huey directory structure', completed: true },
        { id: 'check-1-2', text: 'Move core HueyOS modules to src/huey', completed: true },
        { id: 'check-1-3', text: 'Update internal imports within moved modules', completed: false },
        { id: 'check-1-4', text: 'Run validation suite', completed: false },
        { id: 'check-1-5', text: 'Update documentation with new paths', completed: false }
      ],
      validationCommands: [
        'python scripts/check_stale_platform_strings.py',
        'python -m pytest -q tests/huey/'
      ],
      notes: 'Currently working on updating imports. Need to coordinate with team on timing.'
    },
    {
      id: 'phase-2',
      name: 'Phase 2: huey.os canonical import path and hueyos compatibility shim',
      description: 'Establish huey.os as the canonical import path while maintaining backward compatibility through shims',
      status: 'not-started',
      riskLevel: 'high',
      risks: [
        {
          id: 'risk-2-1',
          level: 'high',
          description: 'Breaking changes for external consumers',
          mitigation: 'Maintain compatibility shims for at least 2 releases'
        },
        {
          id: 'risk-2-2',
          level: 'medium',
          description: 'Shim performance overhead',
          mitigation: 'Profile import times and optimize critical paths'
        }
      ],
      checklist: [
        { id: 'check-2-1', text: 'Design compatibility shim architecture', completed: false },
        { id: 'check-2-2', text: 'Implement hueyos → huey.os redirect layer', completed: false },
        { id: 'check-2-3', text: 'Add deprecation warnings to legacy imports', completed: false },
        { id: 'check-2-4', text: 'Update all internal consumers to use new path', completed: false },
        { id: 'check-2-5', text: 'Test shim with production scenarios', completed: false },
        { id: 'check-2-6', text: 'Update migration guide documentation', completed: false }
      ],
      validationCommands: [
        'python scripts/check_legacy_hueyos_imports.py',
        'python -m pytest -q'
      ],
      notes: ''
    },
    {
      id: 'phase-2.5',
      name: 'Phase 2.5: move src/huey/pygpt_net to src/huey/connectors/pyhuey',
      description: 'Reorganize connector code into dedicated connectors subdirectory',
      status: 'not-started',
      riskLevel: 'low',
      risks: [
        {
          id: 'risk-2.5-1',
          level: 'low',
          description: 'Connector import path updates needed',
          mitigation: 'Update references in single atomic commit'
        }
      ],
      checklist: [
        { id: 'check-2.5-1', text: 'Create src/huey/connectors directory', completed: false },
        { id: 'check-2.5-2', text: 'Move pygpt_net to connectors/pyhuey', completed: false },
        { id: 'check-2.5-3', text: 'Update import paths in connector tests', completed: false },
        { id: 'check-2.5-4', text: 'Verify connector functionality', completed: false }
      ],
      validationCommands: [
        'python -m pytest -q tests/huey/connectors/'
      ],
      notes: ''
    },
    {
      id: 'phase-3',
      name: 'Phase 3: rename PyHuey repo package pygpt_net to pyhuey',
      description: 'Final package rename to align naming with new architecture',
      status: 'not-started',
      riskLevel: 'high',
      risks: [
        {
          id: 'risk-3-1',
          level: 'high',
          description: 'PyPI package name collision or confusion',
          mitigation: 'Reserve package name early, coordinate release announcement'
        },
        {
          id: 'risk-3-2',
          level: 'high',
          description: 'Downstream dependency breakage',
          mitigation: 'Maintain pygpt_net as deprecated alias package for 6 months'
        },
        {
          id: 'risk-3-3',
          level: 'medium',
          description: 'CI/CD pipeline updates required',
          mitigation: 'Update all build scripts and deployment configs before release'
        }
      ],
      checklist: [
        { id: 'check-3-1', text: 'Reserve pyhuey package name on PyPI', completed: false },
        { id: 'check-3-2', text: 'Update setup.py/pyproject.toml', completed: false },
        { id: 'check-3-3', text: 'Update all import statements', completed: false },
        { id: 'check-3-4', text: 'Create pygpt_net → pyhuey alias package', completed: false },
        { id: 'check-3-5', text: 'Update CI/CD configurations', completed: false },
        { id: 'check-3-6', text: 'Update README and documentation', completed: false },
        { id: 'check-3-7', text: 'Prepare migration announcement', completed: false },
        { id: 'check-3-8', text: 'Run full validation suite', completed: false }
      ],
      validationCommands: [
        'python scripts/check_repo_drift.py',
        'python -m black --check src tests scripts conftest.py',
        'python -m isort --check-only src tests scripts conftest.py',
        'python -m ruff check src tests scripts conftest.py',
        'python -m flake8 --exclude=src/huey/connectors/pyhuey src tests scripts conftest.py',
        'python -m pytest -q'
      ],
      notes: ''
    }
  ],
  globalNotes: 'Migration started Q1 2024. Target completion: Q2 2024.\n\nKey stakeholders: Dev team, QA, Technical writing.\n\nRelated docs: /docs/architecture/huey-migration.md'
}

export const allValidationCommands = [
  'python scripts/check_stale_platform_strings.py',
  'python scripts/check_repo_drift.py',
  'python scripts/check_legacy_hueyos_imports.py',
  'python -m black --check src tests scripts conftest.py',
  'python -m isort --check-only src tests scripts conftest.py',
  'python -m ruff check src tests scripts conftest.py',
  'python -m flake8 --exclude=src/huey/connectors/pyhuey src tests scripts conftest.py',
  'python -m pytest -q'
]

export const mockV1Runs: V1Run[] = [
  {
    id: 'run-001',
    timestamp: '2024-01-15T14:23:45.123Z',
    fixtureFilename: 'test_hello_world.mp3',
    transcriptionStatus: 'complete',
    transcriptionText: 'Hello Huey, please turn on the lights.',
    cognitionStatus: 'complete',
    cognitionResponse: 'Understood. Turning on lights in living room.',
    result: 'passed',
    rawJson: {
      fixture: 'test_hello_world.mp3',
      transcription: { text: 'Hello Huey, please turn on the lights.', confidence: 0.98 },
      cognition: { intent: 'light_control', action: 'turn_on', target: 'living_room' },
      result: 'passed'
    }
  },
  {
    id: 'run-002',
    timestamp: '2024-01-15T14:24:12.456Z',
    fixtureFilename: 'test_weather_query.mp3',
    transcriptionStatus: 'complete',
    transcriptionText: 'What is the weather like today?',
    cognitionStatus: 'complete',
    cognitionResponse: 'The current weather is sunny with a temperature of 72°F.',
    result: 'passed',
    rawJson: {
      fixture: 'test_weather_query.mp3',
      transcription: { text: 'What is the weather like today?', confidence: 0.95 },
      cognition: { intent: 'weather_query', location: 'current' },
      result: 'passed'
    }
  },
  {
    id: 'run-003',
    timestamp: '2024-01-15T14:25:03.789Z',
    fixtureFilename: 'test_garbled_audio.mp3',
    transcriptionStatus: 'error',
    transcriptionError: 'Audio quality too low - SNR below threshold',
    cognitionStatus: 'pending',
    result: 'failed',
    errorDetails: 'Transcription failed: insufficient audio quality',
    rawJson: {
      fixture: 'test_garbled_audio.mp3',
      transcription: { error: 'Audio quality too low - SNR below threshold' },
      result: 'failed'
    }
  },
  {
    id: 'run-004',
    timestamp: '2024-01-15T14:26:34.012Z',
    fixtureFilename: 'test_timer_command.mp3',
    transcriptionStatus: 'complete',
    transcriptionText: 'Set a timer for 5 minutes.',
    cognitionStatus: 'complete',
    cognitionResponse: 'Timer set for 5 minutes starting now.',
    result: 'passed',
    rawJson: {
      fixture: 'test_timer_command.mp3',
      transcription: { text: 'Set a timer for 5 minutes.', confidence: 0.97 },
      cognition: { intent: 'timer', duration: 300 },
      result: 'passed'
    }
  },
  {
    id: 'run-005',
    timestamp: '2024-01-15T14:27:45.234Z',
    fixtureFilename: 'test_ambiguous_query.mp3',
    transcriptionStatus: 'complete',
    transcriptionText: 'Turn it on.',
    cognitionStatus: 'error',
    cognitionError: 'Ambiguous reference - unable to resolve "it"',
    result: 'failed',
    errorDetails: 'Cognition failed: ambiguous pronoun reference',
    rawJson: {
      fixture: 'test_ambiguous_query.mp3',
      transcription: { text: 'Turn it on.', confidence: 0.99 },
      cognition: { error: 'Ambiguous reference - unable to resolve "it"' },
      result: 'failed'
    }
  },
  {
    id: 'run-006',
    timestamp: '2024-01-15T14:28:56.567Z',
    fixtureFilename: 'test_music_control.mp3',
    transcriptionStatus: 'complete',
    transcriptionText: 'Play some jazz music.',
    cognitionStatus: 'complete',
    cognitionResponse: 'Playing jazz playlist on default speaker.',
    result: 'passed',
    rawJson: {
      fixture: 'test_music_control.mp3',
      transcription: { text: 'Play some jazz music.', confidence: 0.96 },
      cognition: { intent: 'music_control', action: 'play', genre: 'jazz' },
      result: 'passed'
    }
  },
  {
    id: 'run-007',
    timestamp: '2024-01-15T14:30:12.890Z',
    fixtureFilename: 'test_empty_audio.mp3',
    transcriptionStatus: 'error',
    transcriptionError: 'No speech detected in audio file',
    cognitionStatus: 'pending',
    result: 'failed',
    errorDetails: 'Transcription failed: no speech detected',
    rawJson: {
      fixture: 'test_empty_audio.mp3',
      transcription: { error: 'No speech detected in audio file' },
      result: 'failed'
    }
  },
  {
    id: 'run-008',
    timestamp: '2024-01-15T14:31:23.123Z',
    fixtureFilename: 'test_complex_command.mp3',
    transcriptionStatus: 'complete',
    transcriptionText: 'Turn off the lights in the bedroom and set the thermostat to 68 degrees.',
    cognitionStatus: 'complete',
    cognitionResponse: 'Executed: lights off in bedroom, thermostat set to 68°F.',
    result: 'passed',
    rawJson: {
      fixture: 'test_complex_command.mp3',
      transcription: {
        text: 'Turn off the lights in the bedroom and set the thermostat to 68 degrees.',
        confidence: 0.94
      },
      cognition: {
        intents: [
          { intent: 'light_control', action: 'turn_off', target: 'bedroom' },
          { intent: 'thermostat_control', temperature: 68 }
        ]
      },
      result: 'passed'
    }
  },
  {
    id: 'run-009',
    timestamp: '2024-01-15T14:32:45.456Z',
    fixtureFilename: 'test_unknown_command.mp3',
    transcriptionStatus: 'complete',
    transcriptionText: 'Make me a sandwich.',
    cognitionStatus: 'error',
    cognitionError: 'Intent not recognized: food preparation not supported',
    result: 'failed',
    errorDetails: 'Cognition failed: unsupported intent category',
    rawJson: {
      fixture: 'test_unknown_command.mp3',
      transcription: { text: 'Make me a sandwich.', confidence: 0.98 },
      cognition: { error: 'Intent not recognized: food preparation not supported' },
      result: 'failed'
    }
  },
  {
    id: 'run-010',
    timestamp: '2024-01-15T14:33:56.789Z',
    fixtureFilename: 'test_reminder.mp3',
    transcriptionStatus: 'complete',
    transcriptionText: 'Remind me to call mom at 3 PM.',
    cognitionStatus: 'complete',
    cognitionResponse: 'Reminder set for 3:00 PM today: call mom.',
    result: 'passed',
    rawJson: {
      fixture: 'test_reminder.mp3',
      transcription: { text: 'Remind me to call mom at 3 PM.', confidence: 0.96 },
      cognition: { intent: 'reminder', time: '15:00', task: 'call mom' },
      result: 'passed'
    }
  },
  {
    id: 'run-011',
    timestamp: '2024-01-15T14:35:12.012Z',
    fixtureFilename: 'test_pending_run.mp3',
    transcriptionStatus: 'pending',
    cognitionStatus: 'pending',
    result: 'pending',
    rawJson: {
      fixture: 'test_pending_run.mp3',
      status: 'processing'
    }
  },
  {
    id: 'run-012',
    timestamp: '2024-01-15T14:36:23.345Z',
    fixtureFilename: 'test_volume_control.mp3',
    transcriptionStatus: 'complete',
    transcriptionText: 'Volume up please.',
    cognitionStatus: 'complete',
    cognitionResponse: 'Volume increased by 10%.',
    result: 'passed',
    rawJson: {
      fixture: 'test_volume_control.mp3',
      transcription: { text: 'Volume up please.', confidence: 0.97 },
      cognition: { intent: 'volume_control', action: 'increase', amount: 10 },
      result: 'passed'
    }
  }
]

export const mockOperatorPanelData: OperatorPanelData = {
  systemIdentity: {
    instanceId: 'huey-dev-001',
    version: 'v0.3.2-alpha',
    environment: 'development',
    uptime: 3847200,
    hostname: 'localhost:8080'
  },
  apiHealth: {
    status: 'healthy',
    lastCheck: new Date().toISOString(),
    responseTime: 42,
    endpoints: [
      { name: '/api/health', status: 'healthy', responseTime: 15 },
      { name: '/api/transcribe', status: 'healthy', responseTime: 89 },
      { name: '/api/cognition', status: 'healthy', responseTime: 124 },
      { name: '/api/memory', status: 'degraded', responseTime: 342 }
    ]
  },
  proofLoop: {
    status: 'running',
    currentRun: 'run-015',
    totalRuns: 847,
    successRate: 87.3,
    lastRunTime: new Date(Date.now() - 45000).toISOString(),
    errorCount: 12
  },
  memory: {
    status: 'healthy',
    totalEntries: 2847,
    recentWrites: 23,
    lastSync: new Date(Date.now() - 120000).toISOString(),
    storageUsed: 1.2,
    storageLimit: 10.0
  },
  governance: {
    status: 'healthy',
    activeRules: 47,
    violations: 2,
    lastAudit: new Date(Date.now() - 3600000).toISOString(),
    emergencyMode: false
  },
  connectors: [
    {
      id: 'conn-001',
      name: 'PyHuey Connector',
      status: 'connected',
      lastPing: new Date(Date.now() - 5000).toISOString(),
      messageCount: 1247
    },
    {
      id: 'conn-002',
      name: 'Local Audio Interface',
      status: 'connected',
      lastPing: new Date(Date.now() - 8000).toISOString(),
      messageCount: 3891
    },
    {
      id: 'conn-003',
      name: 'External API Gateway',
      status: 'disconnected',
      lastPing: new Date(Date.now() - 300000).toISOString(),
      messageCount: 45
    },
    {
      id: 'conn-004',
      name: 'Smart Home Bridge',
      status: 'connected',
      lastPing: new Date(Date.now() - 3000).toISOString(),
      messageCount: 892
    }
  ],
  recentLogs: [
    {
      id: 'log-001',
      timestamp: new Date(Date.now() - 5000).toISOString(),
      level: 'info',
      source: 'proof-loop',
      message: 'Run completed successfully: run-014'
    },
    {
      id: 'log-002',
      timestamp: new Date(Date.now() - 12000).toISOString(),
      level: 'warn',
      source: 'memory',
      message: 'Slow write detected: 342ms latency on entry update'
    },
    {
      id: 'log-003',
      timestamp: new Date(Date.now() - 18000).toISOString(),
      level: 'error',
      source: 'connector',
      message: 'External API Gateway connection timeout after 30s'
    },
    {
      id: 'log-004',
      timestamp: new Date(Date.now() - 25000).toISOString(),
      level: 'info',
      source: 'api',
      message: 'Health check passed for all critical endpoints'
    },
    {
      id: 'log-005',
      timestamp: new Date(Date.now() - 35000).toISOString(),
      level: 'debug',
      source: 'governance',
      message: 'Rule evaluation complete: 47 rules checked, 2 violations found'
    },
    {
      id: 'log-006',
      timestamp: new Date(Date.now() - 42000).toISOString(),
      level: 'info',
      source: 'transcription',
      message: 'Audio transcription completed in 89ms'
    },
    {
      id: 'log-007',
      timestamp: new Date(Date.now() - 55000).toISOString(),
      level: 'warn',
      source: 'cognition',
      message: 'Ambiguous intent detected, requesting clarification'
    },
    {
      id: 'log-008',
      timestamp: new Date(Date.now() - 68000).toISOString(),
      level: 'info',
      source: 'memory',
      message: 'Background sync completed: 23 entries synchronized'
    }
  ]
}

export const mockDependencyBacklog: DependencySecurityBacklog = {
  dependencies: [
    {
      id: 'dep-001',
      package: 'openai-whisper',
      currentVersion: '1.2.3',
      latestVersion: '1.3.0',
      status: 'outdated',
      severity: 'low',
      updateRecommendation: 'Non-breaking update available with performance improvements',
      relatedPhases: ['phase-1']
    },
    {
      id: 'dep-002',
      package: 'transformers',
      currentVersion: '4.30.2',
      latestVersion: '4.35.1',
      status: 'outdated',
      severity: 'medium',
      updateRecommendation: 'Security patch available, update recommended before Phase 2',
      relatedPhases: ['phase-2']
    },
    {
      id: 'dep-003',
      package: 'fastapi',
      currentVersion: '0.95.1',
      latestVersion: '0.104.0',
      status: 'outdated',
      severity: 'low',
      updateRecommendation: 'Feature updates available, not critical',
      relatedPhases: []
    }
  ],
  securityIssues: [
    {
      id: 'sec-001',
      severity: 'high',
      package: 'requests',
      vulnerability: 'CVE-2023-XXXXX',
      description: 'Server-Side Request Forgery (SSRF) vulnerability in URL parsing',
      affectedVersions: '< 2.31.0',
      fixedVersion: '2.31.0',
      recommendation: 'Update to 2.31.0 or later immediately',
      status: 'open',
      relatedPhases: ['phase-1', 'phase-2']
    },
    {
      id: 'sec-002',
      severity: 'medium',
      package: 'pillow',
      vulnerability: 'CVE-2023-YYYYY',
      description: 'Buffer overflow in image processing',
      affectedVersions: '< 10.0.1',
      fixedVersion: '10.0.1',
      recommendation: 'Update if processing untrusted images',
      status: 'open',
      relatedPhases: []
    },
    {
      id: 'sec-003',
      severity: 'low',
      package: 'urllib3',
      vulnerability: 'CVE-2023-ZZZZZ',
      description: 'Cookie leak in redirect handling',
      affectedVersions: '< 1.26.15',
      fixedVersion: '1.26.15',
      recommendation: 'Update when convenient',
      status: 'resolved',
      resolvedDate: '2024-01-10',
      relatedPhases: []
    }
  ],
  technicalDebt: [
    {
      id: 'debt-001',
      title: 'Legacy import paths in test suite',
      description: 'Test files still using old import paths for HueyOS modules',
      priority: 'high',
      estimatedEffort: '2-3 days',
      impact: 'Blocks Phase 1 completion',
      relatedPhases: ['phase-1']
    },
    {
      id: 'debt-002',
      title: 'Missing type hints in connector modules',
      description: 'PyHuey connector code lacks comprehensive type annotations',
      priority: 'medium',
      estimatedEffort: '1 week',
      impact: 'Reduces code maintainability, complicates refactoring',
      relatedPhases: ['phase-2.5']
    },
    {
      id: 'debt-003',
      title: 'Outdated documentation for API endpoints',
      description: 'API documentation hasn\'t been updated since v0.2',
      priority: 'medium',
      estimatedEffort: '1-2 days',
      impact: 'Confuses new contributors',
      relatedPhases: []
    }
  ],
  testCoverage: {
    overall: 78.5,
    byModule: [
      { module: 'src.huey.core', coverage: 92.3, status: 'excellent' },
      { module: 'src.huey.connectors', coverage: 65.7, status: 'needs_improvement' },
      { module: 'src.huey.memory', coverage: 88.1, status: 'good' },
      { module: 'src.huey.governance', coverage: 71.4, status: 'acceptable' }
    ],
    gaps: [
      {
        module: 'src.huey.connectors.pyhuey',
        missingTests: ['error handling', 'timeout scenarios', 'reconnection logic'],
        priority: 'high'
      }
    ]
  },
  codeQuality: {
    lintIssues: 23,
    formattingIssues: 7,
    complexityWarnings: 5,
    duplicateCode: 3,
    unusedImports: 12
  }
}
