export interface GitHubRepository {
  owner: string
  name: string
  fullName: string
  description: string
  purpose: string
  role: string
  url: string
  defaultBranch: string
  openPRs: number
  openIssues: number
  lastCommitSha?: string
  lastCommitMessage?: string
  lastCommitDate?: string
  latestWorkflowRun?: WorkflowRun
}

export interface PullRequest {
  number: number
  title: string
  state: 'open' | 'closed' | 'merged'
  createdAt: string
  updatedAt: string
  author: string
  url: string
  draft: boolean
  labels: string[]
}

export interface Issue {
  number: number
  title: string
  state: 'open' | 'closed'
  createdAt: string
  updatedAt: string
  author: string
  url: string
  labels: string[]
}

export interface WorkflowRun {
  id: number
  name: string
  status: 'queued' | 'in_progress' | 'completed'
  conclusion?: 'success' | 'failure' | 'cancelled' | 'skipped'
  createdAt: string
  url: string
}

export interface GitHubSettings {
  token?: string
  enabled: boolean
}

export interface RepositoryHealth {
  repo: GitHubRepository
  phase?: string
  status?: string
  openPRs: PullRequest[]
  openIssues: Issue[]
  recentWorkflowRuns: WorkflowRun[]
  lastUpdated: string
}
