import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  GitBranch, 
  Desktop, 
  ChartLine, 
  Globe,
  CheckCircle,
  XCircle,
  Link as LinkIcon
} from '@phosphor-icons/react'

type MaturityLevel = 'prototype' | 'active-development' | 'stable' | 'production'

interface ProjectCard {
  id: string
  name: string
  icon: React.ReactNode
  role: string
  belongsHere: string[]
  doesNotBelong: string[]
  repoLink: string
  maturityLevel: MaturityLevel
  maturityColor: string
}

const projects: ProjectCard[] = [
  {
    id: 'monkey-head',
    name: 'Monkey-Head-Project',
    icon: <GitBranch size={24} weight="bold" />,
    role: 'Canonical HueyOS runtime and umbrella repository',
    belongsHere: [
      'HueyOS core runtime code',
      'Brain/cognition engine',
      'Connector architecture',
      'Memory systems',
      'Governance systems',
      'Integration tests',
      'Production deployment configs'
    ],
    doesNotBelong: [
      'Dashboard/UI prototypes',
      'Operator cockpit forks',
      'Public-facing marketing sites',
      'Experimental UI tools'
    ],
    repoLink: 'https://github.com/[owner]/monkey-head-project',
    maturityLevel: 'active-development',
    maturityColor: 'bg-chart-2 text-foreground'
  },
  {
    id: 'pyhuey',
    name: 'PyHuey',
    icon: <Desktop size={24} weight="bold" />,
    role: 'Desktop cockpit and operator-side control fork',
    belongsHere: [
      'Operator interface code',
      'Desktop UI components',
      'Control panel logic',
      'Local system integrations',
      'Operator-specific tooling',
      'Desktop packaging configs'
    ],
    doesNotBelong: [
      'HueyOS core runtime',
      'Web dashboard code',
      'Migration tracking tools',
      'Public documentation sites'
    ],
    repoLink: 'https://github.com/[owner]/pyhuey',
    maturityLevel: 'prototype',
    maturityColor: 'bg-muted text-muted-foreground'
  },
  {
    id: 'migration-center',
    name: 'HueyOS Migration Command Center',
    icon: <ChartLine size={24} weight="bold" />,
    role: 'Dashboard prototype and migration tracking companion',
    belongsHere: [
      'Migration phase tracking UI',
      'V1 proof-loop run viewer',
      'Operator panel mockups',
      'Dashboard prototypes',
      'Local-first data viewers',
      'Mock/sample data'
    ],
    doesNotBelong: [
      'HueyOS runtime code',
      'Live robot control',
      'Production system mutations',
      'Real governance/memory operations',
      'External API integrations (unless explicit)'
    ],
    repoLink: 'https://github.com/[owner]/hueyos-migration-command-center',
    maturityLevel: 'prototype',
    maturityColor: 'bg-muted text-muted-foreground'
  },
  {
    id: 'dlrp',
    name: 'dlrp.ca',
    icon: <Globe size={24} weight="bold" />,
    role: 'Public project site and personal portfolio',
    belongsHere: [
      'Public-facing documentation',
      'Project announcements',
      'Portfolio content',
      'Blog posts',
      'High-level architecture docs',
      'Public demos/videos'
    ],
    doesNotBelong: [
      'Private repository code',
      'Internal tracking tools',
      'Development dashboards',
      'Sensitive technical details',
      'API keys or secrets'
    ],
    repoLink: 'https://dlrp.ca',
    maturityLevel: 'stable',
    maturityColor: 'bg-accent text-accent-foreground'
  }
]

const maturityLabels: Record<MaturityLevel, string> = {
  'prototype': 'Prototype',
  'active-development': 'Active Development',
  'stable': 'Stable',
  'production': 'Production'
}

export function UmbrellaPage() {
  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-2xl font-bold mb-2">Monkey-Head-Project Ecosystem</h2>
        <p className="text-muted-foreground mb-6">
          This dashboard is part of the Monkey-Head-Project umbrella. Below is the architecture showing how each component relates to the core HueyOS runtime.
        </p>

        <Card className="mb-8 bg-card/50">
          <CardHeader>
            <CardTitle className="text-lg">Architecture Diagram</CardTitle>
            <CardDescription>Component relationships and data flow</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center gap-8 py-8">
              <div className="relative w-full max-w-4xl">
                <svg viewBox="0 0 800 500" className="w-full h-auto">
                  <defs>
                    <marker
                      id="arrowhead"
                      markerWidth="10"
                      markerHeight="10"
                      refX="9"
                      refY="3"
                      orient="auto"
                    >
                      <polygon
                        points="0 0, 10 3, 0 6"
                        fill="oklch(0.55 0.25 285)"
                      />
                    </marker>
                  </defs>

                  <rect
                    x="300"
                    y="200"
                    width="200"
                    height="100"
                    rx="8"
                    fill="oklch(0.55 0.25 285)"
                    stroke="oklch(0.75 0.20 145)"
                    strokeWidth="3"
                  />
                  <text
                    x="400"
                    y="235"
                    textAnchor="middle"
                    fill="oklch(0.98 0 0)"
                    fontSize="16"
                    fontWeight="bold"
                  >
                    Monkey-Head-Project
                  </text>
                  <text
                    x="400"
                    y="255"
                    textAnchor="middle"
                    fill="oklch(0.92 0.01 265)"
                    fontSize="12"
                  >
                    HueyOS Runtime
                  </text>
                  <text
                    x="400"
                    y="275"
                    textAnchor="middle"
                    fill="oklch(0.92 0.01 265)"
                    fontSize="12"
                  >
                    Core Systems
                  </text>

                  <rect
                    x="50"
                    y="50"
                    width="180"
                    height="80"
                    rx="8"
                    fill="oklch(0.25 0.015 265)"
                    stroke="oklch(0.60 0.02 265)"
                    strokeWidth="2"
                  />
                  <text
                    x="140"
                    y="80"
                    textAnchor="middle"
                    fill="oklch(0.92 0.01 265)"
                    fontSize="14"
                    fontWeight="600"
                  >
                    PyHuey
                  </text>
                  <text
                    x="140"
                    y="100"
                    textAnchor="middle"
                    fill="oklch(0.60 0.02 265)"
                    fontSize="11"
                  >
                    Operator Cockpit
                  </text>

                  <rect
                    x="570"
                    y="50"
                    width="180"
                    height="80"
                    rx="8"
                    fill="oklch(0.25 0.015 265)"
                    stroke="oklch(0.60 0.02 265)"
                    strokeWidth="2"
                  />
                  <text
                    x="660"
                    y="80"
                    textAnchor="middle"
                    fill="oklch(0.92 0.01 265)"
                    fontSize="14"
                    fontWeight="600"
                  >
                    Migration Center
                  </text>
                  <text
                    x="660"
                    y="100"
                    textAnchor="middle"
                    fill="oklch(0.60 0.02 265)"
                    fontSize="11"
                  >
                    Dashboard/Tracker
                  </text>

                  <rect
                    x="310"
                    y="380"
                    width="180"
                    height="80"
                    rx="8"
                    fill="oklch(0.25 0.015 265)"
                    stroke="oklch(0.60 0.02 265)"
                    strokeWidth="2"
                  />
                  <text
                    x="400"
                    y="410"
                    textAnchor="middle"
                    fill="oklch(0.92 0.01 265)"
                    fontSize="14"
                    fontWeight="600"
                  >
                    dlrp.ca
                  </text>
                  <text
                    x="400"
                    y="430"
                    textAnchor="middle"
                    fill="oklch(0.60 0.02 265)"
                    fontSize="11"
                  >
                    Public Site
                  </text>

                  <line
                    x1="230"
                    y1="90"
                    x2="320"
                    y2="220"
                    stroke="oklch(0.55 0.25 285)"
                    strokeWidth="2"
                    markerEnd="url(#arrowhead)"
                  />
                  <text
                    x="260"
                    y="145"
                    fill="oklch(0.60 0.02 265)"
                    fontSize="10"
                  >
                    controls
                  </text>

                  <line
                    x1="570"
                    y1="90"
                    x2="480"
                    y2="220"
                    stroke="oklch(0.55 0.25 285)"
                    strokeWidth="2"
                    markerEnd="url(#arrowhead)"
                  />
                  <text
                    x="510"
                    y="145"
                    fill="oklch(0.60 0.02 265)"
                    fontSize="10"
                  >
                    monitors
                  </text>

                  <line
                    x1="400"
                    y1="300"
                    x2="400"
                    y2="380"
                    stroke="oklch(0.55 0.25 285)"
                    strokeWidth="2"
                    markerEnd="url(#arrowhead)"
                  />
                  <text
                    x="415"
                    y="345"
                    fill="oklch(0.60 0.02 265)"
                    fontSize="10"
                  >
                    documents
                  </text>
                </svg>
              </div>

              <div className="text-sm text-muted-foreground text-center max-w-2xl">
                <p>
                  <span className="font-semibold text-primary">Monkey-Head-Project</span> is the canonical runtime at the center.{' '}
                  <span className="font-semibold text-foreground">PyHuey</span> provides operator controls,{' '}
                  <span className="font-semibold text-foreground">Migration Command Center</span> monitors and tracks development,{' '}
                  and <span className="font-semibold text-foreground">dlrp.ca</span> presents public-facing documentation.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      <Separator />

      <section>
        <h2 className="text-xl font-semibold mb-6">Project Components</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {projects.map((project) => (
            <Card key={project.id} className="hover:border-primary/50 transition-colors">
              <CardHeader>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div className="text-primary">{project.icon}</div>
                    <div>
                      <CardTitle className="text-lg">{project.name}</CardTitle>
                      <CardDescription className="text-xs mt-1">
                        {project.role}
                      </CardDescription>
                    </div>
                  </div>
                  <Badge className={project.maturityColor}>
                    {maturityLabels[project.maturityLevel]}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                    <CheckCircle size={16} className="text-accent" weight="fill" />
                    What belongs here
                  </h4>
                  <ul className="space-y-1">
                    {project.belongsHere.map((item, idx) => (
                      <li key={idx} className="text-xs text-muted-foreground pl-6">
                        • {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                    <XCircle size={16} className="text-destructive" weight="fill" />
                    What does not belong here
                  </h4>
                  <ul className="space-y-1">
                    {project.doesNotBelong.map((item, idx) => (
                      <li key={idx} className="text-xs text-muted-foreground pl-6">
                        • {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <Separator />

                <div className="flex items-center gap-2 text-xs">
                  <LinkIcon size={14} className="text-muted-foreground" />
                  <code className="text-xs text-muted-foreground font-mono bg-muted px-2 py-1 rounded">
                    {project.repoLink}
                  </code>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <Separator />

      <section>
        <h2 className="text-xl font-semibold mb-4">Integration Guidelines</h2>
        <Card>
          <CardContent className="pt-6 space-y-4">
            <div>
              <h4 className="text-sm font-semibold mb-2 text-foreground">Data Flow</h4>
              <p className="text-sm text-muted-foreground">
                All components should maintain clear boundaries. The Migration Command Center operates in local-first mode with mock data by default. 
                Any future integration with live HueyOS systems must use explicit adapter boundaries with proper authentication and safety controls.
              </p>
            </div>

            <div>
              <h4 className="text-sm font-semibold mb-2 text-foreground">Repository Structure</h4>
              <p className="text-sm text-muted-foreground">
                Each component lives in its own repository. Monkey-Head-Project may optionally reference companion repos as submodules in the future, 
                but each maintains independent version control and deployment pipelines.
              </p>
            </div>

            <div>
              <h4 className="text-sm font-semibold mb-2 text-foreground">Safety Boundaries</h4>
              <p className="text-sm text-muted-foreground">
                Dashboard and viewer tools must never perform live system mutations, robot control, governance changes, or memory operations 
                without explicit opt-in configuration and multi-layer confirmation.
              </p>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}
