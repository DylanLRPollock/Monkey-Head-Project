import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Textarea } from '@/components/ui/textarea'
import { Separator } from '@/components/ui/separator'
import { Progress } from '@/components/ui/progress'
import { StatusBadge, RiskBadge } from './StatusBadge'
import { CopyButton } from './CopyButton'
import { Warning, Terminal, CheckCircle } from '@phosphor-icons/react'
import type { Phase, PhaseStatus, RiskLevel } from '@/lib/types'
import { cn } from '@/lib/utils'

interface PhaseCardProps {
  phase: Phase
  isCurrentPhase: boolean
  onUpdateStatus: (phaseId: string, status: PhaseStatus) => void
  onUpdateRisk: (phaseId: string, risk: RiskLevel) => void
  onToggleChecklist: (phaseId: string, checklistId: string) => void
  onUpdateNotes: (phaseId: string, notes: string) => void
}

export function PhaseCard({
  phase,
  isCurrentPhase,
  onUpdateStatus,
  onUpdateRisk,
  onToggleChecklist,
  onUpdateNotes
}: PhaseCardProps) {
  const [isExpanded, setIsExpanded] = useState(isCurrentPhase)

  const completedItems = phase.checklist.filter(item => item.completed).length
  const totalItems = phase.checklist.length
  const completionPercentage = (completedItems / totalItems) * 100

  return (
    <Card 
      className={cn(
        'transition-all duration-200 hover:border-primary/50',
        isCurrentPhase && 'border-primary glow-purple'
      )}
    >
      <CardHeader className="cursor-pointer" onClick={() => setIsExpanded(!isExpanded)}>
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              {isCurrentPhase && (
                <span className="text-xs font-mono text-primary uppercase tracking-wider">Current Phase</span>
              )}
            </div>
            <CardTitle className="text-lg">{phase.name}</CardTitle>
            <p className="text-sm text-muted-foreground mt-2">{phase.description}</p>
          </div>
          <div className="flex flex-col gap-2 items-end">
            <StatusBadge status={phase.status} />
            <RiskBadge level={phase.riskLevel} />
          </div>
        </div>
        
        <div className="mt-4">
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="text-muted-foreground">Progress</span>
            <span className="font-mono text-xs">{completedItems}/{totalItems} tasks</span>
          </div>
          <Progress value={completionPercentage} className="h-2" />
        </div>
      </CardHeader>

      {isExpanded && (
        <CardContent className="space-y-6">
          <Separator />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-xs uppercase tracking-wide text-muted-foreground mb-2 block">
                Status
              </label>
              <Select value={phase.status} onValueChange={(value) => onUpdateStatus(phase.id, value as PhaseStatus)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="not-started">Not Started</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="blocked">Blocked</SelectItem>
                  <SelectItem value="ready">Ready for PR</SelectItem>
                  <SelectItem value="merged">Merged</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs uppercase tracking-wide text-muted-foreground mb-2 block">
                Risk Level
              </label>
              <Select value={phase.riskLevel} onValueChange={(value) => onUpdateRisk(phase.id, value as RiskLevel)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low Risk</SelectItem>
                  <SelectItem value="medium">Medium Risk</SelectItem>
                  <SelectItem value="high">High Risk</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {phase.risks.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Warning className="text-destructive" weight="fill" />
                <h4 className="text-sm font-semibold uppercase tracking-wide">Risks</h4>
              </div>
              <div className="space-y-2">
                {phase.risks.map(risk => (
                  <div key={risk.id} className={cn('p-3 rounded border', `risk-${risk.level}`)}>
                    <div className="flex items-center gap-2 mb-1">
                      <RiskBadge level={risk.level} className="text-xs" />
                      <p className="text-sm font-medium">{risk.description}</p>
                    </div>
                    {risk.mitigation && (
                      <p className="text-xs text-muted-foreground mt-1">
                        <span className="font-semibold">Mitigation:</span> {risk.mitigation}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div>
            <div className="flex items-center gap-2 mb-3">
              <CheckCircle className="text-accent" weight="fill" />
              <h4 className="text-sm font-semibold uppercase tracking-wide">PR Checklist</h4>
            </div>
            <div className="space-y-2">
              {phase.checklist.map(item => (
                <div key={item.id} className="flex items-center gap-3 p-2 hover:bg-muted/30 rounded">
                  <Checkbox
                    id={item.id}
                    checked={item.completed}
                    onCheckedChange={() => onToggleChecklist(phase.id, item.id)}
                  />
                  <label
                    htmlFor={item.id}
                    className={cn(
                      'text-sm cursor-pointer flex-1',
                      item.completed && 'line-through text-muted-foreground'
                    )}
                  >
                    {item.text}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {phase.validationCommands.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Terminal className="text-accent" weight="bold" />
                <h4 className="text-sm font-semibold uppercase tracking-wide">Validation Commands</h4>
              </div>
              <div className="space-y-2">
                {phase.validationCommands.map((cmd, idx) => (
                  <div key={idx} className="flex items-center gap-2 p-3 bg-secondary rounded border border-border">
                    <code className="flex-1 text-xs font-mono text-foreground">{cmd}</code>
                    <CopyButton text={cmd} />
                  </div>
                ))}
              </div>
            </div>
          )}

          <div>
            <label className="text-xs uppercase tracking-wide text-muted-foreground mb-2 block">
              Notes
            </label>
            <Textarea
              value={phase.notes}
              onChange={(e) => onUpdateNotes(phase.id, e.target.value)}
              placeholder="Add notes about this phase..."
              className="min-h-[80px] font-sans"
              onBlur={(e) => onUpdateNotes(phase.id, e.target.value)}
            />
          </div>
        </CardContent>
      )}
    </Card>
  )
}
