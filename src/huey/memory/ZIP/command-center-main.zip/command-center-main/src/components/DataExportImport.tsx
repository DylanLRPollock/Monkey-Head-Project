import { useState, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Download, Upload } from '@phosphor-icons/react'
import { toast } from 'sonner'
import type { MigrationData } from '@/lib/types'

interface DataExportImportProps {
  migrationData: MigrationData
  onImport: (data: MigrationData) => void
}

export function DataExportImport({ migrationData, onImport }: DataExportImportProps) {
  const [isImporting, setIsImporting] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleExport = () => {
    try {
      const dataStr = JSON.stringify(migrationData, null, 2)
      const dataBlob = new Blob([dataStr], { type: 'application/json' })
      const url = URL.createObjectURL(dataBlob)
      const link = document.createElement('a')
      link.href = url
      link.download = `hueyos-migration-${new Date().toISOString().split('T')[0]}.json`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)
      toast.success('Migration data exported successfully')
    } catch (error) {
      toast.error('Failed to export migration data')
      console.error('Export error:', error)
    }
  }

  const handleImportClick = () => {
    fileInputRef.current?.click()
  }

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setIsImporting(true)
    const reader = new FileReader()

    reader.onload = (e) => {
      try {
        const content = e.target?.result as string
        const importedData = JSON.parse(content) as MigrationData
        
        if (!importedData.phases || !Array.isArray(importedData.phases)) {
          throw new Error('Invalid migration data format')
        }

        onImport(importedData)
        toast.success('Migration data imported successfully')
      } catch (error) {
        toast.error('Failed to import migration data. Please check the file format.')
        console.error('Import error:', error)
      } finally {
        setIsImporting(false)
        if (fileInputRef.current) {
          fileInputRef.current.value = ''
        }
      }
    }

    reader.onerror = () => {
      toast.error('Failed to read file')
      setIsImporting(false)
    }

    reader.readAsText(file)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Backup & Restore</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-4">
          Export your migration data as JSON for backup or sharing. Import previously exported data to restore your state.
        </p>
        <div className="flex flex-wrap gap-3">
          <Button onClick={handleExport} variant="default" className="flex items-center gap-2">
            <Download size={16} weight="bold" />
            Export Data
          </Button>
          <Button 
            onClick={handleImportClick} 
            variant="secondary" 
            disabled={isImporting}
            className="flex items-center gap-2"
          >
            <Upload size={16} weight="bold" />
            {isImporting ? 'Importing...' : 'Import Data'}
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            onChange={handleFileChange}
            className="hidden"
          />
        </div>
      </CardContent>
    </Card>
  )
}
