import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { toast } from 'sonner'
import { CopyButton } from './CopyButton'
import type { Phase } from '@/lib/types'
import { generateCopilotPrompt, formatCopilotPromptForCopy, generateNextBestTask } from '@/lib/copilot-prompts'
import { Sparkle, Copy } from '@phosphor-icons/react'

interface CopilotTaskGeneratorProps {
  phases: Phase[]
}

export function CopilotTaskGenerator({ phases }: CopilotTaskGeneratorProps) {
  const handleGenerateForPhase = (phase: Phase) => {
    const prompt = generateCopilotPrompt(phase, 'DylanLRPollock/Monkey-Head-Project')
    const formatted = formatCopilotPromptForCopy(prompt)
    navigator.clipboard.writeText(formatted)
    toast.success('Copilot prompt copied to clipboard')
  }

  const handleGenerateNext = () => {
    const prompt = generateNextBestTask(phases)
    navigator.clipboard.writeText(prompt)
    toast.success('Next best task copied to clipboard')
  }

  return (
    <div className="space-y-6">
      <Card className="border-accent/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkle className="text-accent" weight="fill" />
            Generate Next Best Task
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            Automatically generates a Copilot-ready prompt for the highest-priority unblocked task.
          </p>
          <Button onClick={handleGenerateNext} className="w-full">
            <Copy className="mr-2" />
            Generate & Copy Next Task
          </Button>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <h3 className="text-lg font-semibold">Generate Task for Specific Phase</h3>
        {phases.map((phase) => (
          <Card key={phase.id}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <h4 className="font-semibold mb-1">{phase.name}</h4>
                  <p className="text-sm text-muted-foreground">{phase.description}</p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleGenerateForPhase(phase)}
                >
                  <Copy className="mr-2" size={16} />
                  Copy Prompt
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
