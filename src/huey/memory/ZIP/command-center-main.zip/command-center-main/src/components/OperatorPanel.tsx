import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Alert, AlertDescription } from '@/components/ui/alert'
import {
  Desktop,
  ChartLine,
  Brain,
  Database,
  ShieldCheck,
  Plugs,
  FileText,
  Power,
  ArrowsClockwise,
  Warning,
  CheckCircle,
  XCircle,
  Clock,
  Prohibit
} from '@phosphor-icons/react'
import { toast } from 'sonner'
import type { HealthStatus, LoopStatus, ConnectorStatus, OperatorPanelData } from '@/lib/types'
import { formatDistanceToNow } from 'date-fns'

interface OperatorPanelProps {
  data: OperatorPanelData
}

const HealthBadge = ({ status }: { status: HealthStatus }) => {
  const config = {
    healthy: { icon: CheckCircle, color: 'text-accent', bg: 'bg-accent/20', label: 'Healthy' },
    degraded: { icon: Warning, color: 'text-yellow-500', bg: 'bg-yellow-500/20', label: 'Degraded' },
    down: { icon: XCircle, color: 'text-destructive', bg: 'bg-destructive/20', label: 'Down' }
  }
  
  const { icon: Icon, color, bg, label } = config[status]
  
  return (
    <Badge className={`${bg} ${color} border-none`}>
      <Icon className="mr-1" size={14} weight="fill" />
      {label}
    </Badge>
  )
}

const LoopStatusBadge = ({ status }: { status: LoopStatus }) => {
  const config = {
    running: { icon: CheckCircle, color: 'text-accent', bg: 'bg-accent/20', label: 'Running' },
    paused: { icon: Clock, color: 'text-yellow-500', bg: 'bg-yellow-500/20', label: 'Paused' },
    stopped: { icon: XCircle, color: 'text-muted-foreground', bg: 'bg-muted', label: 'Stopped' },
    error: { icon: XCircle, color: 'text-destructive', bg: 'bg-destructive/20', label: 'Error' }
  }
  
  const { icon: Icon, color, bg, label } = config[status]
  
  return (
    <Badge className={`${bg} ${color} border-none`}>
      <Icon className="mr-1" size={14} weight="fill" />
      {label}
    </Badge>
  )
}

const ConnectorStatusBadge = ({ status }: { status: ConnectorStatus }) => {
  const config = {
    connected: { icon: CheckCircle, color: 'text-accent', bg: 'bg-accent/20', label: 'Connected' },
    disconnected: { icon: XCircle, color: 'text-muted-foreground', bg: 'bg-muted', label: 'Disconnected' },
    error: { icon: XCircle, color: 'text-destructive', bg: 'bg-destructive/20', label: 'Error' }
  }
  
  const { icon: Icon, color, bg, label } = config[status]
  
  return (
    <Badge className={`${bg} ${color} border-none`}>
      <Icon className="mr-1" size={14} weight="fill" />
      {label}
    </Badge>
  )
}

const formatUptime = (seconds: number) => {
  const days = Math.floor(seconds / 86400)
  const hours = Math.floor((seconds % 86400) / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  
  if (days > 0) return `${days}d ${hours}h ${minutes}m`
  if (hours > 0) return `${hours}h ${minutes}m`
  return `${minutes}m`
}

const LogLevelBadge = ({ level }: { level: 'info' | 'warn' | 'error' | 'debug' }) => {
  const config = {
    info: { color: 'text-blue-400', bg: 'bg-blue-400/20', label: 'INFO' },
    warn: { color: 'text-yellow-500', bg: 'bg-yellow-500/20', label: 'WARN' },
    error: { color: 'text-destructive', bg: 'bg-destructive/20', label: 'ERROR' },
    debug: { color: 'text-muted-foreground', bg: 'bg-muted', label: 'DEBUG' }
  }
  
  const { color, bg, label } = config[level]
  
  return (
    <Badge className={`${bg} ${color} border-none font-mono text-[10px]`}>
      {label}
    </Badge>
  )
}

export function OperatorPanel({ data }: OperatorPanelProps) {
  const [isRefreshing, setIsRefreshing] = useState(false)
  
  const handleMockAction = (actionName: string) => {
    toast.info(`Mock Only: ${actionName}`, {
      description: 'This is a mock operator panel. No actions will be executed.'
    })
  }
  
  const handleRefresh = () => {
    setIsRefreshing(true)
    toast.success('Data refreshed')
    setTimeout(() => setIsRefreshing(false), 800)
  }
  
  const storagePercent = (data.memory.storageUsed / data.memory.storageLimit) * 100
  
  return (
    <div className="space-y-6">
      <Alert className="border-primary/30 bg-primary/10">
        <Warning className="text-primary" weight="fill" />
        <AlertDescription className="text-sm">
          <span className="font-semibold">Mock Operator Panel:</span> All controls are simulated. 
          No live system modifications will occur.
        </AlertDescription>
      </Alert>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card className="border-primary/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Desktop className="text-primary" size={20} weight="bold" />
              System Identity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Instance ID</span>
                <span className="font-mono">{data.systemIdentity.instanceId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Version</span>
                <Badge variant="outline" className="font-mono">{data.systemIdentity.version}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Environment</span>
                <Badge className="bg-secondary">{data.systemIdentity.environment}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Uptime</span>
                <span className="font-mono">{formatUptime(data.systemIdentity.uptime)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Hostname</span>
                <span className="font-mono text-xs">{data.systemIdentity.hostname}</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-primary/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <ChartLine className="text-accent" size={20} weight="bold" />
              Local API Health
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Overall Status</span>
                <HealthBadge status={data.apiHealth.status} />
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Response Time</span>
                <span className="font-mono text-accent">{data.apiHealth.responseTime}ms</span>
              </div>
              <Separator />
              <div className="space-y-2">
                {data.apiHealth.endpoints.map((endpoint) => (
                  <div key={endpoint.name} className="flex items-center justify-between text-xs">
                    <span className="font-mono text-muted-foreground">{endpoint.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">{endpoint.responseTime}ms</span>
                      <HealthBadge status={endpoint.status} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-primary/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Brain className="text-primary" size={20} weight="bold" />
              V1 Proof Loop
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Status</span>
                <LoopStatusBadge status={data.proofLoop.status} />
              </div>
              {data.proofLoop.currentRun && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Current Run</span>
                  <span className="font-mono">{data.proofLoop.currentRun}</span>
                </div>
              )}
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Total Runs</span>
                <span className="font-mono">{data.proofLoop.totalRuns.toLocaleString()}</span>
              </div>
              <div className="space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Success Rate</span>
                  <span className="font-mono text-accent">{data.proofLoop.successRate.toFixed(1)}%</span>
                </div>
                <Progress value={data.proofLoop.successRate} className="h-2" />
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Errors</span>
                <span className="font-mono text-destructive">{data.proofLoop.errorCount}</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-primary/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Database className="text-accent" size={20} weight="bold" />
              Memory Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Status</span>
                <HealthBadge status={data.memory.status} />
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Total Entries</span>
                <span className="font-mono">{data.memory.totalEntries.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Recent Writes</span>
                <span className="font-mono">{data.memory.recentWrites}</span>
              </div>
              <div className="space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Storage</span>
                  <span className="font-mono text-xs">
                    {data.memory.storageUsed.toFixed(1)}GB / {data.memory.storageLimit.toFixed(1)}GB
                  </span>
                </div>
                <Progress value={storagePercent} className="h-2" />
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Last Sync</span>
                <span className="font-mono">{formatDistanceToNow(new Date(data.memory.lastSync), { addSuffix: true })}</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-primary/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <ShieldCheck className="text-primary" size={20} weight="bold" />
              Governance Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Status</span>
                <HealthBadge status={data.governance.status} />
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Active Rules</span>
                <span className="font-mono">{data.governance.activeRules}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Violations</span>
                <span className={`font-mono ${data.governance.violations > 0 ? 'text-yellow-500' : ''}`}>
                  {data.governance.violations}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Emergency Mode</span>
                <Badge className={data.governance.emergencyMode ? 'bg-destructive' : 'bg-muted'}>
                  {data.governance.emergencyMode ? 'ACTIVE' : 'Inactive'}
                </Badge>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Last Audit</span>
                <span className="font-mono">{formatDistanceToNow(new Date(data.governance.lastAudit), { addSuffix: true })}</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-primary/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Plugs className="text-accent" size={20} weight="bold" />
              Connectors ({data.connectors.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[180px]">
              <div className="space-y-3">
                {data.connectors.map((connector) => (
                  <div key={connector.id} className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">{connector.name}</span>
                      <ConnectorStatusBadge status={connector.status} />
                    </div>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>Messages: {connector.messageCount.toLocaleString()}</span>
                      <span>{formatDistanceToNow(new Date(connector.lastPing), { addSuffix: true })}</span>
                    </div>
                    {connector !== data.connectors[data.connectors.length - 1] && (
                      <Separator className="mt-3" />
                    )}
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-primary/30">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <FileText className="text-primary" size={20} weight="bold" />
              Recent Logs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[300px]">
              <div className="space-y-3">
                {data.recentLogs.map((log) => (
                  <div key={log.id} className="space-y-1">
                    <div className="flex items-start gap-2">
                      <LogLevelBadge level={log.level} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                          <span className="font-mono">{log.source}</span>
                          <span>•</span>
                          <span>{formatDistanceToNow(new Date(log.timestamp), { addSuffix: true })}</span>
                        </div>
                        <p className="text-sm break-words">{log.message}</p>
                      </div>
                    </div>
                    {log !== data.recentLogs[data.recentLogs.length - 1] && (
                      <Separator className="mt-3" />
                    )}
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
        
        <Card className="border-primary/30">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Power className="text-accent" size={20} weight="bold" />
              Safe Actions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Safe Operations:</p>
                <div className="grid grid-cols-1 gap-2">
                  <Button
                    variant="outline"
                    className="justify-start"
                    onClick={handleRefresh}
                    disabled={isRefreshing}
                  >
                    <ArrowsClockwise className={`mr-2 ${isRefreshing ? 'animate-spin' : ''}`} size={16} />
                    Refresh Dashboard
                  </Button>
                  <Button
                    variant="outline"
                    className="justify-start"
                    onClick={() => handleMockAction('View System Logs')}
                  >
                    <FileText className="mr-2" size={16} />
                    View System Logs
                  </Button>
                  <Button
                    variant="outline"
                    className="justify-start"
                    onClick={() => handleMockAction('Export Diagnostics')}
                  >
                    <ChartLine className="mr-2" size={16} />
                    Export Diagnostics
                  </Button>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground flex items-center gap-2">
                  <Prohibit className="text-destructive" size={16} weight="fill" />
                  Dangerous Operations (Mock Only):
                </p>
                <div className="grid grid-cols-1 gap-2">
                  <Button
                    variant="outline"
                    className="justify-start opacity-50"
                    disabled
                    onClick={() => handleMockAction('System Shutdown')}
                  >
                    <Power className="mr-2 text-destructive" size={16} />
                    System Shutdown
                  </Button>
                  <Button
                    variant="outline"
                    className="justify-start opacity-50"
                    disabled
                    onClick={() => handleMockAction('Emergency Mode')}
                  >
                    <ShieldCheck className="mr-2 text-destructive" size={16} />
                    Toggle Emergency Mode
                  </Button>
                  <Button
                    variant="outline"
                    className="justify-start opacity-50"
                    disabled
                    onClick={() => handleMockAction('Memory Mutation')}
                  >
                    <Database className="mr-2 text-destructive" size={16} />
                    Mutate Memory
                  </Button>
                  <Button
                    variant="outline"
                    className="justify-start opacity-50"
                    disabled
                    onClick={() => handleMockAction('Execute Task')}
                  >
                    <Brain className="mr-2 text-destructive" size={16} />
                    Execute Direct Task
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
