import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { CopyButton } from './CopyButton'
import { validationCommands, getValidationCommandsByRepo } from '@/lib/validation-commands'
import { Terminal } from '@phosphor-icons/react'

const repos = ['Monkey-Head-Project', 'PyHuey', 'command-center']

export function ValidationCommandCenter() {
  return (
    <div className="space-y-6">
      <div className="bg-muted/50 border border-border rounded p-4">
        <p className="text-sm text-muted-foreground">
          <span className="font-semibold text-foreground">Important:</span> Commands shown here are for reference only.
          They must be run locally in the appropriate repository. Do not execute commands from this browser app.
        </p>
      </div>

      <Tabs defaultValue="Monkey-Head-Project">
        <TabsList className="grid w-full grid-cols-3">
          {repos.map((repo) => (
            <TabsTrigger key={repo} value={repo}>
              {repo.replace('Monkey-Head-Project', 'MHP').replace('command-center', 'CC')}
            </TabsTrigger>
          ))}
        </TabsList>

        {repos.map((repo) => {
          const commands = getValidationCommandsByRepo(repo)
          return (
            <TabsContent key={repo} value={repo} className="space-y-3">
              <h3 className="text-lg font-semibold mb-3">{repo} Validation Commands</h3>
              {commands.map((cmd) => (
                <Card key={cmd.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <CardTitle className="text-base flex items-center gap-2 mb-2">
                          <Terminal size={18} />
                          {cmd.purpose}
                        </CardTitle>
                        <Badge
                          variant={
                            cmd.riskLevel === 'high'
                              ? 'destructive'
                              : cmd.riskLevel === 'medium'
                              ? 'default'
                              : 'secondary'
                          }
                          className="mr-2"
                        >
                          {cmd.riskLevel} risk
                        </Badge>
                      </div>
                      <CopyButton text={cmd.command} />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="p-3 bg-secondary rounded border border-border">
                        <code className="text-xs font-mono text-foreground">{cmd.command}</code>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        <span className="font-semibold">Expected:</span> {cmd.expectedResult}
                      </div>
                      {cmd.notes && (
                        <div className="text-xs text-muted-foreground">
                          <span className="font-semibold">Notes:</span> {cmd.notes}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
          )
        })}
      </Tabs>
    </div>
  )
}
