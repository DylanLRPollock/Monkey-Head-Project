import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { ArrowSquareOut, GitPullRequest, Info, CheckCircle, XCircle, Clock } from '@phosphor-icons/react'
import type { RepositoryHealth } from '@/lib/github-types'

interface RepositoryCardProps {
  repoHealth: RepositoryHealth
  isLive: boolean
}

export function RepositoryCard({ repoHealth, isLive }: RepositoryCardProps) {
  const { repo, openPRs, openIssues, recentWorkflowRuns } = repoHealth
  
  const latestWorkflow = recentWorkflowRuns[0]
  
  const getWorkflowStatusIcon = () => {
    if (!latestWorkflow) return <Clock className="text-muted-foreground" />
    if (latestWorkflow.conclusion === 'success') return <CheckCircle className="text-accent" weight="fill" />
    if (latestWorkflow.conclusion === 'failure') return <XCircle className="text-destructive" weight="fill" />
    return <Clock className="text-muted-foreground" />
  }

  return (
    <Card className="border-primary/20 hover:border-primary/40 transition-colors">
      <CardHeader>
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1">
            <CardTitle className="text-lg font-mono mb-2">{repo.name}</CardTitle>
            <p className="text-sm text-muted-foreground mb-2">{repo.purpose || repo.description}</p>
            <p className="text-xs text-accent font-medium">{repo.role}</p>
          </div>
          <Badge variant={isLive ? "default" : "secondary"} className="shrink-0">
            {isLive ? 'LIVE' : 'MOCK'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-3 gap-3">
          <div className="flex flex-col items-center p-3 bg-secondary rounded border border-border">
            <div className="flex items-center gap-1 mb-1">
              <GitPullRequest size={16} />
              <span className="text-xs text-muted-foreground">PRs</span>
            </div>
            <span className="text-lg font-bold font-mono">{openPRs.length}</span>
          </div>
          
          <div className="flex flex-col items-center p-3 bg-secondary rounded border border-border">
            <div className="flex items-center gap-1 mb-1">
              <Info size={16} />
              <span className="text-xs text-muted-foreground">Issues</span>
            </div>
            <span className="text-lg font-bold font-mono">{openIssues.length}</span>
          </div>
          
          <div className="flex flex-col items-center p-3 bg-secondary rounded border border-border">
            {getWorkflowStatusIcon()}
            <span className="text-xs text-muted-foreground mt-1">CI</span>
          </div>
        </div>

        {latestWorkflow && (
          <div className="text-xs text-muted-foreground p-2 bg-muted/50 rounded">
            <span className="font-semibold">Latest: </span>
            {latestWorkflow.name} - {latestWorkflow.conclusion || latestWorkflow.status}
          </div>
        )}

        <Button 
          variant="outline" 
          size="sm" 
          className="w-full" 
          asChild
        >
          <a href={repo.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
            <ArrowSquareOut size={16} />
            View on GitHub
          </a>
        </Button>
      </CardContent>
    </Card>
  )
}
