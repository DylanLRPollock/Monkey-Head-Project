import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Shield, CheckCircle } from '@phosphor-icons/react'

export function SafetyBoundaries() {
  const boundaries = [
    'Mock data only',
    'No live robot control',
    'No network mutation',
    'No governance mutation',
    'No memory mutation',
    'No external API calls'
  ]

  return (
    <Card className="border-accent/30 bg-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-accent">
          <Shield size={24} weight="fill" />
          Safety Boundaries
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-4">
          This is a <strong>read-only dashboard prototype</strong> for planning and tracking only.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {boundaries.map((boundary, idx) => (
            <div key={idx} className="flex items-center gap-2 text-sm">
              <CheckCircle size={16} weight="fill" className="text-accent flex-shrink-0" />
              <span>{boundary}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
