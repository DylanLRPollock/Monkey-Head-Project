import { useState, useMemo } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { V1RunCard } from './V1RunCard'
import { toast } from 'sonner'
import { Download, Funnel, FolderOpen } from '@phosphor-icons/react'
import type { V1Run, RunStatus } from '@/lib/types'

interface V1RunViewerProps {
  runs: V1Run[]
}

export function V1RunViewer({ runs }: V1RunViewerProps) {
  const [filter, setFilter] = useState<RunStatus | 'all'>('all')

  const filteredRuns = useMemo(() => {
    if (filter === 'all') return runs
    return runs.filter(run => run.result === filter)
  }, [runs, filter])

  const stats = useMemo(() => {
    const passed = runs.filter(r => r.result === 'passed').length
    const failed = runs.filter(r => r.result === 'failed').length
    const pending = runs.filter(r => r.result === 'pending').length
    return { passed, failed, pending, total: runs.length }
  }, [runs])

  const handleExportJSON = () => {
    const exportData = filteredRuns.map(run => run.rawJson)
    const jsonString = JSON.stringify(exportData, null, 2)
    const blob = new Blob([jsonString], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `v1-runs-${filter}-${Date.now()}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast.success(`Exported ${filteredRuns.length} run${filteredRuns.length !== 1 ? 's' : ''} to JSON`)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-2">
              <Funnel className="text-primary" weight="bold" />
              <span className="text-sm font-semibold">Filter:</span>
              <div className="flex gap-2">
                <Button
                  variant={filter === 'all' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilter('all')}
                >
                  All <Badge variant="secondary" className="ml-2">{stats.total}</Badge>
                </Button>
                <Button
                  variant={filter === 'passed' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilter('passed')}
                  className={filter === 'passed' ? '' : 'hover:bg-accent/10'}
                >
                  Passed <Badge variant="secondary" className="ml-2">{stats.passed}</Badge>
                </Button>
                <Button
                  variant={filter === 'failed' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilter('failed')}
                  className={filter === 'failed' ? '' : 'hover:bg-destructive/10'}
                >
                  Failed <Badge variant="secondary" className="ml-2">{stats.failed}</Badge>
                </Button>
                <Button
                  variant={filter === 'pending' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilter('pending')}
                  className={filter === 'pending' ? '' : 'hover:bg-muted'}
                >
                  Pending <Badge variant="secondary" className="ml-2">{stats.pending}</Badge>
                </Button>
              </div>
            </div>

            <Button onClick={handleExportJSON} variant="outline" size="sm">
              <Download weight="bold" />
              Export Visible as JSON
            </Button>
          </div>
        </CardContent>
      </Card>

      {filteredRuns.length === 0 ? (
        <Card>
          <CardContent className="py-12 flex flex-col items-center justify-center text-center">
            <FolderOpen size={48} className="text-muted-foreground mb-4" weight="thin" />
            <p className="text-muted-foreground">No runs match the current filter</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filteredRuns.map(run => (
            <V1RunCard key={run.id} run={run} />
          ))}
        </div>
      )}
    </div>
  )
}
