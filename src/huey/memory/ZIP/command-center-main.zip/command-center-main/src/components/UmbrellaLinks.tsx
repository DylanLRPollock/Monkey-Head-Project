import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Link, Folder } from '@phosphor-icons/react'

export function UmbrellaLinks() {
  const links = [
    { name: 'Monkey-Head-Project', url: '#', description: 'Main runtime repository' },
    { name: 'PyHuey', url: '#', description: 'Operator cockpit fork' },
    { name: 'HueyOS Layout Docs', url: '#', description: 'Architecture documentation' },
    { name: 'Phase 2.5: Connector Reconciliation', url: '#', description: 'src/huey/connectors/pyhuey migration' },
    { name: 'Phase 3: PyHuey Rename', url: '#', description: 'Package rename pygpt_net → pyhuey' }
  ]

  return (
    <Card className="border-primary/30 bg-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-primary">
          <Folder size={24} weight="fill" />
          Umbrella Links
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {links.map((link, idx) => (
            <div key={idx} className="flex items-start gap-3 group">
              <Link size={16} className="text-primary flex-shrink-0 mt-0.5" weight="bold" />
              <div className="flex-1 min-w-0">
                <a
                  href={link.url}
                  className="text-sm font-medium hover:text-primary transition-colors block"
                >
                  {link.name}
                </a>
                <p className="text-xs text-muted-foreground">{link.description}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
