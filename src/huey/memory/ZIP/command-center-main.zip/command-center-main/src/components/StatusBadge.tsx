import { Badge } from '@/components/ui/badge'
import type { PhaseStatus, RiskLevel } from '@/lib/types'
import { cn } from '@/lib/utils'

interface StatusBadgeProps {
  status: PhaseStatus
  className?: string
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const statusMap = {
    'not-started': { label: 'Not Started', class: 'status-not-started' },
    'in-progress': { label: 'In Progress', class: 'status-in-progress' },
    'blocked': { label: 'Blocked', class: 'status-blocked' },
    'ready': { label: 'Ready for PR', class: 'status-ready' },
    'merged': { label: 'Merged', class: 'status-merged' }
  }

  const { label, class: statusClass } = statusMap[status]

  return (
    <Badge className={cn(statusClass, className)}>
      {label}
    </Badge>
  )
}

interface RiskBadgeProps {
  level: RiskLevel
  className?: string
}

export function RiskBadge({ level, className }: RiskBadgeProps) {
  const riskMap = {
    'low': { label: 'Low Risk', class: 'risk-low' },
    'medium': { label: 'Medium Risk', class: 'risk-medium' },
    'high': { label: 'High Risk', class: 'risk-high' }
  }

  const { label, class: riskClass } = riskMap[level]

  return (
    <Badge variant="outline" className={cn(riskClass, className)}>
      {label}
    </Badge>
  )
}
