import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { useKV } from '@github/spark/hooks'
import type { GitHubSettings } from '@/lib/github-types'
import { Key, Info, CheckCircle } from '@phosphor-icons/react'
import { toast } from 'sonner'

export function GitHubSettingsPanel() {
  const [settings, setSettings] = useKV<GitHubSettings>('github-settings', {
    enabled: false
  })
  const [tokenInput, setTokenInput] = useState('')
  const [showToken, setShowToken] = useState(false)

  const handleSaveToken = () => {
    if (!tokenInput.trim()) {
      toast.error('Please enter a GitHub token')
      return
    }

    setSettings({
      token: tokenInput,
      enabled: true
    })

    setTokenInput('')
    toast.success('GitHub token saved locally')
  }

  const handleDisable = () => {
    setSettings({
      enabled: false
    })
    toast.success('GitHub API disabled - using mock data')
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Key className="text-primary" />
          GitHub API Settings
          <Badge variant={settings && settings.enabled ? 'default' : 'secondary'} className="ml-auto">
            {settings && settings.enabled ? 'LIVE' : 'MOCK'}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription className="text-xs">
            <strong>Optional:</strong> Add a GitHub Personal Access Token to fetch live repository data.
            Token is stored only in your browser's local storage and never sent anywhere except GitHub API calls.
          </AlertDescription>
        </Alert>

        {settings && settings.enabled && settings.token ? (
          <div className="space-y-3">
            <div className="flex items-center gap-2 p-3 bg-accent/10 rounded border border-accent/30">
              <CheckCircle className="text-accent" weight="fill" />
              <span className="text-sm font-medium">GitHub API connected</span>
            </div>
            <Button variant="outline" onClick={handleDisable} className="w-full">
              Disable & Use Mock Data
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            <div>
              <Label htmlFor="github-token">GitHub Personal Access Token</Label>
              <Input
                id="github-token"
                type={showToken ? 'text' : 'password'}
                value={tokenInput}
                onChange={(e) => setTokenInput(e.target.value)}
                placeholder="ghp_xxxxxxxxxxxx"
                className="font-mono text-xs mt-1"
              />
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="show-token"
                checked={showToken}
                onChange={(e) => setShowToken(e.target.checked)}
                className="rounded"
              />
              <Label htmlFor="show-token" className="text-xs cursor-pointer">
                Show token
              </Label>
            </div>

            <Button onClick={handleSaveToken} className="w-full">
              Save Token & Enable Live Data
            </Button>

            <p className="text-xs text-muted-foreground">
              Create a token at{' '}
              <a
                href="https://github.com/settings/tokens"
                target="_blank"
                rel="noopener noreferrer"
                className="text-accent hover:underline"
              >
                github.com/settings/tokens
              </a>
              {' '}with <code className="bg-muted px-1 py-0.5 rounded">repo</code> scope.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
