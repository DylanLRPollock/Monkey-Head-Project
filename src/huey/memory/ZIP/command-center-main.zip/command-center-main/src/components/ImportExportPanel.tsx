import { useState, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Separator } from '@/components/ui/separator'
import { 
  Download, 
  Upload, 
  FileText, 
  ArrowClockwise, 
  CheckCircle, 
  WarningCircle 
} from '@phosphor-icons/react'
import { toast } from 'sonner'
import type { MigrationData, V1Run, OperatorPanelData } from '@/lib/types'
import type { DependencySecurityBacklog, FullDashboardState } from '@/lib/validators'
import {
  validateMigrationData,
  validateV1Runs,
  validateOperatorPanelData,
  validateDependencyBacklog,
  validateFullDashboardState
} from '@/lib/validators'

interface ImportExportPanelProps {
  migrationData: MigrationData
  v1Runs: V1Run[]
  operatorPanelData: OperatorPanelData
  dependencyBacklog: DependencySecurityBacklog
  onImportMigrationData: (data: MigrationData) => void
  onImportV1Runs: (data: V1Run[]) => void
  onImportOperatorPanel: (data: OperatorPanelData) => void
  onImportDependencyBacklog: (data: DependencySecurityBacklog) => void
  onResetToSampleData: () => void
}

export function ImportExportPanel({
  migrationData,
  v1Runs,
  operatorPanelData,
  dependencyBacklog,
  onImportMigrationData,
  onImportV1Runs,
  onImportOperatorPanel,
  onImportDependencyBacklog,
  onResetToSampleData
}: ImportExportPanelProps) {
  const [validationError, setValidationError] = useState<string | null>(null)
  const [validationSuccess, setValidationSuccess] = useState<string | null>(null)
  
  const migrationFileRef = useRef<HTMLInputElement>(null)
  const v1RunsFileRef = useRef<HTMLInputElement>(null)
  const operatorFileRef = useRef<HTMLInputElement>(null)
  const backlogFileRef = useRef<HTMLInputElement>(null)
  const fullStateFileRef = useRef<HTMLInputElement>(null)

  const clearMessages = () => {
    setValidationError(null)
    setValidationSuccess(null)
  }

  const handleFileImport = async (
    file: File,
    validator: (data: any) => { isValid: boolean; errors: string[] },
    onSuccess: (data: any) => void,
    dataTypeName: string
  ) => {
    clearMessages()
    
    try {
      const text = await file.text()
      const data = JSON.parse(text)
      
      const validation = validator(data)
      
      if (!validation.isValid) {
        const errorMsg = `Invalid ${dataTypeName} format:\n${validation.errors.join('\n')}`
        setValidationError(errorMsg)
        toast.error(`Import failed: Invalid ${dataTypeName}`)
        return
      }
      
      onSuccess(data)
      setValidationSuccess(`${dataTypeName} imported successfully!`)
      toast.success(`${dataTypeName} imported successfully`)
    } catch (error) {
      const errorMsg = error instanceof Error 
        ? `Failed to parse JSON: ${error.message}`
        : 'Failed to parse JSON file'
      setValidationError(errorMsg)
      toast.error('Import failed: Invalid JSON')
    }
  }

  const handleMigrationImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      handleFileImport(file, validateMigrationData, onImportMigrationData, 'Migration Data')
    }
    if (migrationFileRef.current) migrationFileRef.current.value = ''
  }

  const handleV1RunsImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      handleFileImport(file, validateV1Runs, onImportV1Runs, 'V1 Proof Loop Runs')
    }
    if (v1RunsFileRef.current) v1RunsFileRef.current.value = ''
  }

  const handleOperatorImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      handleFileImport(file, validateOperatorPanelData, onImportOperatorPanel, 'Operator Panel Data')
    }
    if (operatorFileRef.current) operatorFileRef.current.value = ''
  }

  const handleBacklogImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      handleFileImport(file, validateDependencyBacklog, onImportDependencyBacklog, 'Dependency/Security Backlog')
    }
    if (backlogFileRef.current) backlogFileRef.current.value = ''
  }

  const handleFullStateImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      handleFileImport(
        file,
        validateFullDashboardState,
        (data: FullDashboardState) => {
          onImportMigrationData(data.migrationData)
          onImportV1Runs(data.v1Runs)
          onImportOperatorPanel(data.operatorPanelData)
          onImportDependencyBacklog(data.dependencyBacklog)
        },
        'Full Dashboard State'
      )
    }
    if (fullStateFileRef.current) fullStateFileRef.current.value = ''
  }

  const exportJSON = (data: any, filename: string) => {
    const json = JSON.stringify(data, null, 2)
    const blob = new Blob([json], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = filename
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
    toast.success(`Exported ${filename}`)
  }

  const handleExportMigration = () => {
    exportJSON(migrationData, 'migration-phases.json')
  }

  const handleExportV1Runs = () => {
    exportJSON(v1Runs, 'v1-proof-loop-runs.json')
  }

  const handleExportOperator = () => {
    exportJSON(operatorPanelData, 'operator-panel-status.json')
  }

  const handleExportBacklog = () => {
    exportJSON(dependencyBacklog, 'dependency-security-backlog.json')
  }

  const handleExportFullState = () => {
    const fullState: FullDashboardState = {
      migrationData,
      v1Runs,
      operatorPanelData,
      dependencyBacklog
    }
    const timestamp = new Date().toISOString().split('T')[0]
    exportJSON(fullState, `hueyos-dashboard-full-state-${timestamp}.json`)
  }

  const handleReset = () => {
    if (confirm('Are you sure you want to reset all data to sample defaults? This cannot be undone.')) {
      onResetToSampleData()
      clearMessages()
      toast.success('Data reset to sample defaults')
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="text-primary" weight="bold" />
            Import / Export Data
          </CardTitle>
          <CardDescription>
            Manage dashboard state through local JSON files. All data is stored in browser storage only.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {validationError && (
            <Alert variant="destructive">
              <WarningCircle className="h-4 w-4" weight="fill" />
              <AlertDescription className="whitespace-pre-wrap font-mono text-xs">
                {validationError}
              </AlertDescription>
            </Alert>
          )}

          {validationSuccess && (
            <Alert className="border-accent bg-accent/10">
              <CheckCircle className="h-4 w-4 text-accent" weight="fill" />
              <AlertDescription className="text-accent-foreground">
                {validationSuccess}
              </AlertDescription>
            </Alert>
          )}

          <div>
            <h3 className="text-sm font-semibold mb-3">Import Individual Datasets</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="flex items-center gap-2">
                <input
                  ref={migrationFileRef}
                  type="file"
                  accept=".json"
                  onChange={handleMigrationImport}
                  className="hidden"
                  id="migration-import"
                />
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  onClick={() => migrationFileRef.current?.click()}
                >
                  <Upload size={16} className="mr-2" />
                  Import Migration Phases
                </Button>
              </div>

              <div className="flex items-center gap-2">
                <input
                  ref={v1RunsFileRef}
                  type="file"
                  accept=".json"
                  onChange={handleV1RunsImport}
                  className="hidden"
                  id="v1runs-import"
                />
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  onClick={() => v1RunsFileRef.current?.click()}
                >
                  <Upload size={16} className="mr-2" />
                  Import V1 Runs
                </Button>
              </div>

              <div className="flex items-center gap-2">
                <input
                  ref={operatorFileRef}
                  type="file"
                  accept=".json"
                  onChange={handleOperatorImport}
                  className="hidden"
                  id="operator-import"
                />
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  onClick={() => operatorFileRef.current?.click()}
                >
                  <Upload size={16} className="mr-2" />
                  Import Operator Panel
                </Button>
              </div>

              <div className="flex items-center gap-2">
                <input
                  ref={backlogFileRef}
                  type="file"
                  accept=".json"
                  onChange={handleBacklogImport}
                  className="hidden"
                  id="backlog-import"
                />
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  onClick={() => backlogFileRef.current?.click()}
                >
                  <Upload size={16} className="mr-2" />
                  Import Backlog
                </Button>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="text-sm font-semibold mb-3">Export Individual Datasets</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={handleExportMigration}
              >
                <Download size={16} className="mr-2" />
                Export Migration Phases
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={handleExportV1Runs}
              >
                <Download size={16} className="mr-2" />
                Export V1 Runs
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={handleExportOperator}
              >
                <Download size={16} className="mr-2" />
                Export Operator Panel
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={handleExportBacklog}
              >
                <Download size={16} className="mr-2" />
                Export Backlog
              </Button>
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="text-sm font-semibold mb-3">Full Dashboard State</h3>
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                ref={fullStateFileRef}
                type="file"
                accept=".json"
                onChange={handleFullStateImport}
                className="hidden"
                id="fullstate-import"
              />
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => fullStateFileRef.current?.click()}
              >
                <Upload size={16} className="mr-2" />
                Import Full State
              </Button>

              <Button
                variant="default"
                className="flex-1"
                onClick={handleExportFullState}
              >
                <Download size={16} className="mr-2" />
                Export Full State
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Full state includes all migration phases, V1 runs, operator panel data, and dependency backlog.
            </p>
          </div>

          <Separator />

          <div>
            <h3 className="text-sm font-semibold mb-3">Reset Data</h3>
            <Button
              variant="destructive"
              size="sm"
              onClick={handleReset}
              className="w-full sm:w-auto"
            >
              <ArrowClockwise size={16} className="mr-2" />
              Reset to Sample Data
            </Button>
            <p className="text-xs text-muted-foreground mt-2">
              This will restore all data to the original sample/mock data. Your current data will be lost.
            </p>
          </div>
        </CardContent>
      </Card>

      <Card className="border-muted">
        <CardHeader>
          <CardTitle className="text-sm">Data Privacy & Safety</CardTitle>
        </CardHeader>
        <CardContent className="text-xs text-muted-foreground space-y-2">
          <p>✓ All data is stored locally in your browser</p>
          <p>✓ No data is uploaded to external servers</p>
          <p>✓ Export files are created client-side only</p>
          <p>✓ Imported files are validated before applying</p>
          <p>✓ Invalid JSON will be rejected with error details</p>
        </CardContent>
      </Card>
    </div>
  )
}
