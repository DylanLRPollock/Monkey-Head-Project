import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import { CopyButton } from './CopyButton'
import { CheckCircle, XCircle, Clock, FileAudio, Microphone, Brain, Warning } from '@phosphor-icons/react'
import type { V1Run, RunStatus, TranscriptionStatus, CognitionStatus } from '@/lib/types'

interface V1RunCardProps {
  run: V1Run
}

const getStatusIcon = (status: RunStatus) => {
  switch (status) {
    case 'passed':
      return <CheckCircle className="text-accent" weight="fill" />
    case 'failed':
      return <XCircle className="text-destructive" weight="fill" />
    case 'pending':
      return <Clock className="text-muted-foreground" weight="fill" />
  }
}

const getStatusBadge = (status: RunStatus) => {
  switch (status) {
    case 'passed':
      return <Badge className="status-ready">Passed</Badge>
    case 'failed':
      return <Badge className="status-blocked">Failed</Badge>
    case 'pending':
      return <Badge className="status-not-started">Pending</Badge>
  }
}

const getTranscriptionBadge = (status: TranscriptionStatus) => {
  switch (status) {
    case 'complete':
      return <Badge variant="outline" className="text-accent border-accent">Complete</Badge>
    case 'error':
      return <Badge variant="outline" className="text-destructive border-destructive">Error</Badge>
    case 'pending':
      return <Badge variant="outline" className="text-muted-foreground">Pending</Badge>
  }
}

const getCognitionBadge = (status: CognitionStatus) => {
  switch (status) {
    case 'complete':
      return <Badge variant="outline" className="text-accent border-accent">Complete</Badge>
    case 'error':
      return <Badge variant="outline" className="text-destructive border-destructive">Error</Badge>
    case 'pending':
      return <Badge variant="outline" className="text-muted-foreground">Pending</Badge>
  }
}

export function V1RunCard({ run }: V1RunCardProps) {
  const [isOpen, setIsOpen] = useState(false)
  const timestamp = new Date(run.timestamp).toLocaleString()
  const jsonString = JSON.stringify(run.rawJson, null, 2)

  return (
    <Card className="hover:border-primary/30 transition-colors">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            {getStatusIcon(run.result)}
            <CardTitle className="text-base font-mono truncate">{run.fixtureFilename}</CardTitle>
          </div>
          {getStatusBadge(run.result)}
        </div>
        <p className="text-xs text-muted-foreground font-mono">{timestamp}</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <Microphone className="text-primary mt-0.5" size={16} weight="bold" />
            <div className="flex-1 min-w-0 space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold">Transcription</span>
                {getTranscriptionBadge(run.transcriptionStatus)}
              </div>
              {run.transcriptionText && (
                <p className="text-sm text-foreground">{run.transcriptionText}</p>
              )}
              {run.transcriptionError && (
                <p className="text-xs text-destructive flex items-start gap-1">
                  <Warning size={14} weight="fill" className="mt-0.5 flex-shrink-0" />
                  {run.transcriptionError}
                </p>
              )}
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Brain className="text-primary mt-0.5" size={16} weight="bold" />
            <div className="flex-1 min-w-0 space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold">Cognition</span>
                {getCognitionBadge(run.cognitionStatus)}
              </div>
              {run.cognitionResponse && (
                <p className="text-sm text-foreground">{run.cognitionResponse}</p>
              )}
              {run.cognitionError && (
                <p className="text-xs text-destructive flex items-start gap-1">
                  <Warning size={14} weight="fill" className="mt-0.5 flex-shrink-0" />
                  {run.cognitionError}
                </p>
              )}
            </div>
          </div>

          {run.errorDetails && (
            <div className="p-3 bg-destructive/10 border border-destructive/30 rounded">
              <p className="text-xs text-destructive font-semibold mb-1">Error Details</p>
              <p className="text-xs text-destructive">{run.errorDetails}</p>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2 pt-2">
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="sm" className="flex-1">
                <FileAudio size={16} weight="bold" />
                View JSON
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full sm:max-w-2xl overflow-y-auto">
              <SheetHeader>
                <SheetTitle className="font-mono text-sm">{run.fixtureFilename}</SheetTitle>
              </SheetHeader>
              <div className="mt-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-semibold">Raw JSON</h3>
                  <CopyButton text={jsonString} />
                </div>
                <pre className="p-4 bg-secondary rounded border border-border text-xs overflow-x-auto font-mono">
                  {jsonString}
                </pre>
              </div>
            </SheetContent>
          </Sheet>
          <CopyButton text={jsonString} />
        </div>
      </CardContent>
    </Card>
  )
}
