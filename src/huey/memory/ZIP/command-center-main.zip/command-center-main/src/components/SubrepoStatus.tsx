import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Database, CheckCircle } from '@phosphor-icons/react'

export function SubrepoStatus() {
  const status = [
    { label: 'Repository', value: 'hueyos-migration-command-center' },
    { label: 'Umbrella', value: 'Monkey-Head-Project' },
    { label: 'Status', value: 'Companion prototype' },
    { label: 'Integration Mode', value: 'Separate repo now, optional submodule later' }
  ]

  return (
    <Card className="border-primary/30 bg-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database size={24} weight="fill" className="text-primary" />
          Subrepo Status
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {status.map((item, idx) => (
            <div key={idx} className="flex items-start gap-3">
              <CheckCircle size={16} weight="fill" className="text-accent flex-shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                <div className="text-xs text-muted-foreground uppercase tracking-wider mb-0.5">
                  {item.label}
                </div>
                <div className="text-sm font-medium font-mono">{item.value}</div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
