import { useState } from 'react'
import { useKV } from '@github/spark/hooks'
import { Toaster } from '@/components/ui/sonner'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Separator } from '@/components/ui/separator'
import { Progress } from '@/components/ui/progress'
import { PhaseCard } from './components/PhaseCard'
import { CopyButton } from './components/CopyButton'
import { RiskBadge } from './components/StatusBadge'
import { V1RunViewer } from './components/V1RunViewer'
import { OperatorPanel } from './components/OperatorPanel'
import { SafetyBoundaries } from './components/SafetyBoundaries'
import { UmbrellaLinks } from './components/UmbrellaLinks'
import { SubrepoStatus } from './components/SubrepoStatus'
import { ImportExportPanel } from './components/ImportExportPanel'
import { UmbrellaPage } from './components/UmbrellaPage'
import { mockRepositories } from './lib/mock-repositories'
import { RepositoryCard } from './components/RepositoryCard'
import { ValidationCommandCenter } from './components/ValidationCommandCenter'
import { CopilotTaskGenerator } from './components/CopilotTaskGenerator'
import { GitHubSettingsPanel } from './components/GitHubSettingsPanel'
import { 
  initialMigrationData, 
  allValidationCommands, 
  mockV1Runs, 
  mockOperatorPanelData,
  mockDependencyBacklog
} from './lib/mockData'
import { Terminal, Warning, GitBranch, Brain, Desktop, Database, TreeStructure } from '@phosphor-icons/react'
import type { MigrationData, PhaseStatus, RiskLevel, V1Run, OperatorPanelData } from './lib/types'
import type { DependencySecurityBacklog } from './lib/validators'

function App() {
  const [migrationData, setMigrationData] = useKV<MigrationData>(
    'migration-data',
    initialMigrationData
  )
  const [v1Runs, setV1Runs] = useKV<V1Run[]>('v1-runs', mockV1Runs)
  const [operatorPanelData, setOperatorPanelData] = useKV<OperatorPanelData>(
    'operator-panel-data',
    mockOperatorPanelData
  )
  const [dependencyBacklog, setDependencyBacklog] = useKV<DependencySecurityBacklog>(
    'dependency-backlog',
    mockDependencyBacklog
  )
  const [activeTab, setActiveTab] = useState('migration')

  if (!migrationData || !migrationData.phases || !v1Runs || !operatorPanelData || !dependencyBacklog) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    )
  }

  const currentPhase = migrationData.phases.find(p => p.status === 'in-progress') || 
    migrationData.phases.find(p => p.status === 'not-started') ||
    migrationData.phases[0]

  const activeRisks = migrationData.phases.flatMap(phase =>
    phase.risks
      .filter(risk => risk.level === 'high' || risk.level === 'medium')
      .map(risk => ({ ...risk, phaseName: phase.name }))
  )

  const totalTasks = migrationData.phases.reduce((sum, phase) => sum + phase.checklist.length, 0)
  const completedTasks = migrationData.phases.reduce(
    (sum, phase) => sum + phase.checklist.filter(item => item.completed).length,
    0
  )
  const overallProgress = (completedTasks / totalTasks) * 100

  const handleUpdateStatus = (phaseId: string, status: PhaseStatus) => {
    setMigrationData((current) => {
      if (!current) return initialMigrationData
      return {
        ...current,
        phases: current.phases.map(phase =>
          phase.id === phaseId ? { ...phase, status } : phase
        )
      }
    })
  }

  const handleUpdateRisk = (phaseId: string, riskLevel: RiskLevel) => {
    setMigrationData((current) => {
      if (!current) return initialMigrationData
      return {
        ...current,
        phases: current.phases.map(phase =>
          phase.id === phaseId ? { ...phase, riskLevel } : phase
        )
      }
    })
  }

  const handleToggleChecklist = (phaseId: string, checklistId: string) => {
    setMigrationData((current) => {
      if (!current) return initialMigrationData
      return {
        ...current,
        phases: current.phases.map(phase =>
          phase.id === phaseId
            ? {
                ...phase,
                checklist: phase.checklist.map(item =>
                  item.id === checklistId ? { ...item, completed: !item.completed } : item
                )
              }
            : phase
        )
      }
    })
  }

  const handleUpdateNotes = (phaseId: string, notes: string) => {
    setMigrationData((current) => {
      if (!current) return initialMigrationData
      return {
        ...current,
        phases: current.phases.map(phase =>
          phase.id === phaseId ? { ...phase, notes } : phase
        )
      }
    })
  }

  const handleUpdateGlobalNotes = (notes: string) => {
    setMigrationData((current) => {
      if (!current) return initialMigrationData
      return {
        ...current,
        globalNotes: notes
      }
    })
  }

  const handleImport = (importedData: MigrationData) => {
    setMigrationData(importedData)
  }

  const handleResetToSampleData = () => {
    setMigrationData(initialMigrationData)
    setV1Runs(mockV1Runs)
    setOperatorPanelData(mockOperatorPanelData)
    setDependencyBacklog(mockDependencyBacklog)
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="container mx-auto px-6 py-8 max-w-7xl">
        <header className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <GitBranch className="text-primary" size={32} weight="bold" />
            <h1 className="font-mono text-3xl font-bold uppercase tracking-tight">
              Command Center
            </h1>
          </div>
          <p className="text-muted-foreground">
            Monkey-Head-Project Ecosystem Dashboard: Migration Tracking, Repository Health & Task Generation
          </p>
        </header>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-6 grid w-full grid-cols-7">
            <TabsTrigger value="migration" className="flex items-center gap-2">
              <GitBranch size={16} weight="bold" />
              Migration
            </TabsTrigger>
            <TabsTrigger value="repositories" className="flex items-center gap-2">
              <Database size={16} weight="bold" />
              Repositories
            </TabsTrigger>
            <TabsTrigger value="validation" className="flex items-center gap-2">
              <Terminal size={16} weight="bold" />
              Validation
            </TabsTrigger>
            <TabsTrigger value="copilot" className="flex items-center gap-2">
              <Brain size={16} weight="bold" />
              Copilot
            </TabsTrigger>
            <TabsTrigger value="v1-runs" className="flex items-center gap-2">
              <Brain size={16} weight="bold" />
              V1 Runs
            </TabsTrigger>
            <TabsTrigger value="operator" className="flex items-center gap-2">
              <Desktop size={16} weight="bold" />
              Operator
            </TabsTrigger>
            <TabsTrigger value="umbrella" className="flex items-center gap-2">
              <TreeStructure size={16} weight="bold" />
              Umbrella
            </TabsTrigger>
          </TabsList>

          <TabsContent value="migration" className="space-y-8">
            <div>
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-semibold">Overall Progress</h2>
                <span className="font-mono text-sm text-muted-foreground">
                  {completedTasks}/{totalTasks} tasks completed
                </span>
              </div>
              <Progress value={overallProgress} className="h-3" />
            </div>

            <Separator />

            <section>
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <span className="text-primary">→</span> Current Phase
              </h2>
              {currentPhase && (
                <PhaseCard
                  phase={currentPhase}
                  isCurrentPhase={true}
                  onUpdateStatus={handleUpdateStatus}
                  onUpdateRisk={handleUpdateRisk}
                  onToggleChecklist={handleToggleChecklist}
                  onUpdateNotes={handleUpdateNotes}
                />
              )}
            </section>

            <Separator />

            {activeRisks.length > 0 && (
              <>
                <section>
                  <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                    <Warning className="text-destructive" weight="fill" />
                    Active Risks
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {activeRisks.map((risk) => (
                      <Card key={risk.id} className="border-destructive/30">
                        <CardContent className="pt-6">
                          <div className="flex items-start gap-3 mb-2">
                            <RiskBadge level={risk.level} />
                            <div className="flex-1">
                              <p className="text-sm font-medium mb-1">{risk.description}</p>
                              <p className="text-xs text-muted-foreground">{risk.phaseName}</p>
                              {risk.mitigation && (
                                <p className="text-xs text-muted-foreground mt-2">
                                  <span className="font-semibold">Mitigation:</span> {risk.mitigation}
                                </p>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </section>

                <Separator />
              </>
            )}

            <section>
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Terminal className="text-accent" weight="bold" />
                Validation Commands
              </h2>
              <Card>
                <CardContent className="pt-6">
                  <p className="text-sm text-muted-foreground mb-4">
                    Run these commands to validate the migration at any phase
                  </p>
                  <div className="space-y-2">
                    {allValidationCommands.map((cmd, idx) => (
                      <div
                        key={idx}
                        className="flex items-center gap-2 p-3 bg-secondary rounded border border-border hover:border-primary/30 transition-colors"
                      >
                        <code className="flex-1 text-xs font-mono text-foreground overflow-x-auto">
                          {cmd}
                        </code>
                        <CopyButton text={cmd} />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </section>

            <Separator />

            <section>
              <h2 className="text-xl font-semibold mb-4">Migration Timeline</h2>
              <div className="space-y-4">
                {migrationData.phases.map((phase) => (
                  <PhaseCard
                    key={phase.id}
                    phase={phase}
                    isCurrentPhase={phase.id === currentPhase?.id}
                    onUpdateStatus={handleUpdateStatus}
                    onUpdateRisk={handleUpdateRisk}
                    onToggleChecklist={handleToggleChecklist}
                    onUpdateNotes={handleUpdateNotes}
                  />
                ))}
              </div>
            </section>

            <Separator />

            <section>
              <h2 className="text-xl font-semibold mb-4">Global Notes</h2>
              <Card>
                <CardContent className="pt-6">
                  <Textarea
                    value={migrationData.globalNotes}
                    onChange={(e) => handleUpdateGlobalNotes(e.target.value)}
                    placeholder="Add general notes about the migration..."
                    className="min-h-[150px] font-sans"
                    onBlur={(e) => handleUpdateGlobalNotes(e.target.value)}
                  />
                </CardContent>
              </Card>
            </section>

            <Separator />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <SafetyBoundaries />
              <SubrepoStatus />
            </div>

            <Separator />

            <UmbrellaLinks />
          </TabsContent>

          <TabsContent value="repositories">
            <section>
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Database className="text-primary" weight="bold" />
                Repository Health Dashboard
              </h2>
              <p className="text-sm text-muted-foreground mb-6">
                Monitor repository status, PRs, issues, and CI/CD for Monkey-Head-Project ecosystem. Using mock data by default.
              </p>
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 mb-6">
                {mockRepositories.map((repoHealth) => (
                  <RepositoryCard key={repoHealth.repo.name} repoHealth={repoHealth} isLive={false} />
                ))}
              </div>
              <GitHubSettingsPanel />
            </section>
          </TabsContent>

          <TabsContent value="validation">
            <ValidationCommandCenter />
          </TabsContent>

          <TabsContent value="copilot">
            <section>
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Brain className="text-primary" weight="bold" />
                Copilot Task Generator
              </h2>
              <p className="text-sm text-muted-foreground mb-6">
                Generate ready-to-use prompts for GitHub Copilot or AI coding agents with full context for each migration phase.
              </p>
              <CopilotTaskGenerator phases={migrationData.phases} />
            </section>
          </TabsContent>

          <TabsContent value="v1-runs">
            <section>
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Brain className="text-primary" weight="bold" />
                Huey Brain V1 Proof Loop Runs
              </h2>
              <p className="text-sm text-muted-foreground mb-6">
                Mock JSONL-style run data from controlled MP3 fixtures → local transcription → cognition bridge → structured log
              </p>
              <V1RunViewer runs={v1Runs} />
            </section>
          </TabsContent>

          <TabsContent value="operator">
            <section>
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Desktop className="text-primary" weight="bold" />
                HueyOS Operator Panel Mock
              </h2>
              <p className="text-sm text-muted-foreground mb-6">
                Simulated HueyOS cockpit for monitoring system status and connectors. All actions are mock-only.
              </p>
              <OperatorPanel data={operatorPanelData} />
            </section>
          </TabsContent>

          <TabsContent value="umbrella">
            <UmbrellaPage />
          </TabsContent>

          <TabsContent value="data">
            <ImportExportPanel
              migrationData={migrationData}
              v1Runs={v1Runs}
              operatorPanelData={operatorPanelData}
              dependencyBacklog={dependencyBacklog}
              onImportMigrationData={setMigrationData}
              onImportV1Runs={setV1Runs}
              onImportOperatorPanel={setOperatorPanelData}
              onImportDependencyBacklog={setDependencyBacklog}
              onResetToSampleData={handleResetToSampleData}
            />
          </TabsContent>
        </Tabs>
      </div>

      <Toaster position="bottom-right" />
    </div>
  )
}

export default App