# Contributing to HueyOS Migration Command Center

Thank you for your interest in contributing to the HueyOS Migration Command Center! This document provides guidelines for contributing to this companion dashboard for the Monkey-Head-Project ecosystem.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Process](#development-process)
- [Safety Guidelines](#safety-guidelines)
- [Coding Standards](#coding-standards)
- [Submitting Changes](#submitting-changes)
- [Documentation](#documentation)

---

## Code of Conduct

This project follows the Monkey-Head-Project code of conduct. Be respectful, collaborative, and constructive in all interactions.

---

## Getting Started

### Prerequisites

- Node.js 18+ and npm
- Git
- A code editor (VS Code recommended)
- Familiarity with React, TypeScript, and Tailwind CSS

### Setup

1. Fork the repository
2. Clone your fork:
   ```bash
   git clone https://github.com/your-username/hueyos-migration-command-center.git
   cd hueyos-migration-command-center
   ```
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the development server:
   ```bash
   npm run dev
   ```
5. Open http://localhost:5173 in your browser

---

## Development Process

### Workflow

1. **Create a branch** for your feature or fix:
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make your changes** following the coding standards

3. **Test thoroughly**:
   - Test all affected features
   - Test import/export with sample data
   - Test in different browsers if UI changes
   - Verify no console errors

4. **Commit your changes**:
   ```bash
   git commit -m "Brief description of changes"
   ```

5. **Push to your fork**:
   ```bash
   git push origin feature/your-feature-name
   ```

6. **Open a Pull Request** with:
   - Clear description of changes
   - Screenshots for UI changes
   - Reference to related issues
   - Testing notes

### Branch Naming

- `feature/description` - New features
- `fix/description` - Bug fixes
- `docs/description` - Documentation updates
- `refactor/description` - Code refactoring
- `test/description` - Test additions

---

## Safety Guidelines

### Critical Rules

This dashboard is a **local-first planning tool** with strict safety boundaries. All contributions must adhere to these rules:

#### ✅ Permitted

- Add UI components and layouts
- Create mock data for prototyping
- Add local browser storage features
- Improve import/export functionality
- Add data visualization components
- Enhance documentation

#### ❌ Prohibited

- Add live system control capabilities
- Execute commands on external systems
- Add robot or hardware control interfaces
- Create governance or memory mutation features
- Store credentials in frontend code
- Make external API calls (without Phase C approval and security review)

### Before Submitting

Verify your contribution:

- [ ] Uses mock data by default
- [ ] Does not execute system commands
- [ ] Does not store credentials
- [ ] Does not make network requests (current phase)
- [ ] Maintains clear "mock only" labels
- [ ] Updates relevant documentation
- [ ] Respects data boundaries (see docs/data-boundaries.md)

---

## Coding Standards

### TypeScript

- Use TypeScript for all new code
- Define types in `src/lib/types.ts`
- Avoid `any` - use proper types
- Use strict mode

```typescript
// ✅ Good
interface Props {
  phaseId: string
  status: PhaseStatus
  onUpdate: (id: string, status: PhaseStatus) => void
}

// ❌ Avoid
function MyComponent(props: any) { ... }
```

### React

- Use functional components with hooks
- Use `useKV` for persistent state (not `localStorage` directly)
- Use functional updates for state derived from previous state
- Keep components focused and small

```typescript
// ✅ Good - functional update
setPhases((currentPhases) => 
  currentPhases.map(p => p.id === id ? { ...p, status } : p)
)

// ❌ Bad - stale closure
setPhases([...phases, newPhase]) // phases might be stale!
```

### Styling

- Use Tailwind utility classes
- Follow existing color scheme (purple/black with green accents)
- Use theme CSS variables from `src/index.css`
- Maintain consistent spacing and typography
- Test responsive behavior on mobile

```tsx
// ✅ Good
<div className="bg-card text-card-foreground p-6 rounded-lg border border-border">

// ❌ Avoid inline styles unless necessary
<div style={{ backgroundColor: '#1a1a1a' }}>
```

### File Organization

- Place React components in `src/components/`
- Place types in `src/lib/types.ts`
- Place mock data in `src/lib/mockData.ts`
- Place utilities in `src/lib/utils.ts`
- Place sample data files in `sample-data/`

### Naming Conventions

- **Components**: PascalCase (`PhaseCard.tsx`)
- **Files**: kebab-case for utilities (`mock-data.ts`)
- **Variables**: camelCase (`phaseStatus`)
- **Types**: PascalCase (`PhaseStatus`)
- **Constants**: UPPER_SNAKE_CASE (`MAX_RETRIES`)

### Comments

- Write self-documenting code
- Add comments for complex logic
- Document public APIs and types
- Explain "why" not "what"

```typescript
// ✅ Good - explains reasoning
// Use functional update to avoid stale closure in async callbacks
setPhases((current) => [...current, newPhase])

// ❌ Unnecessary - code is self-explanatory
// Set the phases array
setPhases(newPhases)
```

---

## Submitting Changes

### Pull Request Guidelines

#### Title

Use a clear, descriptive title:

- ✅ "Add filter functionality to V1 Run Viewer"
- ✅ "Fix phase status update bug in checklist"
- ❌ "Updates"
- ❌ "Fixed stuff"

#### Description

Include:

1. **What**: Brief summary of changes
2. **Why**: Motivation and context
3. **How**: Technical approach (if not obvious)
4. **Testing**: How you tested the changes
5. **Screenshots**: For UI changes
6. **Breaking Changes**: If any (should be rare)

#### Template

```markdown
## Summary
Brief description of what this PR does.

## Motivation
Why are these changes needed?

## Changes
- Added X feature
- Fixed Y bug
- Updated Z documentation

## Testing
- [ ] Tested locally with sample data
- [ ] Tested import/export functionality
- [ ] Tested in Chrome and Firefox
- [ ] No console errors

## Screenshots
(if applicable)

## Checklist
- [ ] Follows coding standards
- [ ] Respects safety boundaries
- [ ] Documentation updated
- [ ] No credentials or secrets committed
- [ ] TypeScript types defined
```

### Review Process

1. Maintainer reviews code and tests changes
2. Feedback provided via PR comments
3. Author addresses feedback
4. Once approved, PR is merged

---

## Documentation

### When to Update Docs

Update documentation when you:

- Add a new feature
- Change existing behavior
- Add new data structures
- Add new dependencies
- Change security boundaries

### What to Document

- **README.md**: User-facing features, setup instructions
- **docs/project-scope.md**: Boundary changes, integration guidelines
- **docs/data-boundaries.md**: Data handling rules, security practices
- **docs/roadmap.md**: New phases or major features
- **sample-data/README.md**: New sample data files
- **Code comments**: Complex logic, non-obvious decisions

### Documentation Standards

- Write for the intended audience (users vs. developers)
- Use clear, concise language
- Include code examples where helpful
- Keep formatting consistent
- Update table of contents if adding sections

---

## Common Tasks

### Adding a New Component

1. Create file in `src/components/YourComponent.tsx`
2. Define props interface
3. Use existing shadcn components where possible
4. Follow theme color scheme
5. Test with mock data
6. Import and use in `App.tsx`

### Adding Sample Data

1. Create JSON file in `sample-data/`
2. Follow existing data structure
3. Use fictional/mock data only
4. Update `sample-data/README.md`
5. Test import in dashboard

### Adding a New Phase Feature

1. Update types in `src/lib/types.ts`
2. Update mock data in `src/lib/mockData.ts`
3. Create or modify components
4. Test state persistence
5. Update README.md

---

## Getting Help

- **Questions**: Open a discussion or issue
- **Bugs**: Open an issue with reproduction steps
- **Feature Ideas**: Open an issue to discuss before implementing
- **Security Issues**: See SECURITY.md for private reporting

---

## License

By contributing, you agree that your contributions will be licensed under the same license as the project (MIT for Spark Template components, Monkey-Head-Project license for project-specific code).

---

Thank you for contributing to the HueyOS Migration Command Center! 🚀
