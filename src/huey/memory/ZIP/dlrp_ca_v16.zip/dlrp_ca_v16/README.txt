dlrp.ca v16 – Static site bundle
===============================

Overview
--------
This package contains version 16 of the static site for Dylan L. R. Pollock’s
personal lab. It represents a complete refresh of the earlier design
and content, bringing the site in line with the vision outlined in
recent discussions. The layout prioritises clarity, a cohesive
purple‑on‑purple colour palette, and new sections dedicated to projects,
lab notes and a gallery. Navigation has been simplified, and every page
is filled with freshly written copy that better reflects the current
state of Dylan’s work.

Key Features
------------

* **Unified header and footer** across all pages with a sticky top bar
  that lightly frosts on scroll. A day/night toggle switches between
  dark and light variations of the purple theme.
* **Home page** introduces Dylan as an inventor and highlights
  core projects and lab activity with succinct cards.
* **About page** tells Dylan’s story, outlines focus areas and shows a
  compact timeline of milestones.
* **Projects page** lists major builds like the Monkey‑Head Project
  (Huey), PlayStation Ultimate and pinball experiments, each linking to
  its own detailed write‑up.
* **Lab page** serves as a development diary for kernel tweaks, cooling
  experiments and other work‑in‑progress notes.
* **Gallery page** showcases images of the robots, retro consoles, lab
  hardware and the beloved dogs of the lab. All images are included in
  the `img/` directory.
* **Dedicated project pages** dive into goals, architecture, logs and
  next steps for Huey, the PlayStation Ultimate and pinball
  prototypes.

Structure
---------

* `/index.html` – Main landing page with hero copy, highlight cards and
  calls to action.
* `/about/index.html` – Dylan’s biography, focus areas and a brief
  timeline of his work.
* `/projects/index.html` – Overview of the major builds with status
  tags and links to deeper pages.
* `/lab/index.html` – Ongoing notes and experiments from the lab.
* `/gallery/index.html` – Photo gallery divided into categories such as
  robotics, retro consoles, pinball, lab hardware and dogs.
* `/monkey-head-project/index.html` – Detailed write‑up on Huey and
  the Monkey‑Head Project.
* `/playstation-ultimate/index.html` – Detailed write‑up on the
  PlayStation Ultimate build.
* `/pinball/index.html` – Detailed write‑up on the pinball experiments.
* `/style.css` – Shared stylesheet defining the purple colour system,
  typography, spacing, buttons and responsive behaviours.
* `/script.js` – JavaScript handling theme switching and mobile
  navigation.
* `/img/` – Image assets used across the site. The included images were
  generated specifically for this build to represent the different
  categories in the gallery.
* `/404.html` – Simple not‑found page with a link back to the home
  page.
* `/robots.txt` – Crawl policy and a link to the sitemap.
* `/sitemap.xml` – Sitemap enumerating all of the main pages.
* `/site.webmanifest` – PWA manifest with updated colours and
  description.

Deployment notes
----------------

1. Place the contents of this bundle at the root of `dlrp.ca`.
2. Ensure your web server serves `index.html` by default for directory
   requests. Paths like `/about/` should load `/about/index.html`.
3. The JavaScript stores the user’s theme preference in local storage
   under the key `theme`. Clearing that value will reset to dark mode.
4. Update the year in the footer as appropriate. The current build
   uses `2025`.

Version
-------

This bundle represents v16 of the DLRP static site.