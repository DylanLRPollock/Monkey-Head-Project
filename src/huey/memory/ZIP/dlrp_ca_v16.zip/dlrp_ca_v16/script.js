// v16 – DLRP static site
// Handles theme switching between dark and light purple variants and
// toggles the mobile navigation. Theme preference is persisted in
// localStorage under the key `theme`.

(function () {
  const root = document.documentElement;
  const themeToggle = document.querySelector('.theme-toggle');
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');

  // Apply stored theme preference if available
  const stored = window.localStorage.getItem('theme');
  if (stored === 'light' || stored === 'dark') {
    root.setAttribute('data-theme', stored);
  }

  // Update the theme icon
  function updateIcon() {
    if (!themeToggle) return;
    const current = root.getAttribute('data-theme') || 'dark';
    themeToggle.textContent = current === 'dark' ? '🌙' : '☀️';
  }

  // Toggle between dark and light themes
  function toggleTheme() {
    const current = root.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
    root.setAttribute('data-theme', current);
    window.localStorage.setItem('theme', current);
    updateIcon();
  }

  if (themeToggle) {
    themeToggle.addEventListener('click', toggleTheme);
    updateIcon();
  }

  // Mobile navigation toggle
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      navLinks.classList.toggle('open');
    });

    navLinks.addEventListener('click', (event) => {
      if (event.target.tagName.toLowerCase() === 'a') {
        navLinks.classList.remove('open');
      }
    });
  }
})();