DLRP v14 – Static site bundle
=============================

Overview
--------
This package contains a static version of the dlrp.ca site focused on:

- The Monkey-Head Project (Huey)
- PlayStation Ultimate
- Dirty Leroy & The Executive (pinball experiments)
- A small gallery and basic meta files (sitemap, robots, manifest)

Folder layout
-------------
/index.html                      Main landing page
/style.css                       Global styles (red/black theme)
/script.js                       Small JS for theme + mobile nav
/404.html                        Simple 404 page
/robots.txt                      Basic crawl policy
/sitemap.xml                     Sitemap for major pages
/site.webmanifest                Web manifest (PWA-style metadata)
/favicon.ico                     Placeholder icon (replace if you like)

/img/                            Project photos (copy your own files here)
    dirty-leroy.jpeg            Dirty Leroy cabinet
    huey.jpeg                   Huey shell / robot podium
    playstation-ultimate.jpeg   PlayStation rack cabinet
    the-executive.jpeg          The Executive / alien-themed cabinet
    profile.jpeg                Dylan + Lexi

/monkey-head-project/index.html  Huey overview page
/playstation-ultimate/index.html PlayStation Ultimate cabinet page
/pinball/index.html             Pinball experiments (Dirty Leroy & The Executive)
/gallery/index.html             Photo gallery

Notes
-----
- The site assumes it is served at the domain root (e.g. https://dlrp.ca/).
  If you mount it under a subdirectory (e.g. /v14/), you can keep the structure
  but adjust links and sitemap URLs to include the prefix.

- Ensure the filenames in /img match the references in the HTML exactly.
  If your originals use slightly different names, rename them on upload.

- All styling is handled through style.css. Colors are driven by CSS variables
  at the top of the file. If you want to tweak the palette, adjust those
  variables and everything else will follow.

- script.js is intentionally minimal: it only handles the light/dark theme
  toggle and the mobile nav menu.

Version
-------
This bundle represents v14 of the dlrp.ca static site concept.
