// DLRP v14 – small enhancements (theme + mobile nav)

(function () {
  const root = document.documentElement;
  const themeToggle = document.querySelector("[data-theme-toggle]");
  const navToggle = document.querySelector("[data-nav-toggle]");
  const navLinks = document.querySelector(".site-nav-links");

  // Theme: respect saved preference if present
  const storedTheme = window.localStorage.getItem("dlrp-theme");
  if (storedTheme === "light" || storedTheme === "dark") {
    if (storedTheme === "light") {
      root.dataset.theme = "light";
    } else {
      root.dataset.theme = "dark";
    }
  }

  if (themeToggle) {
    themeToggle.addEventListener("click", () => {
      const current = root.dataset.theme === "light" ? "light" : "dark";
      const next = current === "light" ? "dark" : "light";

      if (next === "dark") {
        root.dataset.theme = "dark";
      } else {
        root.dataset.theme = "light";
      }

      window.localStorage.setItem("dlrp-theme", next);
      themeToggle.setAttribute("aria-pressed", next === "light" ? "true" : "false");
    });
  }

  // Mobile nav
  if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
      const isOpen = navLinks.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });

    navLinks.addEventListener("click", (event) => {
      if (event.target.tagName === "A" && navLinks.classList.contains("is-open")) {
        navLinks.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  }
})();
