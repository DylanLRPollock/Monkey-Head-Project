dlrp.ca — unified layout bundle (v20)
======================================

What this bundle is
-------------------
This archive contains the static files that currently power dlrp.ca. It is a
minimal, hand‑editable site that shares a single layout, navigation, and theme
system across the main pages.

Structure
---------
Root:
- index.html          — Home page with hero, "What lives here", main areas, and snapshots.
- 404.html            — Branded 404 page that shares the global header/footer and theme.
- README.txt          — This file.
- robots.txt          — Basic crawl rules, points to sitemap.xml.
- sitemap.xml         — XML sitemap for the primary sections.
- site.webmanifest    — PWA/manifest stub used for icons and theme color.
- favicon.ico         — Legacy favicon for older browsers.
- script.js           — Legacy theme + mobile nav logic for older sub‑pages.
- style.css           — Legacy stylesheet; the current layout uses assets/css/global.css.

Sections:
- about/
- huey/
- projects/
- gallery/
- download/
- monkey-head-project/
- pinball/
- playstation-ultimate/

Shared assets:
- assets/css/global.css  — Primary stylesheet used by index, gallery, download, and 404.
- assets/js/main.js      — Nav + theme controller shared by the new layout.
- assets/img/*           — Real photos and graphics used by hero, cards, and gallery.

How to work with it
-------------------
1. Edit the HTML files directly when you want copy or structure changes.
2. Keep the header/footer and global.css/main.js usage consistent when creating new pages.
3. When you introduce a new layout family, either:
   - Migrate old pages to the new global header/footer, or
   - Keep their CSS/JS clearly separated and documented here.
4. When publishing a new version:
   - Pack everything under the vXX folder into a zip (for this release: v20).
   - Upload and point your host to that folder as the new root.

This bundle is intentionally static and framework‑free so it can be served by
any basic web host and versioned as plain files.
