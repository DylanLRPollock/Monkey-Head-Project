dlrp.ca unified layout (starter bundle)
=======================================

This zip contains a minimal, single-layout static site for dlrp.ca:

Root pages
----------
- index.html          — Home, hero, and main sections.
- about/index.html    — About Dylan & the lab.
- huey/index.html     — High-level HueyOS overview.
- projects/index.html — Lab projects orbiting HueyOS.
- gallery/index.html  — Simple gallery layout.
- download/index.html — Download & code links placeholder.
- robots.txt          — Basic crawl rules.
- site.webmanifest    — PWA/manifest stub.

Shared assets
-------------
- assets/css/global.css  — Shared dark/light theme, layout, and components.
- assets/js/main.js      — Mobile nav toggle + theme toggle.
- assets/img/*           — PNG placeholders for hero, cards, gallery, favicon & OG.

How to use
----------
1. Drop this bundle into a static host (or your existing dlrp.ca repository).
2. Replace the placeholder PNGs in assets/img/ with real photos when ready.
3. Edit the copy in each HTML file to better match the live hardware state.
4. Keep header/footer + global.css/main.js consistent across new pages so the
   site stays visually unified.

The HTML is intentionally plain and static so it can be hand-edited or wired
into whatever build or deployment flow you prefer.


v5 notes
--------
This v5 bundle is identical in structure to the earlier unified site, but all
stock photography has been removed. Only a single portrait image is used:

- assets/img/dylan-and-dog.jpeg — Dylan kneeling beside a golden retriever indoors.

All favicon, Open Graph, and on-page images point to this single file so it can
be swapped or expanded later without changing the layout.
