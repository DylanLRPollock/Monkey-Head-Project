// v15 – DLRP / HueyOS
// Handles theme toggling (dark ↔ light) and mobile navigation toggling.

(function () {
  const root = document.documentElement;
  const themeToggle = document.querySelector('[data-theme-toggle]');
  const navToggle = document.querySelector('[data-nav-toggle]');
  const navLinks = document.querySelector('.site-nav-links');

  // Apply stored theme preference if available
  const storedTheme = window.localStorage.getItem('dlrp-theme');
  if (storedTheme === 'light' || storedTheme === 'dark') {
    root.setAttribute('data-theme', storedTheme);
  }

  // Helper to update the icon based on the current theme
  function updateThemeIcon() {
    if (!themeToggle) return;
    const current = root.getAttribute('data-theme') || 'dark';
    themeToggle.textContent = current === 'dark' ? '🌙' : '☀️';
  }

  // Toggle between dark and light modes
  function toggleTheme() {
    const current = root.getAttribute('data-theme') || 'dark';
    const next = current === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    window.localStorage.setItem('dlrp-theme', next);
    updateThemeIcon();
  }

  if (themeToggle) {
    themeToggle.addEventListener('click', toggleTheme);
    updateThemeIcon();
  }

  // Mobile navigation toggle
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const open = navLinks.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', String(open));
    });

    navLinks.addEventListener('click', (event) => {
      if (event.target.tagName === 'A' && navLinks.classList.contains('is-open')) {
        navLinks.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }
})();