DLRP v15 – Static site bundle
============================

Overview
--------
This package contains version 15 of the static site for Dylan L. R. Pollock’s
personal lab. It replaces earlier bundles with a unified design inspired by
the dark, glassy aesthetic shown in the screenshot provided. The site
documents HueyOS, the Monkey‑Head‑Project, and the various cabinets and
consoles orbiting it.

Structure
---------

* `/index.html` – Main landing page introducing HueyOS and linking to
  the other sections.
* `/about/index.html` – Information about Dylan and the guiding principles
  behind the lab.
* `/huey/index.html` – Deep dive on the HueyOS runtime, its hardware,
  governance, and goals.
* `/projects/index.html` – Highlights the major builds (PlayStation
  Ultimate, pinball cabinets, Huey shell).
* `/gallery/index.html` – Photo gallery of the machines and the lab
  environment.
* `/404.html` – Custom 404 page with link back home.
* `/style.css` – Shared styles for all pages, including dark/light themes,
  hero blocks, focus cards, and responsive layouts.
* `/script.js` – Handles theme toggling and mobile navigation.
* `/img/` – Photo assets used on the site (converted and renamed from
  JPEGs provided by the user). The images are resized to sensible
  dimensions for web use.
* `/robots.txt` – Crawl policy and sitemap reference.
* `/sitemap.xml` – Sitemap enumerating the main pages.
* `/site.webmanifest` – PWA manifest with theme colours and metadata.
* `/README.txt` – This file.

Deployment notes
----------------

1. Place the contents of this bundle at the root of `dlrp.ca`. Do not
   nest under a versioned folder unless you update internal links and
   `sitemap.xml` accordingly.
2. Ensure your web server serves `index.html` by default for directory
   requests (e.g. `/about/` should load `/about/index.html`).
3. Confirm that static assets (CSS, JS, images) are served with the
   correct MIME types. The CSS references absolute paths like `/style.css`
   and `/img/…`.
4. The `site.webmanifest` includes no icons; you may add an array of
   PNG icons if you wish to make the site installable as a web app.

Version
-------

This bundle represents v15 of the DLRP static site.